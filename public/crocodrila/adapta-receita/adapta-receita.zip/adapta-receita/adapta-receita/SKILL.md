---
name: adapta-receita
description: Adapta uma receita culinária para outro número de pessoas, para a quantidade de um ingrediente que a pessoa já tem, ou para uma restrição ou substituição, apontando o que NÃO escala junto (panela, forno, sal, alho, fermento). Use quando a pessoa mandar uma receita (foto, PDF, link ou texto) e pedir para dobrar, reduzir, adaptar, fazer para X pessoas ou "tenho tantos de tal ingrediente".
---

# Adapta-Receita

Recebo uma receita (foto, PDF, link ou texto colado) e um alvo de adaptação
(nº de porções, quantidade de um ingrediente-âncora, restrição ou substituição).

O que fazer:

1. Transcrever a receita original com fidelidade. Não inventar ingrediente,
   etapa, tempo ou temperatura que não estejam na fonte. Separar dois casos
   de quantidade não escrita, que não são a mesma coisa:
   - dado ausente que impede a conta (a carne, o tomate, o rendimento, a
     temperatura do forno): dizer qual falta, e não completar por suposição;
   - quantidade deixada a gosto por quem escreveu (sal, azeite, ervas,
     tempero, "um pouco de", "a gosto"): é escolha da receita, não lacuna.
     Não listar como dado faltante. Apenas dizer se acompanha a escala ou
     não, e seguir.

2. Estabelecer o consumo por pessoa antes de escalar. Perguntar, se não
   estiver dito: o prato é a refeição completa ou parte de um menu com
   outros pratos; quem come são adultos, crianças ou mistura; é entrada,
   prato único ou acompanhamento. Sem resposta, adotar refeição completa
   para adultos, declarar a suposição e seguir. Não tomar a porção da
   receita como medida de apetite.

3. Calcular o fator de escala a partir do alvo e desse consumo. Se o alvo
   for um ingrediente-âncora (ex.: "três morcillas" numa receita de duas),
   o fator sai dele: 3 ÷ 2 = 1,5.

4. Aplicar o fator a todos os ingredientes. Arredondar só quando a diferença
   for irrelevante no prato, e avisar quando arredondar. Não escalar
   linearmente: temperatura de forno, tamanho da panela, ponto de sal e
   quantidade de alho. O alho não acompanha o fator de jeito nenhum: manter
   a quantidade da receita original e deixar o ajuste a gosto, porque satura
   rápido e passa a dominar o prato.
   Gordura, embutido e aromático potente (linguiça, bacon, anchova, pimenta,
   louro, cravo, noz-moscada) escalam abaixo do fator quando ele passa de 2,
   ponto de partida em torno de três quartos, com o abatimento sempre
   declarado. Fermento, gelatina e agentes de liga escalam, mas com
   ressalva.

   Acompanhamento citado no modo de servir e não medido (espaguete, arroz,
   pão) entra na conta pelo alvo, marcado como acréscimo da adaptação e não
   da receita. Se a preparação tiver de ser dividida em duas panelas ou
   assadeiras, dividir também o aromático e o tempero entre elas, sem
   repetir a dose cheia em cada uma.

5. Entregar no widget de receita, com:
   - porções ajustadas, e quanto rende por pessoa
   - ingredientes com id, referenciados dentro dos passos
   - passos com título curto e timer quando houver espera
   - campo de notas com os ajustes práticos que a escala exige
     (área da panela, tempo de redução, dourar em levas, capacidade do forno)

6. Encerrar com uma linha em prosa dizendo o que mudou. Sem lista repetindo
   o que o widget já mostra.

Regras de estilo: PT-BR, unidades métricas, medidas caseiras brasileiras
preservadas como no original (xícara, colher de café, colher de sopa).
Sem juridiquês, sem estrangeirismo desnecessário, sem elogio à receita.
Manter a atribuição da fonte (livro, página, restaurante) quando existir.
