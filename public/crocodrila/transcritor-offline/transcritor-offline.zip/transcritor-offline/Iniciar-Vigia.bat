@echo off
chcp 65001 >nul
title Vigia de Transcricao - pasta TRANSCREVER

set "PY=%~dp0.venv\Scripts\python.exe"
if not exist "%PY%" (
    echo ERRO: o transcritor nao esta instalado nesta pasta.
    pause
    exit /b 1
)
"%PY%" "%~dp0vigia_transcricao.py"
pause
