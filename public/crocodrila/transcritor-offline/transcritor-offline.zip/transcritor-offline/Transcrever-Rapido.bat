@echo off
chcp 65001 >nul
title Transcritor Offline - Modelo Base (rapido)

set "PY=%~dp0.venv\Scripts\python.exe"
set "APP=%~dp0transcrever.py"

if not exist "%PY%" (
    echo ERRO: o transcritor nao esta instalado nesta pasta.
    echo Rode o instalar.ps1 do kit antes de usar.
    pause
    exit /b 1
)

set "ALVO=%~1"
if "%ALVO%"=="" (
    echo Arraste o audio/video ^(ou uma pasta^) para esta janela e tecle Enter:
    set /p ALVO="Caminho: "
)
rem o Windows cola o caminho arrastado ja entre aspas; tira as aspas
if defined ALVO set ALVO=%ALVO:"=%
if not defined ALVO (
    echo Nenhum arquivo informado.
    pause
    exit /b 1
)

"%PY%" "%APP%" "%ALVO%" --modelo base
if errorlevel 1 (
    echo.
    echo Houve erro. Leia a mensagem acima.
)
echo.
pause
