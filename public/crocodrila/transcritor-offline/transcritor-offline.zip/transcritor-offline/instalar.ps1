# instalar.ps1 - Transcritor Offline de audio e video (pt-BR)
#
# Uso normal: botao direito > "Executar com PowerShell".
# Opcoes (para quem usa o PowerShell):
#   -Destino "C:\outra\pasta"   onde instalar (padrao: C:\transcritor-offline)
#   -Modelos "base,small"       modelos a baixar agora (medium baixa no 1o uso)
#   -SemAtalhos                 nao cria atalhos na Area de Trabalho
#   -SemPausa                   nao espera Enter no final

param(
    [string]$Destino = "C:\transcritor-offline",
    [string]$Modelos = "base,small",
    [switch]$SemAtalhos,
    [switch]$SemPausa
)

# "Continue": no PowerShell 5.1, avisos que o Python/pip escrevem no stderr
# virariam erro fatal com "Stop". Os erros sao checados por $LASTEXITCODE.
$ErrorActionPreference = "Continue"
$origem = $PSScriptRoot
$erros = 0

function Titulo($t) { Write-Host ""; Write-Host "=== $t ===" -ForegroundColor Cyan }
function Ok($t)     { Write-Host "  [OK] $t" -ForegroundColor Green }
function Aviso($t)  { Write-Host "  [AVISO] $t" -ForegroundColor Yellow }
function Erro($t)   { Write-Host "  [ERRO] $t" -ForegroundColor Red }
function Fim {
    if (-not $SemPausa) { Write-Host ""; Read-Host "Aperte Enter para fechar" }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  TRANSCRITOR OFFLINE - instalacao" -ForegroundColor Cyan
Write-Host "  Destino: $Destino" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# Windows sem "caminhos longos" limita a 260 caracteres; uma das bibliotecas
# tem subpastas profundas (~120 caracteres) dentro do .venv.
if ($Destino.Length -gt 80) {
    Write-Host ""
    Write-Host "  [AVISO] O caminho de destino e longo ($($Destino.Length) caracteres)." -ForegroundColor Yellow
    Write-Host "  Se a instalacao falhar com 'No such file or directory', use um destino"
    Write-Host "  curto, como o padrao C:\transcritor-offline."
}

# ---------------------------------------------------------------- 1. Python
Titulo "1/6 - Procurando o Python (3.10 ou mais novo)"
$pyCmd = $null
$pyArgs = @()
$candidatos = @(
    @("py", "-3.13"), @("py", "-3.12"), @("py", "-3.11"), @("py", "-3.10"),
    @("py", "-3.14"), @("python", $null)
)
foreach ($c in $candidatos) {
    $exe = $c[0]; $flag = $c[1]
    if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
    try {
        if ($flag) { $v = & $exe $flag -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null }
        else       { $v = & $exe -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null }
    } catch { continue }
    if ($LASTEXITCODE -ne 0 -or -not $v) { continue }
    $partes = "$v".Trim().Split(".")
    if ([int]$partes[0] -eq 3 -and [int]$partes[1] -ge 10) {
        $pyCmd = $exe
        if ($flag) { $pyArgs = @($flag) }
        Ok "Python $v"
        break
    }
}
if (-not $pyCmd) {
    Erro "Python 3.10 ou mais novo nao encontrado."
    Write-Host "  Instale em https://www.python.org/downloads/ marcando 'Add python.exe to PATH'"
    Write-Host "  e rode este instalador de novo."
    Fim; exit 1
}

# ---------------------------------------------------------------- 2. Arquivos
Titulo "2/6 - Copiando os arquivos para $Destino"
New-Item -ItemType Directory -Path $Destino -Force | Out-Null
$itens = @("transcrever.py", "vigia_transcricao.py", "requirements.txt",
           "Transcrever.bat", "Transcrever-Qualidade.bat", "Transcrever-Rapido.bat",
           "Iniciar-Vigia.bat", "icons", "COMECE-AQUI.txt")
foreach ($i in $itens) {
    $src = Join-Path $origem $i
    if (Test-Path $src) { Copy-Item -Path $src -Destination $Destino -Recurse -Force }
    else { Aviso "Nao achei $i no kit" }
}
New-Item -ItemType Directory -Path (Join-Path $Destino "TRANSCREVER") -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Destino "models") -Force | Out-Null
Ok "Arquivos copiados"

# ---------------------------------------------------------------- 3. Ambiente
Titulo "3/6 - Criando o ambiente Python e baixando o motor (alguns minutos)"
$venv = Join-Path $Destino ".venv"
$venvPy = Join-Path $venv "Scripts\python.exe"
if (-not (Test-Path $venvPy)) {
    & $pyCmd @pyArgs -m venv $venv
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $venvPy)) {
        Erro "Nao consegui criar o ambiente Python em $venv"
        Fim; exit 1
    }
}
& $venvPy -m pip install --upgrade pip --quiet --disable-pip-version-check
& $venvPy -m pip install -r (Join-Path $Destino "requirements.txt") --quiet --disable-pip-version-check
if ($LASTEXITCODE -ne 0) {
    Erro "Falha ao instalar as bibliotecas (confira a internet e rode de novo)."
    Fim; exit 1
}
Ok "faster-whisper instalado"

# ---------------------------------------------------------------- 4. Modelos
Titulo "4/6 - Baixando os modelos de voz (uma unica vez)"
Write-Host "  base ~140 MB, small ~460 MB. Pode demorar, nao feche a janela."
Write-Host "  (Se aparecer 'unauthenticated requests to the HF Hub', e normal: ignore.)"
$env:HF_HUB_DISABLE_SYMLINKS_WARNING = "1"
$env:PYTHONUTF8 = "1"
$modelsDir = Join-Path $Destino "models"
foreach ($m in ($Modelos -split ",")) {
    $m = $m.Trim()
    if (-not $m) { continue }
    Write-Host "  Baixando '$m'..."
    $code = "from faster_whisper import WhisperModel; WhisperModel('$m', device='cpu', compute_type='int8', download_root=r'$modelsDir')"
    & $venvPy -c $code
    if ($LASTEXITCODE -eq 0) { Ok "Modelo $m" } else { Erro "Modelo $m nao baixou (confira a internet e rode de novo)"; $erros++ }
}

# ---------------------------------------------------------------- 5. Atalhos
Titulo "5/6 - Atalhos na Area de Trabalho"
if ($SemAtalhos) {
    Aviso "Pulado (-SemAtalhos)"
} else {
    $desktop = [Environment]::GetFolderPath("Desktop")
    $shell = New-Object -ComObject WScript.Shell
    $atalhos = @(
        @{ Nome = "Transcrever Audio-Video";              Bat = "Transcrever.bat";           Ico = "transcrever.ico" },
        @{ Nome = "Transcrever Audio-Video (qualidade)";  Bat = "Transcrever-Qualidade.bat"; Ico = "transcrever_qualidade.ico" },
        @{ Nome = "Transcrever Audio-Video (rapido)";     Bat = "Transcrever-Rapido.bat";    Ico = "transcrever_rapido.ico" },
        @{ Nome = "Vigia de Transcricao";                 Bat = "Iniciar-Vigia.bat";         Ico = "vigia.ico" }
    )
    foreach ($a in $atalhos) {
        $lnk = $shell.CreateShortcut((Join-Path $desktop ($a.Nome + ".lnk")))
        $lnk.TargetPath = Join-Path $Destino $a.Bat
        $lnk.WorkingDirectory = $Destino
        $lnk.IconLocation = (Join-Path $Destino ("icons\" + $a.Ico)) + ",0"
        $lnk.Save()
        Ok $a.Nome
    }
}

# ---------------------------------------------------------------- 6. Conferencia
Titulo "6/6 - Conferencia final"
& $venvPy -c "import faster_whisper, av" 2>$null
if ($LASTEXITCODE -eq 0) { Ok "Motor de transcricao" } else { Erro "O motor de transcricao nao carrega"; $erros++ }
foreach ($f in @("transcrever.py", "Transcrever.bat")) {
    if (Test-Path (Join-Path $Destino $f)) { Ok $f } else { Erro "Falta $f"; $erros++ }
}

Write-Host ""
if ($erros -eq 0) {
    Write-Host "  INSTALACAO CONCLUIDA COM SUCESSO!" -ForegroundColor Green
    Write-Host "  Arraste um audio ou video sobre o atalho 'Transcrever Audio-Video'."
} else {
    Write-Host "  Instalacao terminou com $erros problema(s). Leia as mensagens acima." -ForegroundColor Yellow
}
Fim
if ($erros -ne 0) { exit 1 }
