# instalar-no-claude.ps1
# Copia a skill "transcrever" para o Claude Code desta conta e confere se o
# transcritor esta instalado. Rodar DEPOIS do instalar.ps1 principal.

$ErrorActionPreference = "Continue"
$origem   = Join-Path $PSScriptRoot "transcrever"
$destBase = Join-Path $HOME ".claude\skills"
$destino  = Join-Path $destBase "transcrever"
$python   = "C:\transcritor-offline\.venv\Scripts\python.exe"
$problemas = 0

Write-Host ""
Write-Host "=== Ligando o transcritor no Claude ===" -ForegroundColor Cyan

# 1. Transcritor instalado?
if (Test-Path $python) {
    Write-Host "[OK] Transcritor instalado em C:\transcritor-offline" -ForegroundColor Green
} else {
    Write-Host "[FALTA] Transcritor nao encontrado em C:\transcritor-offline." -ForegroundColor Red
    Write-Host "        Rode primeiro o instalar.ps1 da pasta principal do kit."
    $problemas++
}

# 2. Copiar a skill (backup da anterior FORA da pasta skills, senao o Claude
#    enxerga duas skills com o mesmo nome)
if (-not (Test-Path $destBase)) { New-Item -ItemType Directory -Path $destBase -Force | Out-Null }
if (Test-Path $destino) {
    $bakBase = Join-Path (Split-Path $destBase -Parent) "skills-backup"
    if (-not (Test-Path $bakBase)) { New-Item -ItemType Directory -Path $bakBase -Force | Out-Null }
    $bak = Join-Path $bakBase ("transcrever-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Move-Item -Path $destino -Destination $bak
    Write-Host "[INFO] Ja existia uma skill 'transcrever'; guardada em $bak"
}
Copy-Item -Path $origem -Destination $destino -Recurse
if (Test-Path (Join-Path $destino "SKILL.md")) {
    Write-Host "[OK] Skill copiada para $destino" -ForegroundColor Green
} else {
    Write-Host "[ERRO] Nao consegui copiar a skill" -ForegroundColor Red
    $problemas++
}

Write-Host ""
if ($problemas -eq 0) {
    Write-Host "PRONTO. Feche e abra o Claude Code e peca: transcreve este audio ..." -ForegroundColor Green
} else {
    Write-Host "Ha $problemas pendencia(s) acima. Resolva e rode de novo." -ForegroundColor Yellow
}
Write-Host ""
Read-Host "Aperte Enter para fechar"
