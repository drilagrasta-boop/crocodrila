# -*- coding: utf-8 -*-
"""
Transcritor offline de audio e video (pt-BR) via faster-whisper.

Uso:
    python transcrever.py <arquivo-ou-pasta> [--modelo base|small|medium]
                          [--saida <pasta>] [--srt] [--sem-timestamps] [--forcar]

Saida (ao lado do arquivo de origem, salvo --saida):
    <nome>.txt              texto corrido em paragrafos
    <nome>_timestamps.txt   segmentos com [HH:MM:SS]
    <nome>.srt              legenda (apenas com --srt)

100% offline apos a instalacao: modelos na pasta models. O ffmpeg e opcional:
se houver (embarcado na pasta ffmpeg ou no PATH), extrai o audio antes; se nao houver,
o proprio faster-whisper decodifica o arquivo (PyAV), inclusive video.
"""

import argparse
import shutil
import subprocess
import sys
import time
from pathlib import Path

try:
    from colorama import Fore, Style, init as colorama_init
    colorama_init()
except ImportError:  # fallback sem cor
    class _Dummy:
        def __getattr__(self, _):
            return ""
    Fore = Style = _Dummy()

BASE = Path(__file__).resolve().parent
MODELS_DIR = BASE / "models"
TEMP_DIR = BASE / "temp"

EXT_AUDIO = {".mp3", ".wav", ".m4a", ".ogg", ".opus", ".wma", ".aac", ".flac"}
EXT_VIDEO = {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm", ".ts"}
EXT_TODAS = EXT_AUDIO | EXT_VIDEO

MODELOS_VALIDOS = ("base", "small", "medium")


def achar_ffmpeg() -> str | None:
    """Localiza o ffmpeg embarcado; depois o PATH; None se nao houver."""
    candidatos = sorted(BASE.glob("ffmpeg/**/ffmpeg.exe"))
    if candidatos:
        return str(candidatos[0])
    return shutil.which("ffmpeg")


def extrair_audio(origem: Path, ffmpeg: str) -> Path:
    """Converte qualquer audio/video para WAV 16 kHz mono (formato do Whisper)."""
    TEMP_DIR.mkdir(exist_ok=True)
    destino = TEMP_DIR / (origem.stem + "_16k.wav")
    cmd = [
        ffmpeg, "-y", "-i", str(origem),
        "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le",
        str(destino),
    ]
    resultado = subprocess.run(cmd, capture_output=True, text=True,
                               encoding="utf-8", errors="replace")
    if resultado.returncode != 0 or not destino.exists():
        raise RuntimeError(
            "ffmpeg falhou ao extrair audio de %s:\n%s"
            % (origem.name, resultado.stderr[-800:])
        )
    return destino


def fmt_ts(segundos: float) -> str:
    h = int(segundos // 3600)
    m = int((segundos % 3600) // 60)
    s = int(segundos % 60)
    return "%02d:%02d:%02d" % (h, m, s)


def fmt_ts_srt(segundos: float) -> str:
    ms = int(round((segundos - int(segundos)) * 1000))
    return fmt_ts(segundos) + ",%03d" % ms


def montar_paragrafos(segmentos, pausa_paragrafo: float = 2.0) -> str:
    """Junta segmentos em paragrafos, quebrando em pausas longas."""
    paragrafos = []
    atual = []
    fim_anterior = None
    for seg in segmentos:
        texto = seg["texto"].strip()
        if not texto:
            continue
        if (fim_anterior is not None
                and seg["inicio"] - fim_anterior >= pausa_paragrafo and atual):
            paragrafos.append(" ".join(atual))
            atual = []
        atual.append(texto)
        fim_anterior = seg["fim"]
    if atual:
        paragrafos.append(" ".join(atual))
    return "\n\n".join(paragrafos) + "\n"


def montar_timestamps(segmentos) -> str:
    linhas = []
    for seg in segmentos:
        texto = seg["texto"].strip()
        if texto:
            linhas.append("[%s] %s" % (fmt_ts(seg["inicio"]), texto))
    return "\n".join(linhas) + "\n"


def montar_srt(segmentos) -> str:
    blocos = []
    n = 0
    for seg in segmentos:
        texto = seg["texto"].strip()
        if not texto:
            continue
        n += 1
        blocos.append(
            "%d\n%s --> %s\n%s\n"
            % (n, fmt_ts_srt(seg["inicio"]), fmt_ts_srt(seg["fim"]), texto)
        )
    return "\n".join(blocos)


def carregar_modelo(nome: str):
    from faster_whisper import WhisperModel
    MODELS_DIR.mkdir(exist_ok=True)
    print(Fore.CYAN + "Carregando modelo '%s'..." % nome + Style.RESET_ALL)
    try:
        return WhisperModel(nome, device="cpu", compute_type="int8",
                            download_root=str(MODELS_DIR), local_files_only=True)
    except Exception:
        print(Fore.YELLOW + "Modelo nao encontrado localmente. "
              "Baixando (unica vez, requer internet)..." + Style.RESET_ALL)
        return WhisperModel(nome, device="cpu", compute_type="int8",
                            download_root=str(MODELS_DIR))


def transcrever_arquivo(arquivo: Path, modelo, ffmpeg: str,
                        saida_dir: Path | None, gerar_srt: bool,
                        gerar_timestamps: bool) -> None:
    destino_base = (saida_dir or arquivo.parent) / arquivo.stem
    print()
    print(Fore.GREEN + "=== %s ===" % arquivo.name + Style.RESET_ALL)

    inicio_exec = time.time()
    wav_temp = None
    fonte = arquivo
    if ffmpeg and arquivo.suffix.lower() != ".wav":
        print("Extraindo audio (ffmpeg)...")
        wav_temp = extrair_audio(arquivo, ffmpeg)
        fonte = wav_temp

    try:
        segments_iter, info = modelo.transcribe(
            str(fonte), language="pt", beam_size=5, vad_filter=True,
        )
        duracao = info.duration or 0
        print("Duracao do audio: %s | transcrevendo..." % fmt_ts(duracao))

        try:
            from tqdm import tqdm
            barra = tqdm(total=round(duracao), unit="s", desc="Progresso")
        except ImportError:
            barra = None

        segmentos = []
        pos = 0
        for seg in segments_iter:
            segmentos.append(
                {"inicio": seg.start, "fim": seg.end, "texto": seg.text}
            )
            if barra:
                avanco = round(seg.end) - pos
                if avanco > 0:
                    barra.update(min(avanco, barra.total - pos))
                    pos = round(seg.end)
        if barra:
            if pos < barra.total:
                barra.update(barra.total - pos)
            barra.close()
    finally:
        if wav_temp and wav_temp.exists():
            wav_temp.unlink()

    if not segmentos:
        print(Fore.YELLOW + "Nenhuma fala detectada em %s." % arquivo.name
              + Style.RESET_ALL)
        return

    txt = destino_base.with_suffix(".txt")
    txt.write_text(montar_paragrafos(segmentos), encoding="utf-8")
    gerados = [txt.name]

    if gerar_timestamps:
        ts = destino_base.parent / (destino_base.name + "_timestamps.txt")
        ts.write_text(montar_timestamps(segmentos), encoding="utf-8")
        gerados.append(ts.name)

    if gerar_srt:
        srt = destino_base.with_suffix(".srt")
        srt.write_text(montar_srt(segmentos), encoding="utf-8")
        gerados.append(srt.name)

    tempo = time.time() - inicio_exec
    print(Fore.GREEN + "Concluido em %s. Gerados: %s"
          % (fmt_ts(tempo), ", ".join(gerados)) + Style.RESET_ALL)


def coletar_arquivos(alvo: Path):
    if alvo.is_file():
        if alvo.suffix.lower() not in EXT_TODAS:
            print(Fore.RED + "Extensao nao suportada: %s" % alvo.suffix
                  + Style.RESET_ALL)
            return []
        return [alvo]
    arquivos = [p for p in sorted(alvo.rglob("*"))
                if p.is_file() and p.suffix.lower() in EXT_TODAS]
    return arquivos


def main():
    parser = argparse.ArgumentParser(
        description="Transcritor offline de audio/video (pt-BR)")
    parser.add_argument("alvo", help="arquivo ou pasta")
    parser.add_argument("--modelo", choices=MODELOS_VALIDOS, default="small")
    parser.add_argument("--saida", help="pasta de saida (padrao: ao lado da origem)")
    parser.add_argument("--srt", action="store_true", help="gerar legenda .srt")
    parser.add_argument("--sem-timestamps", action="store_true",
                        help="nao gerar o _timestamps.txt")
    parser.add_argument("--forcar", action="store_true",
                        help="reprocessar mesmo se o .txt ja existir")
    args = parser.parse_args()

    alvo = Path(args.alvo.strip('"'))
    if not alvo.exists():
        print(Fore.RED + "Caminho nao encontrado: %s" % alvo + Style.RESET_ALL)
        sys.exit(1)

    saida_dir = None
    if args.saida:
        saida_dir = Path(args.saida)
        saida_dir.mkdir(parents=True, exist_ok=True)

    arquivos = coletar_arquivos(alvo)
    if not arquivos:
        print(Fore.YELLOW + "Nenhum audio/video encontrado." + Style.RESET_ALL)
        sys.exit(0)

    if not args.forcar:
        pendentes = []
        for a in arquivos:
            txt = (saida_dir or a.parent) / (a.stem + ".txt")
            if txt.exists():
                print("Pulando (ja transcrito): %s" % a.name)
            else:
                pendentes.append(a)
        arquivos = pendentes

    if not arquivos:
        print(Fore.GREEN + "Tudo ja transcrito. Use --forcar para refazer."
              + Style.RESET_ALL)
        sys.exit(0)

    print("Arquivos a transcrever: %d | modelo: %s"
          % (len(arquivos), args.modelo))

    ffmpeg = achar_ffmpeg()
    modelo = carregar_modelo(args.modelo)

    erros = 0
    for arquivo in arquivos:
        try:
            transcrever_arquivo(arquivo, modelo, ffmpeg, saida_dir,
                                args.srt, not args.sem_timestamps)
        except Exception as exc:
            erros += 1
            print(Fore.RED + "ERRO em %s: %s" % (arquivo.name, exc)
                  + Style.RESET_ALL)

    print()
    if erros:
        print(Fore.YELLOW + "Finalizado com %d erro(s)." % erros + Style.RESET_ALL)
        sys.exit(1)
    print(Fore.GREEN + "Finalizado com sucesso." + Style.RESET_ALL)


if __name__ == "__main__":
    main()
