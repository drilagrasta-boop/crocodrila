# -*- coding: utf-8 -*-
"""
Vigia da pasta TRANSCREVER: qualquer audio/video solto nela e transcrito
automaticamente (modelo small) e o .txt aparece na mesma pasta.

Uso: python vigia_transcricao.py  (deixar a janela aberta; Ctrl+C encerra)

Espera o arquivo parar de crescer (copia concluida) antes de transcrever.
"""

import subprocess
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
PASTA = BASE / "TRANSCREVER"
PYTHON = BASE / ".venv" / "Scripts" / "python.exe"
SCRIPT = BASE / "transcrever.py"

EXT_TODAS = {".mp3", ".wav", ".m4a", ".ogg", ".opus", ".wma", ".aac", ".flac",
             ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm", ".ts"}

INTERVALO = 15  # segundos entre verificacoes


def estavel(arquivo: Path) -> bool:
    """True se o arquivo parou de crescer (copia concluida)."""
    try:
        t1 = arquivo.stat().st_size
        time.sleep(2)
        t2 = arquivo.stat().st_size
        return t1 == t2 and t1 > 0
    except OSError:
        return False


def pendentes():
    itens = []
    for p in sorted(PASTA.iterdir()):
        if not p.is_file() or p.suffix.lower() not in EXT_TODAS:
            continue
        if p.with_suffix(".txt").exists():
            continue
        itens.append(p)
    return itens


def main():
    PASTA.mkdir(exist_ok=True)
    print("Vigia ativo. Solte audios/videos em:\n  %s" % PASTA)
    print("O .txt aparece na mesma pasta. Ctrl+C encerra.\n")
    while True:
        try:
            for arquivo in pendentes():
                if not estavel(arquivo):
                    continue  # ainda copiando; proxima rodada pega
                print("Novo arquivo: %s" % arquivo.name)
                subprocess.run(
                    [str(PYTHON), str(SCRIPT), str(arquivo), "--modelo", "small"]
                )
            time.sleep(INTERVALO)
        except KeyboardInterrupt:
            print("\nVigia encerrado.")
            sys.exit(0)


if __name__ == "__main__":
    main()
