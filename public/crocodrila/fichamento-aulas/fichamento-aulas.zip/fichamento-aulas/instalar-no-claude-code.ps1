# instalar-no-claude-code.ps1
# Copia a skill "fichamento-de-aula" para o Claude Code desta conta, instala a
# biblioteca python-docx (que gera o Word) e testa com a aula de exemplo.

$ErrorActionPreference = "Continue"
$origem   = Join-Path $PSScriptRoot "fichamento-de-aula"
$destBase = Join-Path $HOME ".claude\skills"
$destino  = Join-Path $destBase "fichamento-de-aula"
$problemas = 0

Write-Host ""
Write-Host "=== Instalando o Fichamento de Aula no Claude Code ===" -ForegroundColor Cyan

# 1. Python
$py = $null; $pyArgs = @()
if (Get-Command py -ErrorAction SilentlyContinue) { $py = "py"; $pyArgs = @("-3") }
elseif (Get-Command python -ErrorAction SilentlyContinue) { $py = "python" }
if ($py) {
    Write-Host "[OK] Python encontrado" -ForegroundColor Green
} else {
    Write-Host "[FALTA] Python nao encontrado. Instale em https://www.python.org/downloads/" -ForegroundColor Red
    Write-Host "        marcando 'Add python.exe to PATH', e rode de novo."
    $problemas++
}

# 2. python-docx
if ($py) {
    & $py @pyArgs -c "import docx" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  Instalando python-docx (precisa de internet)..."
        & $py @pyArgs -m pip install --user --quiet --disable-pip-version-check python-docx
    }
    & $py @pyArgs -c "import docx" 2>$null
    if ($LASTEXITCODE -eq 0) { Write-Host "[OK] python-docx" -ForegroundColor Green }
    else { Write-Host "[FALTA] python-docx nao instalou (confira a internet)" -ForegroundColor Red; $problemas++ }
}

# 3. Copiar a skill (backup da anterior FORA da pasta skills)
if (-not (Test-Path $destBase)) { New-Item -ItemType Directory -Path $destBase -Force | Out-Null }
if (Test-Path $destino) {
    $bakBase = Join-Path (Split-Path $destBase -Parent) "skills-backup"
    if (-not (Test-Path $bakBase)) { New-Item -ItemType Directory -Path $bakBase -Force | Out-Null }
    $bak = Join-Path $bakBase ("fichamento-de-aula-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Move-Item -Path $destino -Destination $bak
    Write-Host "[INFO] Ja existia uma versao da skill; guardada em $bak"
}
Copy-Item -Path $origem -Destination $destino -Recurse
$gerador = Join-Path $destino "scripts\gerar_fichamento_docx.py"
if (Test-Path $gerador) { Write-Host "[OK] Skill copiada para $destino" -ForegroundColor Green }
else { Write-Host "[ERRO] Nao consegui copiar a skill" -ForegroundColor Red; $problemas++ }

# 4. Autoteste: gera um Word de teste numa pasta temporaria
if ($py -and (Test-Path $gerador) -and $problemas -eq 0) {
    $tmp = Join-Path $env:TEMP ("teste-fichamento-" + (Get-Date -Format "yyyyMMddHHmmss"))
    New-Item -ItemType Directory -Path $tmp -Force | Out-Null
    $json = Join-Path $tmp "teste.json"
    '{"metadados":{"disciplina":"Teste"},"bloco1":{"tema_central":"Teste de instalacao."},"bloco2":{}}' |
        Out-File -FilePath $json -Encoding ascii
    $saida = Join-Path $tmp "teste.docx"
    & $py @pyArgs $gerador $json $saida *> $null
    if (Test-Path $saida) { Write-Host "[OK] Autoteste: Word gerado" -ForegroundColor Green }
    else { Write-Host "[ERRO] Autoteste: o Word nao foi gerado" -ForegroundColor Red; $problemas++ }
    Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host ""
if ($problemas -eq 0) {
    Write-Host "PRONTO. Feche e abra o Claude Code e peca:" -ForegroundColor Green
    Write-Host "  faz o fichamento da aula em C:\...\aula3.txt"
} else {
    Write-Host "Ha $problemas pendencia(s) acima. Resolva e rode de novo." -ForegroundColor Yellow
}
Write-Host ""
Read-Host "Aperte Enter para fechar"
