# -*- coding: utf-8 -*-
"""
Gera o fichamento de aula em Word (.docx) a partir de um arquivo JSON.

Uso:
    python gerar_fichamento_docx.py fichamento.json "Fichamento - Aula 3.docx"

Estrutura do JSON (campos ausentes viram "Não informado" ou ficam vazios):
{
  "metadados": {"disciplina": "", "professor": "", "instituicao": "",
                "data": "", "modulo": ""},
  "bloco1": {
    "tema_central": "texto",
    "conceitos": [["Conceito", "explicação conforme o professor"], ...],
    "argumentos": "prosa; parágrafos separados por linha em branco",
    "exemplos": "prosa",
    "conexoes": "prosa",
    "perguntas": "prosa"
  },
  "bloco2": {
    "referencias": [{"autor": "", "obra": "", "ano": "",
                     "completude": "Completa|Parcial|Fragmentária",
                     "contexto": ""}, ...],
    "sugestoes": "prosa"
  }
}

Requer: python-docx  (pip install python-docx)
"""

import json
import sys
from pathlib import Path

try:
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Cm, Pt
except ImportError:
    print("ERRO: falta a biblioteca python-docx. Instale com:  pip install python-docx")
    sys.exit(2)

NAO_INFORMADO = "Não informado"
# colunas: #, Autor(es), Obra/Título, Ano, Completude, Contexto na aula (A4, ~16 cm úteis)
LARGURAS_CM = [0.8, 3.0, 3.6, 1.8, 2.4, 4.4]


def paragrafos(doc, texto):
    """Escreve prosa respeitando as quebras de parágrafo (linha em branco)."""
    blocos = [b.strip() for b in (texto or "").split("\n\n") if b.strip()]
    if not blocos:
        doc.add_paragraph("Nada identificado na transcrição.")
    for b in blocos:
        doc.add_paragraph(" ".join(b.split("\n")))


def criar_fichamento(dados, caminho_saida):
    meta = dados.get("metadados", {})
    b1 = dados.get("bloco1", {})
    b2 = dados.get("bloco2", {})

    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.15

    titulo = doc.add_heading("FICHAMENTO DE AULA", level=0)
    titulo.alignment = WD_ALIGN_PARAGRAPH.CENTER

    for rotulo, chave in [("Disciplina", "disciplina"), ("Professor(a)", "professor"),
                          ("Instituição", "instituicao"), ("Data da aula", "data"),
                          ("Módulo/Unidade", "modulo")]:
        p = doc.add_paragraph()
        p.add_run(f"{rotulo}: ").bold = True
        p.add_run(meta.get(chave) or NAO_INFORMADO)

    doc.add_heading("BLOCO 1 — FICHAMENTO ANALÍTICO", level=1)

    doc.add_heading("1. Tema Central da Aula", level=2)
    paragrafos(doc, b1.get("tema_central"))

    doc.add_heading("2. Conceitos-Chave", level=2)
    conceitos = b1.get("conceitos") or []
    if not conceitos:
        doc.add_paragraph("Nada identificado na transcrição.")
    for item in conceitos:
        conceito, explicacao = (list(item) + ["", ""])[:2]
        p = doc.add_paragraph()
        p.add_run(str(conceito)).bold = True
        p.add_run(f" — {explicacao}")

    for numero, titulo_secao, chave in [
        (3, "Argumentos e Teses Centrais", "argumentos"),
        (4, "Exemplos e Casos Concretos", "exemplos"),
        (5, "Conexões Interdisciplinares", "conexoes"),
        (6, "Perguntas em Aberto / Provocações", "perguntas"),
    ]:
        doc.add_heading(f"{numero}. {titulo_secao}", level=2)
        paragrafos(doc, b1.get(chave))

    doc.add_heading("BLOCO 2 — REFERÊNCIAS BIBLIOGRÁFICAS", level=1)
    refs = b2.get("referencias") or []
    if refs:
        colunas = ["#", "Autor(es)", "Obra/Título", "Ano", "Completude", "Contexto na aula"]
        tabela = doc.add_table(rows=1, cols=len(colunas))
        tabela.style = "Table Grid"
        tabela.alignment = WD_TABLE_ALIGNMENT.CENTER
        for i, col in enumerate(colunas):
            cel = tabela.rows[0].cells[i]
            cel.text = col
            for run in cel.paragraphs[0].runs:
                run.bold = True
                run.font.size = Pt(10)
        for n, ref in enumerate(refs, 1):
            valores = [str(ref.get("num") or n), ref.get("autor", ""), ref.get("obra", ""),
                       str(ref.get("ano", "")), ref.get("completude", ""), ref.get("contexto", "")]
            linha = tabela.add_row()
            for i, v in enumerate(valores):
                linha.cells[i].text = v
                for run in linha.cells[i].paragraphs[0].runs:
                    run.font.size = Pt(10)
        # larguras proporcionais (o padrao divide igual e espreme o contexto)
        tabela.autofit = False
        for i, largura in enumerate(LARGURAS_CM):
            for linha in tabela.rows:
                linha.cells[i].width = Cm(largura)
    else:
        doc.add_paragraph("Nenhuma referência bibliográfica foi identificada nesta transcrição.")

    if (b2.get("sugestoes") or "").strip():
        doc.add_heading("Referências para completar", level=2)
        paragrafos(doc, b2["sugestoes"])

    doc.save(caminho_saida)
    return caminho_saida


def main():
    if len(sys.argv) != 3:
        print('Uso: python gerar_fichamento_docx.py fichamento.json "saida.docx"')
        sys.exit(1)
    entrada, saida = Path(sys.argv[1]), Path(sys.argv[2])
    try:
        dados = json.loads(entrada.read_text(encoding="utf-8"))
    except Exception as erro:
        print(f"ERRO ao ler o JSON {entrada}: {erro}")
        sys.exit(1)
    criar_fichamento(dados, saida)
    print(f"Fichamento salvo em: {saida.resolve()}")


if __name__ == "__main__":
    main()
