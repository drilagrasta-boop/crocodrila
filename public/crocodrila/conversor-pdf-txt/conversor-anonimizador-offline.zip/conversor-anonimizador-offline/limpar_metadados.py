#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
limpar_metadados.py  --  Remocao de metadados de documentos FINAIS (.doc, .docx e .pdf)

Passo final do pipeline: depois que a peca anonimizada e montada em Word ou
exportada para PDF, o arquivo novo nasce com metadados que identificam a origem
(autor, "modificado por", datas, nome do software, empresa, template, tempo de
edicao, historico de revisoes, comentarios). Este script remove tudo isso.

Gera uma COPIA ao lado do original:
  <nome>_limpo.docx  /  <nome>_limpo.pdf
O arquivo original NUNCA e alterado.

O que faz:
  PDF  -> zera o dicionario Info (autor, criador, produtor, titulo, datas...),
          remove o fluxo XMP, remove anexos embutidos e JavaScript embutido.
  DOCX -> zera core.xml (autor, datas, revisao, titulo, assunto...),
          zera app.xml (software, empresa, gerente, template, tempo de edicao),
          esvazia custom.xml (propriedades personalizadas),
          remove comentarios,
          REJEITA as marcas de controle de alteracoes (revisoes), voltando ao
          texto original (--aceitar-revisoes inverte para ACEITAR).
  DOC  -> (formato Word antigo) converte para .docx no Word, limpa como acima,
          regrava como .doc e faz um scrub OLE2 final (zera SummaryInformation e
          DocumentSummaryInformation e o historico "salvo por" do fluxo Table).
          A saida MANTEM o formato .doc. Requer Word instalado + pywin32 + olefile.

ATENCAO: quando um .docx tiver revisoes pendentes, por padrao elas serao
REJEITADAS (insercoes desfeitas, delecoes restauradas) e o texto visivel pode
mudar. O script avisa em destaque quais arquivos tinham revisoes, para voce
reconferir a peca.

Uso:
  python limpar_metadados.py "arquivo.docx"
  python limpar_metadados.py "arquivo.pdf"
  python limpar_metadados.py "pasta_com_docs/"        (processa .docx e .pdf)
  python limpar_metadados.py "arquivo.docx" --aceitar-revisoes
"""
import argparse
import io
import sys
import zipfile
from pathlib import Path

# -- PDF ---------------------------------------------------------------------
try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None

# -- DOCX (manipulacao no nivel do pacote OPC/zip) ---------------------------
try:
    from lxml import etree
except Exception:
    etree = None

# -- DOC antigo (.doc binario): convertido para .docx via automacao do Word --
try:
    import win32com.client as _win32
except Exception:
    _win32 = None

# -- Cores no terminal (opcional) --------------------------------------------
try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init()
except Exception:
    class _Dummy:
        def __getattr__(self, _):
            return ""
    Fore = Style = _Dummy()


# ===========================================================================
# WordprocessingML: marcas de revisao e de comentario
# ===========================================================================
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

# Insercoes / destino de mover. ACEITAR = manter o conteudo; REJEITAR = descartar.
INS = {W + "ins", W + "moveTo"}

# Delecoes / origem de mover. ACEITAR = descartar o conteudo; REJEITAR = restaurar.
DEL = {W + "del", W + "moveFrom"}

# Mudancas de formatacao/estrutura: guardam um snapshot da formatacao ANTIGA.
# ACEITAR = remover a marca (mantem a formatacao atual);
# REJEITAR = trocar a formatacao atual pela antiga do snapshot.
FMT_CHANGE = {
    W + "pPrChange", W + "rPrChange", W + "tblPrChange", W + "tcPrChange",
    W + "trPrChange", W + "sectPrChange", W + "tblGridChange",
}

# Marcadores legados/estruturais e de faixa: sempre apenas removidos (raros).
DROP_MARK = {
    W + "numberingChange", W + "cellIns", W + "cellDel", W + "cellMerge",
    W + "moveFromRangeStart", W + "moveFromRangeEnd",
    W + "moveToRangeStart", W + "moveToRangeEnd",
    W + "customXmlInsRangeStart", W + "customXmlInsRangeEnd",
    W + "customXmlDelRangeStart", W + "customXmlDelRangeEnd",
    W + "customXmlMoveFromRangeStart", W + "customXmlMoveFromRangeEnd",
    W + "customXmlMoveToRangeStart", W + "customXmlMoveToRangeEnd",
}

# Marcadores de comentario dentro do corpo do documento.
COMMENT_MARK = {
    W + "commentRangeStart", W + "commentRangeEnd", W + "commentReference",
}

# Partes do pacote que carregam texto do documento (corpo, cabecalhos, notas).
def _e_parte_documento(nome):
    n = nome.lower()
    if not n.startswith("word/") or not n.endswith(".xml"):
        return False
    base = n[len("word/"):]
    if base == "document.xml" or base == "footnotes.xml" or base == "endnotes.xml":
        return True
    if base.startswith("header") and base.endswith(".xml"):
        return True
    if base.startswith("footer") and base.endswith(".xml"):
        return True
    return False

# Partes de comentario: sao esvaziadas por completo.
PARTES_COMENTARIO = {
    "word/comments.xml", "word/commentsextended.xml", "word/commentsids.xml",
    "word/commentsextensible.xml", "word/threadedcomments.xml",
}

# app.xml: elementos que identificam a origem.
APP_STRIP = {
    "Application", "AppVersion", "Company", "Manager", "Template",
    "TotalTime", "HyperlinkBase",
}


# ===========================================================================
# Transformacoes de DOCX
# ===========================================================================
def _desembrulhar(parent, child):
    """Substitui 'child' pelos seus filhos, na mesma posicao."""
    idx = parent.index(child)
    for sub in list(child):
        child.remove(sub)
        parent.insert(idx, sub)
        idx += 1
    parent.remove(child)


def _restaurar_formatacao_antiga(props_parent, change):
    """REJEITAR mudanca de formatacao: troca a formatacao atual pela antiga.
    'change' (ex.: w:rPrChange) e filho de 'props_parent' (ex.: w:rPr) e contem
    um snapshot completo das propriedades antigas."""
    antigo = None
    for c in change:
        antigo = c  # o snapshot e o primeiro elemento filho do *Change
        break
    props_parent.remove(change)
    if antigo is None:
        return
    for c in list(props_parent):
        props_parent.remove(c)
    for c in list(antigo):
        props_parent.append(c)


def _limpar_corpo(xml_bytes, aceitar=False):
    """Resolve revisoes e remove marcadores de comentario num part de corpo.
    aceitar=False (padrao) REJEITA as revisoes (volta ao texto original);
    aceitar=True as ACEITA. Retorna (novo_xml_bytes, n_revisoes, n_comentarios)."""
    root = etree.fromstring(xml_bytes)
    stats = {"rev": 0, "com": 0}

    def recurse(parent):
        for child in list(parent):
            if child.getparent() is not parent:
                continue  # ja foi removido/movido por uma acao anterior
            tag = child.tag

            if tag in COMMENT_MARK:
                parent.remove(child)
                stats["com"] += 1
                continue

            if tag in DROP_MARK:
                parent.remove(child)
                stats["rev"] += 1
                continue

            if tag in FMT_CHANGE:
                if aceitar:
                    parent.remove(child)          # mantem a formatacao atual
                else:
                    _restaurar_formatacao_antiga(parent, child)  # volta a antiga
                stats["rev"] += 1
                continue

            if tag in INS:
                recurse(child)
                if aceitar:
                    _desembrulhar(parent, child)  # mantem o inserido
                else:
                    parent.remove(child)          # descarta o inserido
                stats["rev"] += 1
                continue

            if tag in DEL:
                recurse(child)
                if aceitar:
                    parent.remove(child)          # descarta o deletado
                else:
                    # restaura: delText/delInstrText voltam a ser texto normal
                    for el in child.iter():
                        if el.tag == W + "delText":
                            el.tag = W + "t"
                        elif el.tag == W + "delInstrText":
                            el.tag = W + "instrText"
                    _desembrulhar(parent, child)
                stats["rev"] += 1
                continue

            recurse(child)

    recurse(root)
    out = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    return out, stats["rev"], stats["com"]


def _limpar_core(xml_bytes):
    """Esvazia core.xml. Retorna (novo_xml, {campo: valor_removido})."""
    root = etree.fromstring(xml_bytes)
    removidos = {}
    for child in list(root):
        ln = etree.QName(child).localname
        if child.text and child.text.strip():
            removidos[ln] = child.text.strip()
        root.remove(child)
    out = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    return out, removidos


def _limpar_app(xml_bytes):
    """Remove de app.xml os elementos que identificam a origem.
    Retorna (novo_xml, {campo: valor_removido})."""
    root = etree.fromstring(xml_bytes)
    removidos = {}
    for child in list(root):
        ln = etree.QName(child).localname
        if ln in APP_STRIP:
            if child.text and child.text.strip():
                removidos[ln] = child.text.strip()
            root.remove(child)
    out = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    return out, removidos


CUSTOM_VAZIO = (
    b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'
    b'<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/custom-properties" '
    b'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"/>'
)


def _contar_props_custom(xml_bytes):
    try:
        root = etree.fromstring(xml_bytes)
        return len(list(root))
    except Exception:
        return 0


def _contar_comentarios(xml_bytes):
    """Numero de comentarios e autores em comments.xml."""
    try:
        root = etree.fromstring(xml_bytes)
        comentarios = [c for c in root if etree.QName(c).localname == "comment"]
        autores = set()
        for c in comentarios:
            a = c.get(W + "author")
            if a:
                autores.add(a)
        return len(comentarios), sorted(autores)
    except Exception:
        return 0, []


COMMENTS_VAZIO = (
    b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'
    b'<w:comments xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'
)


def limpar_docx(origem, destino, aceitar_revisoes=False):
    """Le origem (.docx), grava destino (_limpo.docx) sem metadados.
    Retorna dict de relatorio."""
    rel = {"core": {}, "app": {}, "custom": 0, "comentarios": 0,
           "autores_comentario": [], "revisoes": 0}

    zin = zipfile.ZipFile(origem, "r")
    buf = io.BytesIO()
    zout = zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED)

    for item in zin.infolist():
        nome = item.filename
        nlow = nome.lower()
        dados = zin.read(nome)

        if nlow == "docprops/core.xml":
            dados, rel["core"] = _limpar_core(dados)
        elif nlow == "docprops/app.xml":
            dados, rel["app"] = _limpar_app(dados)
        elif nlow == "docprops/custom.xml":
            rel["custom"] = _contar_props_custom(dados)
            dados = CUSTOM_VAZIO
        elif nlow == "word/comments.xml":
            n, autores = _contar_comentarios(dados)
            rel["comentarios"] += n
            rel["autores_comentario"] = autores
            dados = COMMENTS_VAZIO
        elif nlow in PARTES_COMENTARIO:
            # demais partes de comentario: descarta o conteudo
            dados = (b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'
                     b'<root/>')
        elif _e_parte_documento(nome):
            dados, nrev, ncom = _limpar_corpo(dados, aceitar=aceitar_revisoes)
            rel["revisoes"] += nrev
            rel["comentarios"] += ncom

        # Normaliza o timestamp da entrada do zip (evita vazar hora de edicao).
        novo = zipfile.ZipInfo(nome, date_time=(1980, 1, 1, 0, 0, 0))
        novo.compress_type = zipfile.ZIP_DEFLATED
        novo.external_attr = item.external_attr
        zout.writestr(novo, dados)

    zin.close()
    zout.close()
    Path(destino).write_bytes(buf.getvalue())
    return rel


# ===========================================================================
# Transformacao de PDF
# ===========================================================================
def _pdf_tem_js(doc):
    try:
        cat = doc.pdf_catalog()
        for key in ("Names/JavaScript", "OpenAction", "AA"):
            t, _v = doc.xref_get_key(cat, key)
            if t not in (None, "null"):
                return True
    except Exception:
        pass
    return False


def _pdf_anexos(doc):
    try:
        return list(doc.embfile_names())
    except Exception:
        try:
            return list(range(doc.embfile_count()))
        except Exception:
            return []


def limpar_pdf(origem, destino):
    """Le origem (.pdf), grava destino (_limpo.pdf) sem metadados.
    Retorna dict de relatorio."""
    rel = {"info": {}, "xmp": False, "anexos": 0, "javascript": False,
           "protegido": False}

    doc = fitz.open(str(origem))
    if doc.needs_pass:
        if not doc.authenticate(""):
            rel["protegido"] = True
            doc.close()
            return rel

    # Relatorio (antes de limpar)
    meta = doc.metadata or {}
    rel["info"] = {k: v for k, v in meta.items()
                   if v and k not in ("format", "encryption")}
    try:
        rel["xmp"] = bool(doc.xref_xml_metadata()) if hasattr(doc, "xref_xml_metadata") else False
    except Exception:
        rel["xmp"] = False
    rel["anexos"] = len(_pdf_anexos(doc))
    rel["javascript"] = _pdf_tem_js(doc)

    # Limpeza. scrub() e o metodo dedicado de sanitizacao do PyMuPDF; se ausente,
    # cai no metodo manual. Nao mexemos em conteudo visivel nem em links.
    if hasattr(doc, "scrub"):
        try:
            doc.scrub(
                metadata=True, xml_metadata=True, javascript=True,
                embedded_files=True, attached_files=True,
                hidden_text=False, clean_pages=False, remove_links=False,
                reset_fields=False, reset_responses=False, thumbnails=True,
                redactions=False,
            )
        except TypeError:
            # assinaturas mais antigas de scrub aceitam menos parametros
            doc.scrub()
    else:
        for nome in _pdf_anexos(doc):
            try:
                doc.embfile_del(nome)
            except Exception:
                pass
        try:
            cat = doc.pdf_catalog()
            for key in ("Names/JavaScript", "OpenAction", "AA"):
                try:
                    doc.xref_set_key(cat, key, "null")
                except Exception:
                    pass
        except Exception:
            pass

    # Reforco: zera Info e XMP explicitamente (o scrub ja faz, mas garantimos).
    try:
        doc.set_metadata({})
    except Exception:
        pass
    try:
        doc.del_xml_metadata()
    except Exception:
        pass

    doc.save(str(destino), garbage=4, deflate=True, clean=True)
    doc.close()

    # Verificacao: reabre e, se sobrou algo no Info, limpa e regrava uma vez.
    try:
        chk = fitz.open(str(destino))
        resto = {k: v for k, v in (chk.metadata or {}).items()
                 if v and k not in ("format", "encryption")}
        if resto:
            chk.set_metadata({})
            chk.del_xml_metadata()
            tmp = str(destino) + ".tmp"
            chk.save(tmp, garbage=4, deflate=True, clean=True)
            chk.close()
            Path(tmp).replace(destino)
        else:
            chk.close()
    except Exception:
        pass

    return rel


# ===========================================================================
# Orquestracao
# ===========================================================================
def destino_de(origem):
    origem = Path(origem)
    return origem.with_name(origem.stem + "_limpo" + origem.suffix)


def converter_doc_para_docx(origem, destino_docx):
    """Converte um .doc binario em .docx usando o Word (COM), sem alterar o original.

    Grava em destino_docx. Levanta RuntimeError com mensagem clara se o Word nao
    estiver disponivel. Garante que o Word seja encerrado mesmo em caso de erro.
    """
    if _win32 is None:
        raise RuntimeError(
            "para limpar arquivos .doc e preciso o Word instalado e o pacote pywin32 "
            "(pip install pywin32). Alternativa: abra no Word e salve como .docx.")
    origem = Path(origem).resolve()
    destino_docx = Path(destino_docx).resolve()
    wdFormatDocumentDefault = 16  # .docx
    word = None
    doc = None
    try:
        word = _win32.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = False
        # ConfirmConversions=False evita caixas de dialogo de conversao
        doc = word.Documents.Open(str(origem), ConfirmConversions=False,
                                  ReadOnly=True, AddToRecentFiles=False)
        doc.SaveAs(str(destino_docx), FileFormat=wdFormatDocumentDefault)
        doc.Close(False)
        doc = None
    except Exception as e:
        raise RuntimeError("falha ao converter .doc no Word: %s" % e)
    finally:
        try:
            if doc is not None:
                doc.Close(False)
        except Exception:
            pass
        try:
            if word is not None:
                word.Quit()
        except Exception:
            pass


def _scrub_ole_metadados(path):
    """Zera os fluxos de metadados de um .doc (OLE2), substituindo
    \\x05SummaryInformation e \\x05DocumentSummaryInformation por um conjunto de
    propriedades VAZIO do MESMO tamanho (o olefile so reescreve streams de tamanho
    identico). Remove datas, nome do software, template, revisao e residuos.
    """
    import struct
    try:
        import olefile
    except Exception:
        raise RuntimeError(
            "pacote 'olefile' ausente: nao e possivel higienizar o .doc no nivel do "
            "arquivo (pip install olefile).")

    def _vazio(original):
        n = len(original)
        bo    = original[0:2]      # ordem de bytes (0xFFFE)
        ver   = original[2:4]
        osv   = original[4:8]
        clsid = original[8:24]
        fmtid = original[28:44]    # 1o FMTID (identifica Summary vs DocSummary)
        header = bo + ver + osv + clsid + struct.pack('<I', 1)  # 1 property set
        offset = len(header) + 16 + 4                            # apos FMTID+offset
        body = fmtid + struct.pack('<I', offset)
        section = struct.pack('<I', 8) + struct.pack('<I', 0)    # size=8, numprops=0
        novo = header + body + section
        return novo[:n] if len(novo) > n else novo + b'\x00' * (n - len(novo))

    ole = olefile.OleFileIO(path, write_mode=True)
    try:
        for nome in ('\x05SummaryInformation', '\x05DocumentSummaryInformation'):
            if ole.exists(nome):
                raw = ole.openstream(nome).read()
                ole.write_stream(nome, _vazio(raw))
    finally:
        ole.close()


def converter_docx_para_doc(origem_docx, destino_doc):
    """Salva um .docx (ja limpo) como .doc SEM metadados identificadores.

    Fluxo: Word abre o .docx, aplica RemoveDocumentInformation (remove autor,
    "salvo por", historico e info pessoal, inclusive a lista SttbSavedBy do fluxo
    Table que o file() nao mostra), salva como .doc; em seguida o scrub OLE2 zera
    os fluxos de metadados restantes (datas, software, template, revisao).
    """
    if _win32 is None:
        raise RuntimeError(
            "para gerar .doc limpo e preciso o Word instalado e o pacote pywin32.")
    origem_docx = Path(origem_docx).resolve()
    destino_doc = Path(destino_doc).resolve()
    wdFormatDocument = 0   # .doc binario
    wdRDIAll = 99          # remove TODAS as informacoes do documento
    word = None
    doc = None
    try:
        word = _win32.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = False
        doc = word.Documents.Open(str(origem_docx), ReadOnly=True,
                                  AddToRecentFiles=False)
        try:
            doc.RemoveDocumentInformation(wdRDIAll)
        except Exception:
            pass  # nao fatal: o scrub OLE2 abaixo e a garantia final
        for prop in ("Author", "Last Author", "Company", "Manager", "Title",
                     "Subject", "Keywords", "Comments", "Category"):
            try:
                doc.BuiltInDocumentProperties(prop).Value = ""
            except Exception:
                pass
        doc.SaveAs(str(destino_doc), FileFormat=wdFormatDocument)
        doc.Close(False)
        doc = None
    except Exception as e:
        raise RuntimeError("falha ao gerar .doc no Word: %s" % e)
    finally:
        try:
            if doc is not None:
                doc.Close(False)
        except Exception:
            pass
        try:
            if word is not None:
                word.Quit()
        except Exception:
            pass
    # garantia final, no nivel do arquivo
    _scrub_ole_metadados(destino_doc)


def alvos(caminho):
    caminho = Path(caminho)
    if caminho.is_file():
        return [caminho]
    achados = []
    for p in sorted(caminho.rglob("*")):
        if p.suffix.lower() in (".docx", ".pdf", ".doc") and not p.stem.endswith("_limpo"):
            achados.append(p)
    return achados


def _rel_docx(rel):
    linhas = []
    core = rel["core"]
    if core:
        rotulos = {"creator": "autor", "lastModifiedBy": "modificado por",
                   "created": "data de criacao", "modified": "data de modificacao",
                   "revision": "revisao", "title": "titulo", "subject": "assunto",
                   "keywords": "palavras-chave", "description": "descricao",
                   "category": "categoria", "lastPrinted": "ultima impressao"}
        for k, v in core.items():
            linhas.append("    - %s: %s" % (rotulos.get(k, k), v))
    app = rel["app"]
    for k, v in app.items():
        linhas.append("    - %s (app): %s" % (k, v))
    if rel["custom"]:
        linhas.append("    - propriedades personalizadas removidas: %d" % rel["custom"])
    if rel["comentarios"]:
        aut = ("; autores: " + ", ".join(rel["autores_comentario"])
               if rel["autores_comentario"] else "")
        linhas.append("    - comentarios removidos: %d%s" % (rel["comentarios"], aut))
    if not linhas:
        linhas.append("    - (nenhum metadado identificador encontrado)")
    return linhas


def _rel_pdf(rel):
    linhas = []
    if rel.get("protegido"):
        return ["    - PROTEGIDO POR SENHA: nao foi possivel abrir. Remova a senha e tente de novo."]
    info = rel["info"]
    rotulos = {"author": "autor", "creator": "criador (software)",
               "producer": "produtor", "title": "titulo", "subject": "assunto",
               "keywords": "palavras-chave", "creationDate": "data de criacao",
               "modDate": "data de modificacao", "trapped": "trapped"}
    for k, v in info.items():
        linhas.append("    - %s: %s" % (rotulos.get(k, k), v))
    if rel["xmp"]:
        linhas.append("    - fluxo XMP: removido")
    if rel["anexos"]:
        linhas.append("    - anexos embutidos removidos: %d" % rel["anexos"])
    if rel["javascript"]:
        linhas.append("    - JavaScript embutido: removido")
    if not linhas:
        linhas.append("    - (nenhum metadado identificador encontrado)")
    return linhas


def main():
    ap = argparse.ArgumentParser(
        description="Remove metadados de documentos finais (.doc, .docx e .pdf)")
    ap.add_argument("caminho", help="arquivo .doc/.docx/.pdf ou pasta")
    ap.add_argument("--aceitar-revisoes", action="store_true",
                    help="ACEITA as revisoes (padrao: REJEITA, volta ao texto original)")
    args = ap.parse_args()
    aceitar = args.aceitar_revisoes

    caminho = Path(args.caminho)
    if not caminho.exists():
        print("%sCaminho nao encontrado: %s%s" % (Fore.RED, caminho, Style.RESET_ALL))
        sys.exit(1)

    arqs = alvos(caminho)
    if not arqs:
        print("%sNenhum .docx ou .pdf encontrado.%s" % (Fore.RED, Style.RESET_ALL))
        sys.exit(1)

    print("\n%s=== Limpeza de metadados (offline) ===%s" % (Fore.CYAN, Style.RESET_ALL))
    print("Arquivos: %d\n" % len(arqs))

    ok, falhas = 0, 0
    com_revisoes = []
    criados = []
    for f in arqs:
        dest = destino_de(f)
        print("%sLimpando:%s %s" % (Fore.YELLOW, Style.RESET_ALL, f.name))
        temps = []
        try:
            suf = f.suffix.lower()
            if suf == ".docx":
                if etree is None:
                    raise RuntimeError("lxml ausente: nao e possivel limpar .docx")
                rel = limpar_docx(f, dest, aceitar_revisoes=aceitar)
                for l in _rel_docx(rel):
                    print(l)
                if rel["revisoes"]:
                    com_revisoes.append(f.name)
                    acao = "ACEITAS" if aceitar else "REJEITADAS (voltou ao texto original)"
                    print("    %s! REVISOES %s (%d marcas): reconfira o texto da peca.%s"
                          % (Fore.RED, acao, rel["revisoes"], Style.RESET_ALL))
            elif suf == ".doc":
                # .doc antigo: converte p/ .docx, limpa (rejeita revisoes/tira metadados),
                # regrava como .doc SEM metadados e faz o scrub OLE2 final.
                if etree is None:
                    raise RuntimeError("lxml ausente: nao e possivel limpar .doc")
                print("    %s(convertendo e higienizando .doc via Word...)%s"
                      % (Fore.CYAN, Style.RESET_ALL))
                t1 = dest.with_name(dest.stem + "_c1.docx"); temps.append(t1)
                t2 = dest.with_name(dest.stem + "_c2.docx"); temps.append(t2)
                converter_doc_para_docx(f, t1)
                rel = limpar_docx(t1, t2, aceitar_revisoes=aceitar)
                converter_docx_para_doc(t2, dest)
                for l in _rel_docx(rel):
                    print(l)
                if rel["revisoes"]:
                    com_revisoes.append(f.name)
                    acao = "ACEITAS" if aceitar else "REJEITADAS (voltou ao texto original)"
                    print("    %s! REVISOES %s (%d marcas): reconfira o texto da peca.%s"
                          % (Fore.RED, acao, rel["revisoes"], Style.RESET_ALL))
            else:
                if fitz is None:
                    raise RuntimeError("PyMuPDF (fitz) ausente: nao e possivel limpar .pdf")
                rel = limpar_pdf(f, dest)
                for l in _rel_pdf(rel):
                    print(l)
                if rel.get("protegido"):
                    falhas += 1
                    continue
            print("    %s-> salvo em: %s%s" % (Fore.GREEN, dest.resolve(), Style.RESET_ALL))
            criados.append(dest.resolve())
            ok += 1
        except Exception as e:
            print("    %sERRO: %s%s" % (Fore.RED, e, Style.RESET_ALL))
            falhas += 1
        finally:
            for t in temps:
                try:
                    Path(t).unlink()
                except Exception:
                    pass
        print()

    print("%sResultado:%s %d limpo(s), %d falha(s)."
          % (Fore.CYAN, Style.RESET_ALL, ok, falhas))
    if com_revisoes:
        acao = "ACEITO" if aceitar else "REJEITADO (texto voltou ao original)"
        print("%sATENCAO: estes arquivos tinham controle de alteracoes, que foi "
              "%s. Reconfira o texto:%s" % (Fore.RED, acao, Style.RESET_ALL))
        for n in com_revisoes:
            print("  - " + n)
    if criados:
        print("\n%sONDE FICARAM OS ARQUIVOS LIMPOS%s (na MESMA pasta do original, "
              "com sufixo _limpo):" % (Fore.CYAN, Style.RESET_ALL))
        for c in criados:
            print("  %s%s%s" % (Fore.GREEN, c, Style.RESET_ALL))
        pastas = sorted({str(c.parent) for c in criados})
        print("\n%sPasta(s):%s" % (Fore.CYAN, Style.RESET_ALL))
        for p in pastas:
            print("  %s" % p)
    print("\nLEMBRETE: a copia limpa mantem o formato do original "
          "(*_limpo.doc / *_limpo.docx / *_limpo.pdf); o original nao foi alterado.")


if __name__ == "__main__":
    main()
