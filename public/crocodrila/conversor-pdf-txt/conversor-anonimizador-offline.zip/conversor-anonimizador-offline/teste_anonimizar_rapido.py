#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
teste_anonimizar_rapido.py -- testes rapidos (segundos) do anonimizar.py

Roda com o Python da venv do projeto:
  .venv\\Scripts\\python.exe teste_anonimizar_rapido.py

Complementa teste_anonimizar.py (que leva ~5 min por causa do caso de 1M chars).
Cada caso escreve um .txt pequeno, roda processar() e confere o que DEVE sumir
e o que DEVE permanecer.
"""
import re
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import anonimizar as anon  # noqa: E402

# (nome, texto, deve_sumir, deve_ficar, usa_ner, opcoes)
CASOS = [
    # ---------- item 1: pronome de tratamento nao pode blindar o nome ----------
    ("honorifico Sra.",
     "A testemunha Sra. Ana Lúcia Ferreira Gomes depôs em audiência.",
     ["Ana", "Lúcia", "Ferreira", "Gomes"], ["testemunha"], True, None),
    ("honorifico Dr.",
     "O advogado Dr. Pedro Henrique Albuquerque protestou.",
     ["Pedro", "Henrique", "Albuquerque"], ["advogado"], True, None),
    ("honorifico Exmo. Sr.",
     "O Exmo. Sr. Marcelo Tavares Brandão foi intimado.",
     ["Marcelo", "Tavares", "Brandão"], [], True, None),
    ("honorifico Eng. vira iniciais limpas",
     "Perito: Eng. Carlos Alberto Nogueira apresentou o laudo.",
     ["Carlos", "Alberto", "Nogueira", "E.."], ["C.A.N."], True, None),
    ("instituicao preservada",
     "Recorre ao Tribunal de Justiça do Estado de São Paulo o autor João Batista Moreira.",
     ["Batista", "Moreira"], ["Tribunal de Justiça do Estado de São Paulo"], True, None),

    # ---------- item 4: ruido cosmetico ----------
    ("sem ponto duplo apos iniciais",
     "Relator: Des. Otávio Bressane Neto. Voto nº 12.",
     ["Bressane", ".."], [], True, None),
    ("'filho' solto nao vira inicial",
     "O magistrado Dr. Roberto Mendonça Filho decidiu. O filho do casal estuda.",
     ["Mendonça"], ["O filho do casal"], True, None),
    ("marcas e redes nao sao pessoa",
     "Proprietária do veículo VW Gol e do Fiat Argo, com perfil no Instagram.",
     [], ["VW Gol", "Fiat Argo", "Instagram"], True, None),

    # ---------- reforco nao pode propagar palavra comum para o texto todo ----------
    ("reforco ignora palavras comuns vindas de OCR em caixa alta",
     "PACIENTE COM DOR EM MMSS. SUTURA POR PLANOS. NAO REAGENTE.\n"
     "Tabela: Valor Original | Valor Atual\n"
     "A parte não compareceu em juízo, por isso o valor original do documento foi mantido, "
     "com base em prova que consta dos autos. O réu José Ribamar Fontes negou em depoimento.\n"
     "Recibo assinado por José Ribamar Fontes em cartório. Fontes voltou a negar.",
     ["Ribamar", "Fontes"],
     ["não compareceu em juízo, por isso o valor original do documento foi mantido",
      "com base em prova que consta dos autos", "negou em depoimento", "em cartório"],
     True, None),

    ("reforco nao invade 'Sao Paulo' por causa de pessoa chamada Paulo",
     "O autor Paulo Roberto Nunes reside em São Paulo. Paulo pediu a tutela. "
     "Comarca de São Paulo, Foro Central.",
     ["Roberto", "Nunes"], ["São Paulo", "Comarca de São Paulo"], True, None),
    ("numero colado ao 'nº' (sem espaco) e tarjado",
     "Processo de nº1000000-11.2023.8.26.0100; CPF nº123.456.789-01; RG nº12.345.678-9",
     ["1000000-11.2023.8.26.0100", "123.456.789-01", "12.345.678-9"], [], False, {"processo"}),

    # ---------- achados do teste em autos reais (24/09/2026) ----------
    ("nome em lista (um por linha) nao e protegido como LUGAR",
     "04/12/2019 13:52:19\nNagina Maria Queiroz\nN\nAnotação Enfermagem\n"
     "04/12/2019 23:47:25\nGicelia de Souza Leite\nN\n149273\nEvolução Médica\n",
     ["Nagina", "Queiroz", "Gicelia", "Souza Leite"], ["Anotação Enfermagem", "Evolução Médica"], True, None),
    ("sobrenome igual a palavra de instituicao (Camara) em entidade PESSOA",
     "O advogado Néri Torres Câmara sustentou oralmente perante a Décima Câmara Cível. "
     "A Câmara Municipal de São Paulo foi oficiada.",
     ["Néri", "Torres"], ["Décima Câmara Cível", "Câmara Municipal de São Paulo"], True, None),
    ("palavra de instituicao no MEIO do nome, com quebra de linha (caso real)",
     "deveres estes bem demonstrados em artigo do \nilustre advogado e médico especialista em "
     "direito médico, Néri Tadeu Câmara \nSouza, o qual aduz que a obrigação é de meio.",
     ["Néri", "Tadeu"], ["advogado e médico"], True, None),
    ("sobrenome Camara com inicial no meio, sem entidade PESSOA do spaCy",
     "Conforme leciona o ilustre advogado e médico especialista em direito médico, Néri T. Câmara, "
     "a responsabilidade é subjetiva. A 5ª Câmara de Direito Privado assim decidiu.",
     ["Néri"], ["5ª Câmara de Direito Privado"], True, None),
    ("lugar 'inventado' pela copia Title Case nao blinda autor citado",
     "(TJSP, Rel. Osvaldo de Oliveira, j. 31.08.2011). " + chr(10) + "No mesmo diapasão, leciona Arruda Alvim: " + chr(10) +
     "“Cabe ao juiz deferir as provas necessárias”. A comarca de Ribeirão Preto é competente.",
     ["Arruda", "Alvim", "Osvaldo"], ["Ribeirão Preto"], True, None),
    ("primeiro nome Marco nao e confundido com o mes de marco",
     "Relator Ministro Marco Buzzi, julgado em 15 de março de 2021. Marco Aurélio Mello também votou.",
     ["Buzzi", "Aurélio", "Mello"], ["15 de março de 2021"], True, None),

    # ---------- achados do processo real de 11/11/2026 (dados ficticios) ----------
    ("nome em CAIXA ALTA rotulado como lugar, prenome = marca, sobrenome = palavra comum",
     "EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DE UMA DAS VARAS DE\n"
     "FAMÍLIA E SUCESSÕES DA COMARCA DE SÃO CARLOS — SP.\n"
     "HORTENCIA MERCEDES BIANCHI MAXIMO, brasileira, casada, do\n"
     "lar, residente e domiciliada em São Carlos/SP,\n"
     "por intermédio da Defensoria Pública do Estado de São Paulo, vem à presença de Vossa "
     "Excelência propor AÇÃO DE DIVÓRCIO\n"
     "LITIGIOSO em face de RODOLFO AUGUSTO PRADO MAXIMO, argentino, casado, nascido dia\n"
     "5 de abril de 1972, filho de Anselmo Duarte Maximo e Marta Prado Leme,\n"
     "demais dados qualificativos ignorados. O prazo máximo é de 15 dias.\n"
     "Requerente: Hortencia Mercedes Bianchi Maximo. Requerido: Rodolfo Augusto Prado Maximo.\n",
     ["HORTENCIA", "MERCEDES", "BIANCHI", "MAXIMO", "Maximo", "Mercedes", "RODOLFO", "Anselmo"],
     ["São Carlos/SP", "prazo máximo"], True, None),
    ("sobrenome igual a termo forense (Morais) nao derruba nem escapa do nome",
     "Advogado(a): MARIO MENDES MORAIS DE SOUSA\n"
     "O advogado Mario Mendes Morais de Sousa requereu indenização por danos morais.\n"
     "Advogado(a): MARIO MENDES MORAIS DE SOUSA\n",
     ["MORAIS", "Morais", "MENDES", "Mendes"], ["danos morais"], True, None),
    ("sobrenome igual a palavra comum em mencao solta",
     "A requerente Vera Lúcia Prado Maximo foi ouvida. Em seguida, a Sra. Maximo "
     "confirmou o endereço. O valor máximo da multa foi mantido.",
     ["Maximo"], ["valor máximo"], True, None),
    ("e-mail com '@' trocado pelo OCR ou perdido",
     "e-mail fulanadetal(Ogmail.com , residente; contato beltrano.silvahotmail.com e "
     "ciclano(a)uol.com.br",
     ["fulanadetal", "beltrano", "ciclano"], ["residente"], False, None),
    ("numero do endereco com 4 digitos sem ponto",
     "residente na Rua das Acácias, nº 2874, Residencial Primavera, e na Av. Brasil, 12345, Centro",
     ["2874", "12345"], ["Rua das Acácias", "Residencial Primavera"], False, None),
    ("numero do endereco quando o nome da rua quebra de linha",
     "residente e domiciliada na Rua Bento\n\nTeixeira, nº 2874, Residencial Primavera.\n\n"
     "Mora em rua sem saída\n\n3. DO DIREITO",
     ["2874"], ["3. DO DIREITO"], False, None),
    ("vocabulario de formulario nao vira sobrenome por vizinhanca",
     "Assinado por Clara Nunes Barreto Data: 03/02/2020. Certidão de Casamento anexa.\n"
     "Requerente: Clara Nunes Barreto Processo digital. A Data do ato e a Certidão constam dos autos.",
     ["Nunes", "Barreto"], ["Data: 03/02/2020", "Certidão de Casamento", "A Data do ato e a Certidão"],
     True, None),
    ("sobrenome solto rotulado como lugar de uma palavra nao escapa do reforco",
     "Juiz de Direito: Dr. Estevão Carvalho Bortolotto\nVistos.\n"
     "assinado digitalmente por Estevão Carvalho Bortolotto, liberado nos autos.\n"
     "O réu foi citado por edital (fls. 47), Bortolotto, sendo-lhe nomeado Curador Especial.\n"
     " Bortolotto, Os embargos são tempestivos. Comarca de Ribeirão Preto.",
     ["Bortolotto", "Carvalho"], ["Ribeirão Preto", "citado por edital"], True, None),
    ("OAB com hifen entre a UF e o numero",
     "Dra. Fulana - OAB SP - 123456 e OAB SP – 98765DN",
     ["123456", "98765"], [], False, None),
    ("CPF com separadores de OCR",
     "CPF 123.456.789 - 09; CPF 123. 456. 789-09; CPF 123.456.789–09; CPF 123.456.789/09; "
     "CPF nº 123.456.789-\n09; CPF 123,456,789-09",
     ["789"], [], False, None),
    ("CPF com letra no lugar de digito (so com a palavra CPF antes)",
     "inscrita no CPF/MF sob o nº 123.456.789-O9 e CPF: l23.456.789-09",
     ["789"], [], False, None),
    ("valor em reais nao e confundido com CPF",
     "condenação de R$ 123.456.789,00 e área de 123.456,78 m²",
     [], ["123.456.789,00", "123.456,78"], False, None),
    ("registro de estrangeiro, CNH e Renavam",
     "portador do RNM nº B123456-T, CNH nº 01234567890, Renavam: 912345678, RNE V123456-7",
     ["B123456", "01234567890", "912345678", "V123456"], ["portador"], False, None),
    ("placa lida errado pelo OCR e CEP com ponto",
     "veículo placa EEMOF45, Centro, 13.560-120 - São Carlos/SP",
     ["EEMOF45", "13.560-120"], ["Centro"], False, None),

    # ---------- item 2: padroes estruturados ----------
    ("RG sem prefixo RG",
     "portador da cédula de identidade nº 12.345.678-9 SSP/SP",
     ["12.345.678-9"], [], False, None),
    ("CPF em grafia de OCR",
     "CPF 123456789-01 e CPF: 123 456 789 01 e CPF 123.456.789 01",
     ["123456789-01", "123 456 789 01", "123.456.789 01"], [], False, None),
    ("PIS/PASEP",
     "PIS/PASEP 123.45678.90-1",
     ["123.45678.90-1"], [], False, None),
    ("titulo de eleitor",
     "título de eleitor nº 1234 5678 9012, zona 001",
     ["1234 5678 9012", "9012"], ["zona 001"], False, None),
    ("CTPS",
     "CTPS 1234567 série 0012-SP",
     ["1234567", "0012"], [], False, None),
    ("cartao SUS",
     "Cartão SUS 123 4567 8901 2345",
     ["4567 8901", "2345"], [], False, None),
    ("passaporte",
     "passaporte FA123456",
     ["FA123456"], [], False, None),
    ("placas antiga e Mercosul",
     "placa ABC-1234, placa BRA2E19",
     ["ABC-1234", "BRA2E19"], [], False, None),
    ("conta e agencia",
     "conta corrente nº 12.345-6, agência 0123, Banco Itaú S.A.",
     ["12.345-6", "0123"], ["Banco Itaú"], False, None),
    ("beneficio INSS",
     "benefício INSS NB 123.456.789-0",
     ["123.456.789-0"], [], False, None),
    ("matriculas",
     "matrícula funcional 123.456-7; matrícula do imóvel nº 123.456 do 4º CRI",
     ["123.456-7", "123.456"], ["CRI"], False, None),
    ("OAB em varias grafias",
     "OAB/SP 123.456; OAB-SP 345678; OAB nº 234567/SP; OAB/SP 98.765",
     ["123.456", ".456", "345678", "234567", "98.765"], [], False, None),
    ("conselhos profissionais",
     "CRM-SP 123456; CRESS 12.345/SP; CREA-SP 0601234567; CRP 06/12345",
     ["123456", "12.345", "0601234567", "12345"], [], False, None),
    ("CNPJ alfanumerico",
     "CNPJ 12.ABC.345/01DE-35 e CNPJ 00.000.000/E08G-12 e CNPJ 12.345.678/0001-90",
     ["12.ABC.345/01DE-35", "00.000.000/E08G-12", "12.345.678/0001-90"], [], False, None),
    ("redes sociais",
     "perfil @mariasantos no Instagram, www.facebook.com/maria.santos.oliveira",
     ["mariasantos", "maria.santos"], [], False, None),
    ("IPTU / inscricao imobiliaria",
     "IPTU contribuinte 012.345.0678-9; inscrição imobiliária nº 123456789",
     ["012.345.0678-9", "123456789"], ["IPTU"], False, None),
    ("telefone com DDD e nove separados por espaco",
     "WhatsApp +55 11 9 8765 4321, tel. 11 9 8765-4321",
     ["11 9 8765", "8765-4321"], [], False, None),
    ("numero e complemento do endereco",
     "residente na Rua das Acácias, nº 1.234, apto. 45, Jardim Paulista, São Paulo/SP",
     ["1.234", "apto. 45"], ["Rua das Acácias", "Jardim Paulista"], False, None),

    # ---------- nao-regressao: citacoes legais e valores ficam ----------
    ("citacoes legais intactas",
     "Lei nº 8.078/90, Voto nº 12.345, arts. 1.694 e 1.699 do Código Civil, "
     "fls. 234/256, R$ 1.500,00, julgado em 24/09/2026, Tema 1.076 do STJ.",
     [], ["8.078/90", "Voto nº 12.345", "1.694 e 1.699", "fls. 234/256",
          "R$ 1.500,00", "24/09/2026", "Tema 1.076"], False, None),

    # ---------- item 3: flags opcionais ----------
    ("processo mantido por padrao",
     "Processo nº 1002345-67.2024.8.26.0100",
     [], ["1002345-67.2024.8.26.0100"], False, None),
    ("processo tarjado com flag",
     "Processo nº 1002345-67.2024.8.26.0100 e 10023456720248260100",
     ["1002345-67.2024.8.26.0100", "10023456720248260100"], [], False, {"processo"}),
    ("nascimento mantido por padrao",
     "nascido em 12/03/1978",
     [], ["12/03/1978"], False, None),
    ("nascimento tarjado com flag, julgamento fica",
     "nascido em 12/03/1978, data de nascimento: 05/05/2015, DN 1º de maio de 1990, "
     "julgado em 24/09/2026",
     ["12/03/1978", "05/05/2015", "1º de maio de 1990"], ["24/09/2026"], False, {"nascimento"}),
]


def rodar(texto, nlp, opcoes):
    with tempfile.TemporaryDirectory() as tmp:
        alvo = Path(tmp) / "caso.txt"
        alvo.write_text(texto, encoding="utf-8")
        if opcoes:
            saida, _mapa, _n = anon.processar(alvo, [], nlp, agressivo=True, opcoes=opcoes)
        else:
            saida, _mapa, _n = anon.processar(alvo, [], nlp, agressivo=True)
        return saida.read_text(encoding="utf-8")


def testar_uniao_de_candidatos():
    """Dois candidatos sobrepostos (um comeca antes, o outro termina depois, com
    o sobrenome) viram UM: antes o segundo era descartado e o sobrenome sobrava."""
    texto = "Divórcio Litigioso\n\nHORTENCIA BIANCHI MAXIMO, já qualificada"
    a = texto.index("Divórcio")
    b = texto.index("HORTENCIA")
    spans = [(a, texto.index(" MAXIMO"), "NOME_AUTO", "D.L.H.B.", texto[a:texto.index(" MAXIMO")]),
             (b, texto.index(","), "NOME_AUTO", "H.B.M.", texto[b:texto.index(",")])]
    unidos = anon._unir_sobrepostos(spans, texto)
    saida, _mapa = anon.aplicar(texto, anon.resolver(unidos))
    return [] if "MAXIMO" not in saida and "já qualificada" in saida else ["vazou 'MAXIMO': %r" % saida]


# Palavras-chave que abrem um padrao estruturado. Em formulario com o campo em
# branco, a palavra vem seguida de um bloco enorme de espacos e de nenhum numero.
_CHAVES_TEMPO = [
    "CPF", "CPF/MF sob o", "CPF nº", "CNPJ", "RG", "RG nº", "identidade", "RNM", "CNH",
    "CNH registro nº", "renavam", "cartão SUS", "CNS", "título de eleitor", "PIS", "NB",
    "benefício", "OAB", "OAB SP", "CRM", "CTPS", "passaporte", "placa", "agência",
    "conta corrente nº", "c/c", "matrícula", "matrícula do imóvel nº", "IPTU",
    "inscrição municipal", "CEP", "telefone", "rua das Flores", "rua das Flores,",
    "av. Brasil nº", "nascimento", "data de nascimento", "nascido em", "e-mail",
]
_CODIGO_TEMPO = r"""
import sys, time
sys.path.insert(0, sys.argv[1])
import anonimizar as A
chaves = sys.argv[2].split("|")
itens = list(A.PADROES) + list(A.PADROES_OPCIONAIS.values())
# o mesmo padrao no motor alternativo (modulo regex), usado no Python 3.10
if A.ure is not A.re:
    itens += [(i[0] + "/regex", A._compilar(i[1].pattern, i[1].flags, motor=A.ure)) for i in list(itens)]
brancos =[" " * 3000, " \n" * 1500, "\t \n " * 750]
for item in itens:
    for ch in chaves:
        for br in brancos:
            for fim in ("x", ""):
                print("INICIO %s | %r" % (item[0], ch), flush=True)
                t = time.perf_counter()
                for _ in item[1].finditer("texto " + ch + br + fim):
                    pass
                dt = time.perf_counter() - t
                if dt > 1.0:
                    print("LENTO %s | %r | %.1f s" % (item[0], ch, dt), flush=True)
print("FIM", flush=True)
"""


def testar_tempo_com_blocos_de_espaco(limite=60):
    """Nenhum padrao pode travar quando a palavra-chave ("CPF", "RG", "conta"...)
    vem seguida de milhares de espacos sem numero depois. Caso real de 26/11/2026:
    "CPF" + 3.103 espacos deixou o anonimizador rodando por horas (retrocesso
    catastrofico em quatro \\s* encadeados). Roda em subprocesso com limite de
    tempo, para o proprio teste nunca travar."""
    import subprocess
    cmd = [sys.executable, "-c", _CODIGO_TEMPO, str(Path(__file__).parent), "|".join(_CHAVES_TEMPO)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=limite)
        saida, estourou = r.stdout, False
        if r.returncode != 0:
            return ["subprocesso falhou: %s" % r.stderr.strip()[-300:]]
    except subprocess.TimeoutExpired as e:
        saida = e.stdout or ""
        if isinstance(saida, bytes):
            saida = saida.decode("utf-8", "replace")
        estourou = True
    linhas = saida.splitlines()
    erros = [l for l in linhas if l.startswith("LENTO")]
    if estourou:
        inicios = [l for l in linhas if l.startswith("INICIO")]
        erros.append("nao terminou em %d s; travou em: %s"
                     % (limite, inicios[-1][7:] if inicios else "?"))
    elif "FIM" not in linhas:
        erros.append("subprocesso terminou sem concluir")
    return erros


def testar_motor_alternativo():
    """No Python 3.10 os padroes sao compilados pelo modulo regex (o re so ganhou
    o quantificador possessivo no 3.11). Os dois motores tem de tarjar exatamente
    os mesmos trechos em todos os textos dos casos."""
    if anon.ure is anon.re:
        return ["modulo regex ausente (pip install regex)"]
    corpus = "\n".join(c[1] for c in CASOS)
    erros = []
    for item in list(anon.PADROES) + list(anon.PADROES_OPCIONAIS.values()):
        outro = anon._compilar(item[1].pattern, item[1].flags, motor=anon.ure)
        grupo = item[2] if len(item) > 2 else None
        a = [anon._span_padrao(m, grupo) for m in item[1].finditer(corpus)]
        b = [anon._span_padrao(m, grupo) for m in outro.finditer(corpus)]
        if a != b:
            erros.append("%s: re achou %d, regex achou %d" % (item[0], len(a), len(b)))
    return erros


def main():
    falhas = 0
    try:
        erros = testar_motor_alternativo()
    except AttributeError as e:
        erros = [str(e)]
    if erros:
        falhas += 1
        print("FALHA [motor alternativo (Python 3.10) tarja os mesmos trechos]: %s" % "; ".join(erros))
    else:
        print("ok    [motor alternativo (Python 3.10) tarja os mesmos trechos]")
    erros = testar_tempo_com_blocos_de_espaco()
    if erros:
        falhas += 1
        print("FALHA [nenhum padrao trava com bloco de espacos apos a palavra-chave]: %s"
              % "; ".join(erros))
    else:
        print("ok    [nenhum padrao trava com bloco de espacos apos a palavra-chave]")
    if "--so-tempo" in sys.argv:
        sys.exit(1 if falhas else 0)
    precisa_ner = any(c[4] for c in CASOS)
    nlp = anon.carregar_nlp("lg") if precisa_ner else None
    try:
        erros = testar_uniao_de_candidatos()
    except AttributeError as e:
        erros = [str(e)]
    if erros:
        falhas += 1
        print("FALHA [uniao de candidatos sobrepostos]: %s" % "; ".join(erros))
    else:
        print("ok    [uniao de candidatos sobrepostos]")
    for nome, texto, sumir, ficar, usa_ner, opcoes in CASOS:
        try:
            out = rodar(texto, nlp if usa_ner else None, opcoes)
        except TypeError as e:  # assinatura antiga (sem opcoes)
            print("FALHA [%s]: %s" % (nome, e))
            falhas += 1
            continue
        erros = []
        for s in sumir:
            if s in out:
                erros.append("vazou %r" % s)
        for f in ficar:
            if f not in out:
                erros.append("sumiu indevidamente %r" % f)
        if erros:
            falhas += 1
            print("FALHA [%s]: %s" % (nome, "; ".join(erros)))
            print("    saida: %s" % out.strip().replace("\n", " | "))
        else:
            print("ok    [%s]" % nome)
    print()
    if falhas:
        print("%d caso(s) FALHARAM." % falhas)
        sys.exit(1)
    print("OK: todos os %d casos passaram." % (len(CASOS) + 3))


if __name__ == "__main__":
    main()
