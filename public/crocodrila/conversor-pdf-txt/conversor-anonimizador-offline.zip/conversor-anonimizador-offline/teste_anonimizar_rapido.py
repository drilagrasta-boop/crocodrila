#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
teste_anonimizar_rapido.py -- testes rapidos (segundos) do anonimizar.py

Roda com o Python da venv do projeto:
  .venv\\Scripts\\python.exe teste_anonimizar_rapido.py

Complementa teste_anonimizar.py (que leva ~5 min por causa do caso de 1M chars).
Cada caso escreve um .txt pequeno, roda processar() e confere o que DEVE sumir
e o que DEVE permanecer.
"""
import re
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import anonimizar as anon  # noqa: E402

# (nome, texto, deve_sumir, deve_ficar, usa_ner, opcoes)
CASOS = [
    # ---------- item 1: pronome de tratamento nao pode blindar o nome ----------
    ("honorifico Sra.",
     "A testemunha Sra. Ana Lúcia Ferreira Gomes depôs em audiência.",
     ["Ana", "Lúcia", "Ferreira", "Gomes"], ["testemunha"], True, None),
    ("honorifico Dr.",
     "O advogado Dr. Pedro Henrique Albuquerque protestou.",
     ["Pedro", "Henrique", "Albuquerque"], ["advogado"], True, None),
    ("honorifico Exmo. Sr.",
     "O Exmo. Sr. Marcelo Tavares Brandão foi intimado.",
     ["Marcelo", "Tavares", "Brandão"], [], True, None),
    ("honorifico Eng. vira iniciais limpas",
     "Perito: Eng. Carlos Alberto Nogueira apresentou o laudo.",
     ["Carlos", "Alberto", "Nogueira", "E.."], ["C.A.N."], True, None),
    ("instituicao preservada",
     "Recorre ao Tribunal de Justiça do Estado de São Paulo o autor João Batista Moreira.",
     ["Batista", "Moreira"], ["Tribunal de Justiça do Estado de São Paulo"], True, None),

    # ---------- item 4: ruido cosmetico ----------
    ("sem ponto duplo apos iniciais",
     "Relator: Des. Otávio Bressane Neto. Voto nº 12.",
     ["Bressane", ".."], [], True, None),
    ("'filho' solto nao vira inicial",
     "O magistrado Dr. Roberto Mendonça Filho decidiu. O filho do casal estuda.",
     ["Mendonça"], ["O filho do casal"], True, None),
    ("marcas e redes nao sao pessoa",
     "Proprietária do veículo VW Gol e do Fiat Argo, com perfil no Instagram.",
     [], ["VW Gol", "Fiat Argo", "Instagram"], True, None),

    # ---------- reforco nao pode propagar palavra comum para o texto todo ----------
    ("reforco ignora palavras comuns vindas de OCR em caixa alta",
     "PACIENTE COM DOR EM MMSS. SUTURA POR PLANOS. NAO REAGENTE.\n"
     "Tabela: Valor Original | Valor Atual\n"
     "A parte não compareceu em juízo, por isso o valor original do documento foi mantido, "
     "com base em prova que consta dos autos. O réu José Ribamar Fontes negou em depoimento.\n"
     "Recibo assinado por José Ribamar Fontes em cartório. Fontes voltou a negar.",
     ["Ribamar", "Fontes"],
     ["não compareceu em juízo, por isso o valor original do documento foi mantido",
      "com base em prova que consta dos autos", "negou em depoimento", "em cartório"],
     True, None),

    ("reforco nao invade 'Sao Paulo' por causa de pessoa chamada Paulo",
     "O autor Paulo Roberto Nunes reside em São Paulo. Paulo pediu a tutela. "
     "Comarca de São Paulo, Foro Central.",
     ["Roberto", "Nunes"], ["São Paulo", "Comarca de São Paulo"], True, None),
    ("numero colado ao 'nº' (sem espaco) e tarjado",
     "Processo de nº1000000-11.2023.8.26.0100; CPF nº123.456.789-01; RG nº12.345.678-9",
     ["1000000-11.2023.8.26.0100", "123.456.789-01", "12.345.678-9"], [], False, {"processo"}),

    # ---------- achados do teste em autos reais (24/09/2026) ----------
    ("nome em lista (um por linha) nao e protegido como LUGAR",
     "04/12/2019 13:52:19\nNagina Maria Queiroz\nN\nAnotação Enfermagem\n"
     "04/12/2019 23:47:25\nGicelia de Souza Leite\nN\n149273\nEvolução Médica\n",
     ["Nagina", "Queiroz", "Gicelia", "Souza Leite"], ["Anotação Enfermagem", "Evolução Médica"], True, None),
    ("sobrenome igual a palavra de instituicao (Camara) em entidade PESSOA",
     "O advogado Néri Torres Câmara sustentou oralmente perante a Décima Câmara Cível. "
     "A Câmara Municipal de São Paulo foi oficiada.",
     ["Néri", "Torres"], ["Décima Câmara Cível", "Câmara Municipal de São Paulo"], True, None),
    ("palavra de instituicao no MEIO do nome, com quebra de linha (caso real)",
     "deveres estes bem demonstrados em artigo do \nilustre advogado e médico especialista em "
     "direito médico, Néri Tadeu Câmara \nSouza, o qual aduz que a obrigação é de meio.",
     ["Néri", "Tadeu"], ["advogado e médico"], True, None),
    ("sobrenome Camara com inicial no meio, sem entidade PESSOA do spaCy",
     "Conforme leciona o ilustre advogado e médico especialista em direito médico, Néri T. Câmara, "
     "a responsabilidade é subjetiva. A 5ª Câmara de Direito Privado assim decidiu.",
     ["Néri"], ["5ª Câmara de Direito Privado"], True, None),
    ("lugar 'inventado' pela copia Title Case nao blinda autor citado",
     "(TJSP, Rel. Osvaldo de Oliveira, j. 31.08.2011). " + chr(10) + "No mesmo diapasão, leciona Arruda Alvim: " + chr(10) +
     "“Cabe ao juiz deferir as provas necessárias”. A comarca de Ribeirão Preto é competente.",
     ["Arruda", "Alvim", "Osvaldo"], ["Ribeirão Preto"], True, None),
    ("primeiro nome Marco nao e confundido com o mes de marco",
     "Relator Ministro Marco Buzzi, julgado em 15 de março de 2021. Marco Aurélio Mello também votou.",
     ["Buzzi", "Aurélio", "Mello"], ["15 de março de 2021"], True, None),

    # ---------- item 2: padroes estruturados ----------
    ("RG sem prefixo RG",
     "portador da cédula de identidade nº 12.345.678-9 SSP/SP",
     ["12.345.678-9"], [], False, None),
    ("CPF em grafia de OCR",
     "CPF 123456789-01 e CPF: 123 456 789 01 e CPF 123.456.789 01",
     ["123456789-01", "123 456 789 01", "123.456.789 01"], [], False, None),
    ("PIS/PASEP",
     "PIS/PASEP 123.45678.90-1",
     ["123.45678.90-1"], [], False, None),
    ("titulo de eleitor",
     "título de eleitor nº 1234 5678 9012, zona 001",
     ["1234 5678 9012", "9012"], ["zona 001"], False, None),
    ("CTPS",
     "CTPS 1234567 série 0012-SP",
     ["1234567", "0012"], [], False, None),
    ("cartao SUS",
     "Cartão SUS 123 4567 8901 2345",
     ["4567 8901", "2345"], [], False, None),
    ("passaporte",
     "passaporte FA123456",
     ["FA123456"], [], False, None),
    ("placas antiga e Mercosul",
     "placa ABC-1234, placa BRA2E19",
     ["ABC-1234", "BRA2E19"], [], False, None),
    ("conta e agencia",
     "conta corrente nº 12.345-6, agência 0123, Banco Itaú S.A.",
     ["12.345-6", "0123"], ["Banco Itaú"], False, None),
    ("beneficio INSS",
     "benefício INSS NB 123.456.789-0",
     ["123.456.789-0"], [], False, None),
    ("matriculas",
     "matrícula funcional 123.456-7; matrícula do imóvel nº 123.456 do 4º CRI",
     ["123.456-7", "123.456"], ["CRI"], False, None),
    ("OAB em varias grafias",
     "OAB/SP 123.456; OAB-SP 345678; OAB nº 234567/SP; OAB/SP 98.765",
     ["123.456", ".456", "345678", "234567", "98.765"], [], False, None),
    ("conselhos profissionais",
     "CRM-SP 123456; CRESS 12.345/SP; CREA-SP 0601234567; CRP 06/12345",
     ["123456", "12.345", "0601234567", "12345"], [], False, None),
    ("CNPJ alfanumerico",
     "CNPJ 12.ABC.345/01DE-35 e CNPJ 00.000.000/E08G-12 e CNPJ 12.345.678/0001-90",
     ["12.ABC.345/01DE-35", "00.000.000/E08G-12", "12.345.678/0001-90"], [], False, None),
    ("redes sociais",
     "perfil @mariasantos no Instagram, www.facebook.com/maria.santos.oliveira",
     ["mariasantos", "maria.santos"], [], False, None),
    ("IPTU / inscricao imobiliaria",
     "IPTU contribuinte 012.345.0678-9; inscrição imobiliária nº 123456789",
     ["012.345.0678-9", "123456789"], ["IPTU"], False, None),
    ("telefone com DDD e nove separados por espaco",
     "WhatsApp +55 11 9 8765 4321, tel. 11 9 8765-4321",
     ["11 9 8765", "8765-4321"], [], False, None),
    ("numero e complemento do endereco",
     "residente na Rua das Acácias, nº 1.234, apto. 45, Jardim Paulista, São Paulo/SP",
     ["1.234", "apto. 45"], ["Rua das Acácias", "Jardim Paulista"], False, None),

    # ---------- nao-regressao: citacoes legais e valores ficam ----------
    ("citacoes legais intactas",
     "Lei nº 8.078/90, Voto nº 12.345, arts. 1.694 e 1.699 do Código Civil, "
     "fls. 234/256, R$ 1.500,00, julgado em 24/09/2026, Tema 1.076 do STJ.",
     [], ["8.078/90", "Voto nº 12.345", "1.694 e 1.699", "fls. 234/256",
          "R$ 1.500,00", "24/09/2026", "Tema 1.076"], False, None),

    # ---------- item 3: flags opcionais ----------
    ("processo mantido por padrao",
     "Processo nº 1002345-67.2024.8.26.0100",
     [], ["1002345-67.2024.8.26.0100"], False, None),
    ("processo tarjado com flag",
     "Processo nº 1002345-67.2024.8.26.0100 e 10023456720248260100",
     ["1002345-67.2024.8.26.0100", "10023456720248260100"], [], False, {"processo"}),
    ("nascimento mantido por padrao",
     "nascido em 12/03/1978",
     [], ["12/03/1978"], False, None),
    ("nascimento tarjado com flag, julgamento fica",
     "nascido em 12/03/1978, data de nascimento: 05/05/2015, DN 1º de maio de 1990, "
     "julgado em 24/09/2026",
     ["12/03/1978", "05/05/2015", "1º de maio de 1990"], ["24/09/2026"], False, {"nascimento"}),
]


def rodar(texto, nlp, opcoes):
    with tempfile.TemporaryDirectory() as tmp:
        alvo = Path(tmp) / "caso.txt"
        alvo.write_text(texto, encoding="utf-8")
        if opcoes:
            saida, _mapa, _n = anon.processar(alvo, [], nlp, agressivo=True, opcoes=opcoes)
        else:
            saida, _mapa, _n = anon.processar(alvo, [], nlp, agressivo=True)
        return saida.read_text(encoding="utf-8")


def main():
    precisa_ner = any(c[4] for c in CASOS)
    nlp = anon.carregar_nlp("lg") if precisa_ner else None
    falhas = 0
    for nome, texto, sumir, ficar, usa_ner, opcoes in CASOS:
        try:
            out = rodar(texto, nlp if usa_ner else None, opcoes)
        except TypeError as e:  # assinatura antiga (sem opcoes)
            print("FALHA [%s]: %s" % (nome, e))
            falhas += 1
            continue
        erros = []
        for s in sumir:
            if s in out:
                erros.append("vazou %r" % s)
        for f in ficar:
            if f not in out:
                erros.append("sumiu indevidamente %r" % f)
        if erros:
            falhas += 1
            print("FALHA [%s]: %s" % (nome, "; ".join(erros)))
            print("    saida: %s" % out.strip().replace("\n", " | "))
        else:
            print("ok    [%s]" % nome)
    print()
    if falhas:
        print("%d caso(s) FALHARAM." % falhas)
        sys.exit(1)
    print("OK: todos os %d casos passaram." % len(CASOS))


if __name__ == "__main__":
    main()
