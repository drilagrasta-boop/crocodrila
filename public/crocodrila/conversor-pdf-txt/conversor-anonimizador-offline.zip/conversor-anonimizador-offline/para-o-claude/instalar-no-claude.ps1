# instalar-no-claude.ps1
# Copia a skill "pdf-para-txt-offline" para o Claude Code desta conta
# e confere se o conversor e o OCR Tesseract estao prontos.
# Rodar DEPOIS do instalar.ps1 principal.

$ErrorActionPreference = "Stop"
$origem   = Join-Path $PSScriptRoot "pdf-para-txt-offline"
$destBase = Join-Path $HOME ".claude\skills"
$destino  = Join-Path $destBase "pdf-para-txt-offline"
$python   = "C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
$tess     = "C:\Program Files\Tesseract-OCR\tesseract.exe"
$problemas = 0

Write-Host ""
Write-Host "=== Ligando o conversor com OCR no Claude ===" -ForegroundColor Cyan

# 1. Conversor instalado?
if (Test-Path $python) {
    Write-Host "[OK] Conversor instalado" -ForegroundColor Green
} else {
    Write-Host "[FALTA] Conversor nao instalado. Rode primeiro o instalar.ps1 da pasta principal." -ForegroundColor Red
    $problemas++
}

# 2. Tesseract com portugues?
if (Test-Path $tess) {
    $langs = & $tess --list-langs 2>&1 | Out-String
    if ($langs -match "(?m)^por\s*$") {
        Write-Host "[OK] Tesseract com portugues" -ForegroundColor Green
    } else {
        Write-Host "[FALTA] Tesseract sem o idioma portugues (veja o PASSO 4 do COMECE-AQUI.txt)" -ForegroundColor Yellow
        $problemas++
    }
} else {
    Write-Host "[FALTA] Tesseract nao instalado (veja o PASSO 4 do COMECE-AQUI.txt)" -ForegroundColor Yellow
    $problemas++
}

# 3. Copiar a skill
if (-not (Test-Path $destBase)) { New-Item -ItemType Directory -Path $destBase -Force | Out-Null }
if (Test-Path $destino) {
    # backup FORA da pasta skills, senao o Claude ve duas skills com o mesmo nome
    $bakBase = Join-Path (Split-Path $destBase -Parent) "skills-backup"
    if (-not (Test-Path $bakBase)) { New-Item -ItemType Directory -Path $bakBase -Force | Out-Null }
    $bak = Join-Path $bakBase ("pdf-para-txt-offline-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Move-Item -Path $destino -Destination $bak
    Write-Host "[INFO] Ja existia uma versao da skill; guardada em $bak"
}
Copy-Item -Path $origem -Destination $destino -Recurse
if (Test-Path (Join-Path $destino "SKILL.md")) {
    Write-Host "[OK] Skill copiada para $destino" -ForegroundColor Green
} else {
    Write-Host "[ERRO] Nao consegui copiar a skill" -ForegroundColor Red
    $problemas++
}

Write-Host ""
if ($problemas -eq 0) {
    Write-Host "PRONTO. Feche e abra o Claude Code e peca: converte este PDF ..." -ForegroundColor Green
} else {
    Write-Host "Skill instalada, mas ha $problemas pendencia(s) acima. Resolva e rode de novo." -ForegroundColor Yellow
}
Write-Host ""
Read-Host "Aperte Enter para fechar"
