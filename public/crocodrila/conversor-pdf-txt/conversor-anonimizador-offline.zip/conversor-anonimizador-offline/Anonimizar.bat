@echo off
chcp 65001 >nul
title Anonimizar TXT - offline (segredo de justica)
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "APP=C:\claude-code-backup\pipeline_juridica\anonimizar.py"

set "ALVO=%~1"
if "%ALVO%"=="" set /p ALVO="Arraste a pasta ou o arquivo .txt para esta janela e tecle Enter: "
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%

echo.
echo Este anonimizador detecta os nomes de pessoas AUTOMATICAMENTE.
echo Para deteccao 100%% automatica, apenas tecle Enter (deixe em branco).
echo Se quiser REFORCAR nomes especificos, digite-os separados por ponto e virgula.
echo Exemplo: Joao Silva Souza; Maria Lima
set "NOMES="
set /p NOMES="Nomes (opcional): "

echo.
echo.
echo Tarjar TAMBEM o numero do processo e as datas de nascimento?
echo   S = sigilo total (texto que vai SAIR da sua maquina)
echo   N = manter (analise interna; e o padrao)
set "RESP="
set "SIGILO="
set /p RESP="Sigilo total? [S/N] (Enter = N): "
if /i "%RESP%"=="S" set "SIGILO=--sigilo-total"
echo.
"%VENV%" "%APP%" "%ALVO%" --nomes "%NOMES%" %SIGILO%

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A ANONIMIZACAO FALHOU. NENHUM ARQUIVO _anon.txt FOI GERADO.
    echo  Leia a mensagem de erro ACIMA antes de fechar esta janela.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo Terminado. O texto anonimizado esta no arquivo *_anon.txt
echo (o .txt original NAO e alterado).
echo Abra o arquivo _anon_mapa.txt e confira ANTES de usar a peca.
echo O mapa e sigiloso: nunca o envie junto com o texto anonimizado.
pause
