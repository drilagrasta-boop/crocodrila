@echo off
chcp 65001 >nul
title Converter PDF e Anonimizar - offline
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "CONVERTER=C:\claude-code-backup\pipeline_juridica\converter.py"
set "ANONIMIZAR=C:\claude-code-backup\pipeline_juridica\anonimizar.py"

set "ALVO=%~1"
if "%ALVO%"=="" set /p ALVO="Arraste o PDF ou pasta de PDFs para esta janela e tecle Enter: "
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%

echo.
echo ============================
echo  ETAPA 1: Converter PDF -^> TXT
echo ============================
echo.
"%VENV%" "%CONVERTER%" "%ALVO%"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A CONVERSAO FALHOU. A anonimizacao NAO sera executada.
    echo  Leia a mensagem de erro ACIMA antes de fechar esta janela.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo ============================
echo  ETAPA 2: Anonimizar TXT
echo ============================
echo.
echo Informe os nomes das partes, separados por ponto e virgula.
echo Exemplo: Joao Silva Souza; Maria Lima
echo (Deixe em branco para usar apenas deteccao automatica)
set "NOMES="
set /p NOMES="Nomes: "

echo.

rem Determinar pasta dos TXTs (mesma do PDF)
for %%A in ("%ALVO%") do (
    if exist "%%~A\" (
        set "PASTA_TXT=%ALVO%"
    ) else (
        set "PASTA_TXT=%%~dpA"
    )
)

echo.
echo Tarjar TAMBEM o numero do processo e as datas de nascimento?
echo   S = sigilo total (texto que vai SAIR da sua maquina)
echo   N = manter (analise interna; e o padrao)
set "RESP="
set "SIGILO="
set /p RESP="Sigilo total? [S/N] (Enter = N): "
if /i "%RESP%"=="S" set "SIGILO=--sigilo-total"
echo.
"%VENV%" "%ANONIMIZAR%" "%PASTA_TXT%" --nomes "%NOMES%" %SIGILO%

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A ANONIMIZACAO FALHOU. NENHUM ARQUIVO _anon.txt FOI GERADO.
    echo  Os .txt convertidos NAO estao anonimizados - nao os use
    echo  em ferramentas online. Leia a mensagem de erro ACIMA.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo ============================
echo  CONCLUIDO
echo ============================
echo.
echo Arquivos gerados:
echo   - *.txt           (texto extraido do PDF - AINDA COM NOMES)
echo   - *_anon.txt      (texto ANONIMIZADO - use este)
echo   - *_anon_mapa.txt (mapa de substituicoes - SIGILOSO)
echo.
echo IMPORTANTE: Confira o _anon_mapa.txt antes de usar a peca.
echo O mapa e sigiloso: NUNCA o envie junto com o texto anonimizado.
pause
