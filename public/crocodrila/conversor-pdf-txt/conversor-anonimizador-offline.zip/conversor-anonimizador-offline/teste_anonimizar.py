#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
teste_anonimizar.py -- testes de regressao do anonimizar.py

Roda com o Python da venv do projeto:
  .venv\\Scripts\\python.exe teste_anonimizar.py

Casos:
  1. Nome de pessoa no INICIO do arquivo e anonimizado (regressao).
  2. CPF e tarjado e instituicao (Tribunal) e preservada (regressao).
  3. Nome de pessoa que so aparece DEPOIS de 1.000.000 de caracteres
     tambem e anonimizado (documento nao pode ter "zona cega" de NER).
"""
import subprocess
import sys
import tempfile
from pathlib import Path

RAIZ = Path(__file__).parent
PYTHON = RAIZ / ".venv" / "Scripts" / "python.exe"
SCRIPT = RAIZ / "anonimizar.py"

NOME_INICIO = "Joao da Silva Pereira"
NOME_TARDIO = "Marcelo Antunes Bezerra"
FILLER = ("O presente feito tramita regularmente e aguarda as providencias "
          "de praxe, nos termos do que dispoe a legislacao aplicavel. ")


def montar_texto():
    partes = ["O requerente %s, CPF 123.456.789-00, compareceu perante o "
              "Tribunal de Justica de Sao Paulo.\n" % NOME_INICIO]
    tam = len(partes[0])
    while tam <= 1_050_000:
        partes.append(FILLER)
        tam += len(FILLER)
    partes.append("\nAo final, o senhor %s prestou depoimento como "
                  "testemunha do juizo.\n" % NOME_TARDIO)
    return "".join(partes)


def main():
    falhas = []
    with tempfile.TemporaryDirectory() as tmp:
        alvo = Path(tmp) / "peca_teste.txt"
        alvo.write_text(montar_texto(), encoding="utf-8")

        r = subprocess.run([str(PYTHON), str(SCRIPT), str(alvo)],
                           capture_output=True, text=True, timeout=3600)
        if r.returncode != 0:
            print(r.stdout)
            print(r.stderr)
            print("FALHA: anonimizar.py saiu com codigo %d" % r.returncode)
            sys.exit(1)

        saida = alvo.with_name("peca_teste_anon.txt")
        if not saida.exists():
            print("FALHA: arquivo _anon.txt nao foi gerado.")
            sys.exit(1)
        anon = saida.read_text(encoding="utf-8")

        # 1. nome do inicio anonimizado
        for palavra in ("Joao", "Pereira"):
            if palavra in anon:
                falhas.append("nome do INICIO vazou: '%s' presente na saida" % palavra)

        # 2. CPF tarjado, instituicao preservada
        if "123.456.789-00" in anon:
            falhas.append("CPF vazou na saida")
        if "Tribunal de Justica de Sao Paulo" not in anon:
            falhas.append("instituicao (Tribunal) foi indevidamente anonimizada")

        # 3. nome que so aparece apos 1M de caracteres anonimizado
        for palavra in ("Marcelo", "Antunes", "Bezerra"):
            if palavra in anon:
                falhas.append("nome TARDIO (apos 1M chars) vazou: '%s' presente na saida" % palavra)

    if falhas:
        for f in falhas:
            print("FALHA:", f)
        sys.exit(1)
    print("OK: todos os testes passaram.")


if __name__ == "__main__":
    main()
