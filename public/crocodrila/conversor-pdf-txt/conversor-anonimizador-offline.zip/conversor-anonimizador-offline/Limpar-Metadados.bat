@echo off
chcp 65001 >nul
title Limpar Metadados - documento final (.doc, .docx e .pdf)
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "APP=C:\claude-code-backup\pipeline_juridica\limpar_metadados.py"

set "ALVO=%~1"
if "%ALVO%"=="" set /p ALVO="Arraste o .doc/.docx/.pdf (ou uma pasta) para esta janela e tecle Enter: "
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%

echo.
echo === LIMPEZA DE METADADOS ===
echo Passo FINAL: use no documento pronto que voce vai protocolar (.doc, .docx ou PDF).
echo (.doc antigo e convertido para .docx no Word e depois limpo.)
echo Remove autor, datas, software, empresa, template, tempo de edicao,
echo comentarios e historico de revisoes.
echo As revisoes sao REJEITADAS: o texto volta ao original (insercoes desfeitas,
echo delecoes restauradas). Gera uma copia *_limpo; o original NAO e alterado.
echo.

"%VENV%" "%APP%" "%ALVO%"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A LIMPEZA FALHOU. NENHUM ARQUIVO *_limpo FOI GERADO.
    echo  Leia a mensagem de erro ACIMA antes de fechar esta janela.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo Terminado. Use o arquivo *_limpo para protocolar (o original NAO e alterado).
echo Se houver aviso de REVISOES REJEITADAS, reconfira o texto da peca.
pause
