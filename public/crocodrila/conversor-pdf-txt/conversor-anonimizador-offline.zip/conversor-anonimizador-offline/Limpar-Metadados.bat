@echo off
chcp 65001 >nul
title Limpar Metadados - documento final (.doc, .docx e .pdf)
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "APP=%~dp0limpar_metadados.py"

set "ALVO=%~1"
set "TENTATIVAS=0"
:PEDIR_ALVO
if defined ALVO goto ALVO_INFORMADO
if %TENTATIVAS% GEQ 3 (
    echo.
    echo Nenhum caminho foi informado. Abra o atalho de novo quando tiver o arquivo.
    pause
    exit /b 1
)
set /a TENTATIVAS+=1
set /p ALVO="Arraste o .doc/.docx/.pdf (ou uma pasta) para esta janela e tecle Enter: "
if not defined ALVO echo Nenhum caminho informado. Arraste o arquivo ou a pasta para esta janela e tecle Enter.
goto PEDIR_ALVO
:ALVO_INFORMADO
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%
if not defined ALVO goto PEDIR_ALVO

echo.
echo === LIMPEZA DE METADADOS ===
echo Passo FINAL: use no documento pronto que voce vai protocolar (.doc, .docx ou PDF).
echo (.doc antigo e convertido para .docx no Word e depois limpo.)
echo Remove autor, datas, software, empresa, template, tempo de edicao,
echo comentarios e historico de revisoes.
echo As revisoes sao REJEITADAS: o texto volta ao original (insercoes desfeitas,
echo delecoes restauradas). Gera uma copia *_limpo; o original NAO e alterado.
echo.

"%VENV%" "%APP%" "%ALVO%"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A LIMPEZA FALHOU. NENHUM ARQUIVO *_limpo FOI GERADO.
    echo  Leia a mensagem de erro ACIMA antes de fechar esta janela.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo Terminado. Use o arquivo *_limpo para protocolar (o original NAO e alterado).
echo Se houver aviso de REVISOES REJEITADAS, reconfira o texto da peca.
pause
