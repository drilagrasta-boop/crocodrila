#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""Regressao: pagina com camada de texto FRAGMENTADA nao pode passar como texto bom.

Caso real (processo de familia, 29/10/2026): o PDF das peticoes do apelante
gravava cada linha em varios objetos de texto pequenos. O PyMuPDF, sem
ordenacao, devolvia os pedacos na ordem interna do arquivo ("O " / "Ap" /
"pelante " / "ajuizou "), cada um numa linha. Como a pagina tinha mais de 100
caracteres, o conversor aceitava o texto embaralhado e nunca chamava o OCR.
353 das 662 paginas sairam ilegiveis.

Regra nova: pagina com texto suficiente MAS fragmentada (mediana do comprimento
das linhas <= 30 caracteres, com ao menos 8 linhas) e re-extraida com ordenacao
geometrica; se continuar fragmentada, vai para o OCR.

Run: python -m pytest -q test_converter_fragmentacao.py
"""
import sys
import tempfile
from pathlib import Path

import fitz
import pytest

sys.path.insert(0, str(Path(__file__).parent))
import converter  # noqa: E402

LINHAS_FRAGMENTADAS = [
    "O ", "Ap", "cumulada com partilha d", "visitas. ", "As pa",
    "2001, sob o regime da", "filhos, sendo que, ao i", "No ", "c",
    "documentais, testemunh", "acerca das condições do", "O ", "pr",
    "remanescente envolvia,", "aluguel e partilha de b", "Sobrev",
    "procedentes os pedidos", "pelante ", "ajuizou ", "ação ", "de ", "di",
    "de bens, oferta de alimentos e", "rtes contraíram matrimônio em",
    "comunhão parcial de bens, te", "nício da demanda, M.A.", "curso ",
    "da ", "demanda, ", "foram ", "p", "ais, estudos técnicos e pe",
    "s filhos T.F. e M.", "róprio ", "Juízo ", "reconheceu ", "que",
]
LINHA_NORMAL = ("Vistos. Trata-se de ação de divórcio cumulada com partilha de bens, "
                "oferta de alimentos e regulamentação de visitas.")


def test_parece_fragmentado_detecta_pagina_embaralhada():
    assert converter.parece_fragmentado("\n".join(LINHAS_FRAGMENTADAS)) is True


def test_parece_fragmentado_aceita_pagina_normal():
    assert converter.parece_fragmentado("\n".join([LINHA_NORMAL] * 20)) is False


def test_parece_fragmentado_ignora_pagina_com_poucas_linhas():
    # Cabecalho curto, tabela de 5 linhas etc.: pouco texto nao e evidencia.
    assert converter.parece_fragmentado("\n".join(LINHAS_FRAGMENTADAS[:5])) is False


def test_parece_fragmentado_nao_conta_carimbo_do_esaj():
    carimbo = ("Para conferir o original, acesse o site https://esaj.tjsp.jus.br/x, "
               "informe o processo 0000000-00.2026.8.26.0000 e código AbCd1234.\n"
               "Este documento é cópia do original, assinado digitalmente por F.M., "
               "protocolado em 01/01/2026 às 10:00 , sob o número 1234.\nfls. 7")
    # So carimbo e 3 linhas curtas: sem conteudo suficiente para julgar.
    assert converter.parece_fragmentado(carimbo + "\nOi\nlá\nx") is False


def _pdf_fragmentado(path):
    """Pagina cujo texto e inserido em pedacos fora da ordem de leitura.

    12 linhas visuais, cada uma em 3 trechos; os trechos sao gravados por coluna
    (todos os primeiros, depois os segundos, depois os terceiros), imitando o PDF
    real. Sem ordenacao, o PyMuPDF devolve 36 linhas curtas embaralhadas.
    """
    doc = fitz.open()
    page = doc.new_page()
    linhas = [("O Apelante", "ajuizou ação de", "divórcio litigioso")] * 4 + \
             [("As partes", "contraíram matrimônio", "em 2001 no regime")] * 4 + \
             [("Sobreveio", "sentença que julgou", "parcialmente os pedidos")] * 4
    xs = (72, 200, 360)
    for coluna in range(3):
        for i, trechos in enumerate(linhas):
            page.insert_text((xs[coluna], 100 + i * 20), trechos[coluna], fontsize=11)
    doc.save(str(path))


def test_converter_pdf_reordena_pagina_fragmentada_sem_ocr():
    with tempfile.TemporaryDirectory() as tmp:
        pdf = Path(tmp) / "fragmentado.pdf"
        _pdf_fragmentado(pdf)
        bruto = fitz.open(str(pdf))[0].get_text("text")
        assert converter.parece_fragmentado(bruto), "pre-condicao: extracao bruta deve sair fragmentada"

        texto, metodo, _ = converter.converter_pdf(pdf)

        primeira = next(l for l in texto.splitlines() if l.strip())
        assert "O Apelante" in primeira and "divórcio litigioso" in primeira, primeira
        assert not converter.parece_fragmentado(texto)
        assert "reordenad" in metodo.lower()
        assert "OCR" not in metodo


class _PaginaIncorrigivel:
    """Pagina cujo texto continua fragmentado mesmo com ordenacao geometrica."""
    rect = fitz.Rect(0, 0, 595, 842)

    def get_text(self, opcao="text", **kw):
        return "\n".join(LINHAS_FRAGMENTADAS)

    def get_pixmap(self, dpi=300):
        raise AssertionError("OCR nao deve ser chamado dentro de extrair_texto_embutido")


def test_extrair_texto_embutido_classifica_fragmentacao_incorrigivel():
    texto, status = converter.extrair_texto_embutido(_PaginaIncorrigivel())
    assert status == "fragmentado"
    assert texto.strip()  # devolve o melhor texto que tem, para o caso de OCR indisponivel


def test_extrair_texto_embutido_aceita_pagina_normal():
    doc = fitz.open()
    page = doc.new_page()
    page.insert_textbox(fitz.Rect(60, 80, 550, 700), (LINHA_NORMAL + " ") * 8, fontsize=11)
    texto, status = converter.extrair_texto_embutido(page)
    assert status == "ok"
    assert "divórcio" in texto
