#!/usr/bin/env python3
r"""Regression test: scanned pages carrying a court stamp must still be OCR'd.

e-SAJ stamps every page (scanned ones included) with ~400 chars of embedded
text ("Para conferir o original..."). The converter used to treat that stamp
as real content and skip OCR, silently losing the scanned pages.

Run: .venv\Scripts\python.exe teste_converter.py
"""
import sys
import tempfile
from pathlib import Path

import fitz

sys.path.insert(0, str(Path(__file__).parent))
import converter  # noqa: E402

STAMP = (
    "Para conferir o original, acesse o site https://esaj.tjsp.jus.br/pastadigital/sg/"
    "abrirConferenciaDocumento.do, informe o processo 0000000-00.2026.8.26.0000 e codigo AbCd1234.\n"
    "Este documento e copia do original, assinado digitalmente por FULANO DE TAL e Tribunal "
    "de Justica do Estado de Sao Paulo, protocolado em 01/01/2026 as 10:00 , sob o numero "
    "00000000020268260000.\nfls. 1"
)
SCANNED_WORDS = "PROCURACAO AD JUDICIA OUTORGANTE ZEBRAMARINHA"


def _scanned_page_png():
    """Render a text page to PNG bytes, simulating a scanned sheet."""
    src = fitz.open()
    page = src.new_page()
    page.insert_textbox(fitz.Rect(60, 80, 550, 400), SCANNED_WORDS, fontsize=28)
    return page.get_pixmap(dpi=150).tobytes("png")


def _build_pdf(path, with_stamp):
    doc = fitz.open()
    page = doc.new_page()
    page.insert_image(page.rect, stream=_scanned_page_png())
    if with_stamp:
        page.insert_textbox(fitz.Rect(10, 790, 590, 840), STAMP, fontsize=5)
    doc.save(str(path))


def run():
    falhas = 0
    with tempfile.TemporaryDirectory() as tmp:
        for with_stamp in (False, True):
            pdf = Path(tmp) / f"scan_{with_stamp}.pdf"
            _build_pdf(pdf, with_stamp)
            texto, metodo, _ = converter.converter_pdf(pdf)
            ok = "ZEBRAMARINHA" in texto.upper().replace(" ", "")
            if with_stamp:
                ok = ok and texto.count("fls. 1") == 1  # one page marker, not two
            print(f"[{'OK' if ok else 'FALHOU'}] pagina escaneada "
                  f"{'COM' if with_stamp else 'sem'} carimbo -> {metodo}")
            falhas += not ok
        # digital page with stamp: keep embedded text, no OCR, no duplication
        pdf = Path(tmp) / "digital.pdf"
        doc = fitz.open()
        page = doc.new_page()
        corpo = "Vistos. Trata-se de acao de divorcio consensual. " * 6
        page.insert_textbox(fitz.Rect(60, 80, 550, 700), corpo, fontsize=11)
        page.insert_textbox(fitz.Rect(10, 790, 590, 840), STAMP, fontsize=5)
        doc.save(str(pdf))
        for forcar in (False, True):
            texto, metodo, _ = converter.converter_pdf(pdf, forcar_ocr=forcar)
            ok = "divorcio" in texto and texto.count("fls. 1") == 1
            if not forcar:
                ok = ok and "OCR" not in metodo
            print(f"[{'OK' if ok else 'FALHOU'}] pagina digital COM carimbo "
                  f"(forcar_ocr={forcar}) -> {metodo}")
            falhas += not ok
    print("RESULTADO:", "tudo OK" if not falhas else f"{falhas} falha(s)")
    return falhas


if __name__ == "__main__":
    sys.exit(1 if run() else 0)
