@echo off
chcp 65001 >nul
title Anonimizar TXT - CLASSICO (conservador, menos ruido)
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "APP=C:\claude-code-backup\pipeline_juridica\anonimizar.py"

set "ALVO=%~1"
if "%ALVO%"=="" set /p ALVO="Arraste a pasta ou o arquivo .txt para esta janela e tecle Enter: "
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%

echo.
echo === MODO CLASSICO (conservador) ===
echo Anonimiza APENAS o que o modelo tem certeza que e pessoa. Gera menos ruido,
echo mas pode DEIXAR ESCAPAR nomes (grafia rara, texto em maiusculas, OCR ruim).
echo Use so em documentos DIGITAIS LIMPOS e sempre conferindo o mapa.
echo Se quiser garantir nomes, informe-os abaixo separados por ponto e virgula.
set "NOMES="
set /p NOMES="Nomes (opcional, recomendado neste modo): "

echo.
echo.
echo Tarjar TAMBEM o numero do processo e as datas de nascimento?
echo   S = sigilo total (texto que vai SAIR da sua maquina)
echo   N = manter (analise interna; e o padrao)
set "RESP="
set "SIGILO="
set /p RESP="Sigilo total? [S/N] (Enter = N): "
if /i "%RESP%"=="S" set "SIGILO=--sigilo-total"
echo.
"%VENV%" "%APP%" "%ALVO%" --classico --nomes "%NOMES%" %SIGILO%

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A ANONIMIZACAO FALHOU. NENHUM ARQUIVO _anon.txt FOI GERADO.
    echo  Leia a mensagem de erro ACIMA antes de fechar esta janela.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo Terminado. O texto anonimizado esta no arquivo *_anon.txt
echo (o .txt original NAO e alterado).
echo CONFIRA o _anon_mapa.txt ANTES de usar a peca.
echo O mapa e sigiloso: nunca o envie junto com o texto anonimizado.
pause
