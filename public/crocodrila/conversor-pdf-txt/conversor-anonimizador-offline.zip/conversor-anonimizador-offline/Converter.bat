@echo off
chcp 65001 >nul
title Converter PDF para TXT - offline
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "APP=%~dp0converter.py"

set "ALVO=%~1"
set "TENTATIVAS=0"
:PEDIR_ALVO
if defined ALVO goto ALVO_INFORMADO
if %TENTATIVAS% GEQ 3 (
    echo.
    echo Nenhum caminho foi informado. Abra o atalho de novo quando tiver o arquivo.
    pause
    exit /b 1
)
set /a TENTATIVAS+=1
set /p ALVO="Arraste o PDF ou pasta de PDFs para esta janela e tecle Enter: "
if not defined ALVO echo Nenhum caminho informado. Arraste o arquivo ou a pasta para esta janela e tecle Enter.
goto PEDIR_ALVO
:ALVO_INFORMADO
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%
if not defined ALVO goto PEDIR_ALVO

echo.
"%VENV%" "%APP%" "%ALVO%"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A CONVERSAO FALHOU. Leia a mensagem de erro ACIMA.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo Conversao concluida. Os arquivos .txt foram gerados ao lado dos PDFs.
pause
