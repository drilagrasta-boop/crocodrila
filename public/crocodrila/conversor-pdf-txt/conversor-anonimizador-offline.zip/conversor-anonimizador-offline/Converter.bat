@echo off
chcp 65001 >nul
title Converter PDF para TXT - offline
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "APP=C:\claude-code-backup\pipeline_juridica\converter.py"

set "ALVO=%~1"
if "%ALVO%"=="" set /p ALVO="Arraste o PDF ou pasta de PDFs para esta janela e tecle Enter: "
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%

echo.
"%VENV%" "%APP%" "%ALVO%"

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A CONVERSAO FALHOU. Leia a mensagem de erro ACIMA.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo Conversao concluida. Os arquivos .txt foram gerados ao lado dos PDFs.
pause
