#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
anonimizar.py  --  RECONSTRUCAO (validar antes de uso em segredo de justica)

Anonimiza arquivos .txt:
  - nomes informados em --nomes viram iniciais ("Joao Silva Souza" -> "J.S.S.")
  - dados estruturados viram tarja: CPF (inclusive grafias de OCR), CNPJ
    (numerico e alfanumerico), RG (com ou sem a sigla), OAB, registros em
    conselhos (CRM, CREA, CRESS...), PIS/NIT, titulo de eleitor, CTPS, cartao
    SUS, passaporte, placa, chassi, cartao de credito, conta/agencia, NB do
    INSS, matricula, CEP, e-mail, telefone, perfil de rede social e o numero/
    complemento do endereco (o logradouro fica)
  - com --tarjar-processo / --tarjar-nascimento / --sigilo-total, tambem o
    numero CNJ do processo e as datas de nascimento
  - nomes de pessoa detectados por spaCy viram iniciais (ver abaixo)

Gera, ao lado de cada .txt:
  <nome>_anon.txt       texto anonimizado
  <nome>_anon_mapa.txt  o que foi trocado (SIGILOSO: permite reidentificar)

Uso:
  python anonimizar.py "PASTA_OU_ARQUIVO.txt" --nomes "Joao Silva; Maria Lima" [--sem-ner] [--modelo lg|md]
                       [--tarjar-processo] [--tarjar-nascimento] [--sigilo-total]

LIMITACOES CONHECIDAS (leia):
  - O metodo confiavel e a lista --nomes. A detecao automatica (spaCy) e apenas
    rede de seguranca: pode falhar com grafias incomuns, e produz falsos positivos
    (por isso vem numa secao separada do mapa, para CONFERIR).
  - Nomes em CAIXA ALTA sao tratados via segundo passo NER sobre texto Title Case.
  - CPF cru de 11 digitos e telefone de 11 digitos sao ambiguos; ambos sao
    tarjados por seguranca, mas o rotulo no mapa pode nao ser exato.
  - Numeros crus fora de formato podem escapar. SEMPRE confira o _anon_mapa.txt.
  - Reconstrucao automatica. Nao substitui revisao humana da peca e do mapa.
"""
import argparse
import bisect
import re
import sys
import unicodedata
from pathlib import Path

try:
    import regex as ure  # limites de palavra unicode para nomes acentuados
except Exception:
    ure = re

try:
    import chardet
except Exception:
    chardet = None

CONECTIVOS = {"de", "da", "do", "das", "dos", "e", "di", "del", "van", "von", "y"}

# Conectivos que podem aparecer DENTRO de um nome (sem "e", que costuma separar
# dois nomes distintos: "Fulano E Beltrano").
PONTES_NOME = {"de", "da", "do", "das", "dos", "di", "del", "dal", "van", "von", "y"}

# Termos que o spaCy costuma marcar como pessoa mas nao sao nome proprio.
STOP_NER = {
    # Partes processuais
    "autor", "autora", "autores", "reu", "re", "ree", "reus", "requerente",
    "requerido", "requerida", "embargante", "embargado", "embargada",
    "apelante", "apelado", "apelada", "agravante", "agravado", "agravada",
    "exequente", "executado", "reclamante", "reclamada", "reclamado",
    "impetrante", "impetrado", "impetrada", "litisconsorte", "interveniente",
    "denunciante", "denunciado", "denunciada", "querelante", "querelado",
    # Tratamento e honorificos
    "advogado", "advogada", "advogados", "procurador", "procuradora",
    "dr", "dra", "drs", "dras", "sr", "sra", "srs", "sras",
    "senhor", "senhora", "senhores", "senhoras", "vossa", "excelencia",
    "exmo", "exma", "excelentissimo", "excelentissima", "meritissimo",
    "meritissima", "ilustrissimo", "ilustrissima", "eminente", "douto",
    # Cargos e funcoes
    "perito", "perita", "juiz", "juiza", "juizo", "desembargador",
    "desembargadora", "relator", "relatora", "ministro", "ministra",
    "promotor", "promotora", "testemunha", "curador", "curadora",
    "supervisor", "supervisora", "escrivao", "escriva",
    "oficial", "analista", "tecnico", "tecnica", "assessor", "assessora",
    "secretario", "secretaria", "delegado", "delegada", "defensor", "defensora",
    # Organizacao judiciaria
    "vara", "comarca", "tribunal", "camara", "turma", "secao",
    "orgao", "julgador", "julgadora", "origem", "foro", "instancia",
    "plenario", "corte", "gabinete",
    # Termos processuais / secoes de peca
    "sentenca", "acordao", "decisao", "despacho", "voto", "ementa",
    "sintese", "tempestividade", "cabimento", "merito", "dispositivo",
    "conclusao", "fundamentacao", "preliminar", "prejudicial", "relatorio",
    "danos", "morais", "materiais", "juros", "mora", "multa",
    "onus", "sucumbencial", "sucumbencia", "honorarios", "custas",
    "tutela", "liminar", "recursal", "provisoria", "antecipada",
    # Termos gerais que geram falso positivo
    "obras", "servico", "servicos", "reclamacao", "reclamacoes",
    # Siglas juridicas
    "cnpj", "cpf", "cpc", "cep", "oab", "rg", "stf", "stj", "tst",
    "tjsp", "tjrj", "tjmg", "tjrs", "cjf", "cnj",
}

# Palavras que denotam INSTITUICAO / ORGAO / EMPRESA / LUGAR.
# Se um "nome proprio" candidato contiver qualquer uma delas, e mantido (nao e pessoa).
STOP_INSTITUICAO = {
    # Judiciario / orgaos publicos
    "tribunal", "justica", "camara", "comarca", "foro", "juizo", "vara",
    "secao", "secretaria", "turma", "orgao", "poder", "judiciario", "estado",
    "municipio", "uniao", "fazenda", "prefeitura", "ministerio", "procuradoria",
    "defensoria", "assembleia", "conselho", "junta", "gabinete", "cartorio",
    # Pessoas juridicas privadas
    "associacao", "beneficente", "cooperativa", "sindicato", "federacao",
    "confederacao", "banco", "bancario", "caixa", "financeira", "seguradora",
    "seguros", "seguro", "companhia", "cia", "industria", "comercio",
    "servicos", "servico", "servidor", "ltda", "epp", "eireli", "sa",
    "empresa", "empreendimentos", "incorporadora", "construtora", "hospital",
    "clinica", "laboratorio", "universidade", "faculdade", "instituto",
    "fundacao", "igreja", "paroquia", "condominio", "espolio", "massa",
    "falida", "administradora", "distribuidora", "transportes", "logistica",
    # Autarquias / marcas comuns
    "inss", "previdencia", "receita", "detran", "senai", "sesc", "sesi",
    "telefonica", "vivo", "claro", "tim", "itau", "bradesco", "santander",
    "nubank", "sabesp", "enel", "eletropaulo", "cdhu", "correios",
    # Qualificadores institucionais
    "nacional", "municipal", "estadual", "federal", "publico", "publica",
    "regional", "central", "geral", "suprema",
    # Lugares (logradouros / divisao territorial)
    "rua", "avenida", "alameda", "praca", "rodovia", "travessa", "estrada",
    "bairro", "jardim", "vila", "distrito", "quadra", "lote", "brasil",
    "republica", "america", "sao",
}

# "marco" fica FORA: sem acento colide com o prenome Marco ("Ministro Marco
# Buzzi" vazava). O mes e reconhecido pela grafia com cedilha em considerar().
MESES = {"janeiro", "fevereiro", "abril", "maio", "junho", "julho",
         "agosto", "setembro", "outubro", "novembro", "dezembro"}

# Termos juridicos / de peca que aparecem capitalizados mas NAO sao nome de pessoa.
STOP_TERMOS = {
    "direito", "privado", "civel", "criminal", "familia", "penal", "trabalho",
    "registro", "autos", "recurso", "recursos", "pretensao", "declaratoria",
    "admissibilidade", "hipotese", "provimento", "conformidade", "sessao",
    "permanente", "virtual", "gratuita", "gratuito", "eletronica", "assinatura",
    "apelo", "apelacao", "agravo", "embargos", "mandado", "seguranca",
    "majoracao", "quantum", "indenizatorio", "reparacao", "importe", "alteracao",
    "incidencia", "teor", "vistos", "acordam", "deram", "negaram", "presidente",
    "revisor", "eminentes", "pares", "poder", "sumula", "tese", "repercussao",
    "geral", "repetitivo", "vencido", "vencedor", "divergencia", "obrigacao",
    # Leis / codigos / diplomas
    "codigo", "civil", "penal", "consumidor", "defesa", "credito", "reserva",
    "lei", "leis", "decreto", "constituicao", "processo", "processual", "tema",
    "provisoria", "medida", "portaria", "resolucao", "enunciado",
}

# Abreviacoes / siglas que o NER as vezes confunde com nome de pessoa.
ABREV = {"cc", "ncpc", "cpc", "cpp", "ctb", "clt", "cdc", "cf", "adct",
         "vu", "ss", "art", "arts", "inc", "par", "fls", "fl", "reg",
         "dje", "dj", "des", "desa", "min", "rel", "obs", "pag", "pags",
         "cnj", "eresp", "resp", "hc", "rms", "ms", "adi", "adc", "adpf"}

# Marcas, redes sociais e provedores que o NER confunde com pessoa
# ("VW Gol", "Instagram"). Sobrenomes plausiveis (Honda, Ford) ficam de fora.
MARCAS = {
    "vw", "volkswagen", "fiat", "chevrolet", "gm", "toyota", "hyundai", "renault",
    "jeep", "nissan", "peugeot", "citroen", "bmw", "mercedes", "audi", "kia",
    "mitsubishi", "yamaha", "suzuki", "volvo", "scania", "iveco",
    "instagram", "facebook", "whatsapp", "twitter", "linkedin", "tiktok",
    "youtube", "telegram", "gmail", "hotmail", "outlook", "yahoo", "uol",
    "google", "microsoft", "apple", "samsung", "motorola", "ifood", "uber",
    "netflix", "spotify", "amazon", "shopee", "aliexpress",
}

# Pronomes de tratamento, titulos, cargos e papeis processuais que costumam
# PRECEDER (ou seguir) o nome e que o spaCy inclui no mesmo span
# ("Sra. Ana Lucia Ferreira Gomes"). Sao APARADOS das pontas do candidato;
# nunca fazem o nome inteiro ser descartado (isso ja vazou nomes completos).
TRATAMENTO = {
    "dr", "dra", "drs", "dras", "sr", "sra", "srs", "sras", "srta", "exmo", "exma",
    "exmos", "exmas", "excelentissimo", "excelentissima", "meritissimo",
    "meritissima", "ilustrissimo", "ilustrissima", "eminente", "douto", "douta",
    "senhor", "senhora", "senhores", "senhoras", "vossa", "excelencia",
    "eng", "enga", "engo", "prof", "profa", "pe", "frei", "irma", "irmao", "dom",
    "dona", "me", "ma", "msc", "phd", "des", "desa", "min", "rel", "mm", "mmo",
    "engenheiro", "engenheira", "medico", "medica", "psicologo", "psicologa",
    "assistente", "social", "contador", "contadora", "arquiteto", "arquiteta",
    "juiz", "juiza", "desembargador", "desembargadora", "ministro", "ministra",
    "relator", "relatora", "revisor", "revisora", "promotor", "promotora",
    "procurador", "procuradora", "advogado", "advogada", "advogados",
    "perito", "perita", "testemunha", "testemunhas", "autor", "autora", "autores",
    "reu", "re", "ree", "reus", "requerente", "requerido", "requerida",
    "apelante", "apelado", "apelada", "agravante", "agravado", "agravada",
    "embargante", "embargado", "embargada", "exequente", "executado", "executada",
    "reclamante", "reclamado", "reclamada", "impetrante", "impetrado", "impetrada",
    "defensor", "defensora", "delegado", "delegada", "escrivao", "escriva",
    "oficial", "curador", "curadora", "genitor", "genitora", "menor", "interessado",
    "interessada", "recorrente", "recorrido", "recorrida", "vitima", "acusado",
    "acusada", "denunciado", "denunciada", "investigado", "investigada",
}

# Sufixos de nome que, SOZINHOS, nao identificam ninguem: nao entram no passe de
# reforco (senao "o filho do casal" vira "o F. do casal").
SUFIXOS_NOME = {"filho", "filha", "neto", "neta", "junior", "sobrinho", "segundo",
                "terceiro", "bisneto"}

# Conjunto unico usado para excluir candidatos a nome de pessoa.
EXCLUI_PESSOA = (STOP_NER | STOP_INSTITUICAO | MESES | STOP_TERMOS | ABREV | MARCAS)

# Palavras comuns do portugues (stopwords do spaCy + vocabulario de rodape/
# tabela de autos). NUNCA entram no passe de reforco: em prontuario/OCR em
# CAIXA ALTA o NER toma "EM MMSS" ou "Valor Original" por nome e, sem este
# filtro, cada "em" e "original" do processo virava inicial (texto ilegivel).
try:
    from spacy.lang.pt.stop_words import STOP_WORDS as _SW_PT
except Exception:  # spaCy ausente: --sem-ner ainda funciona
    _SW_PT = set()
PALAVRAS_COMUNS = {"".join(c for c in unicodedata.normalize("NFKD", w)
                           if not unicodedata.combining(c)).lower() for w in _SW_PT} | {
    "valor", "original", "atual", "anterior", "total", "documento", "documentos",
    "assinado", "assinada", "digitalmente", "acesse", "site", "informe", "codigo",
    "liberado", "liberada", "autos", "copia", "conferir", "pagina", "paginas", "fls",
    "consulta", "consultar", "consulte", "beneficiario", "beneficiaria", "dados",
    "cadastrais", "conta", "data", "hora", "status", "tipo", "descricao",
    "quantidade", "unidade", "item", "itens", "observacao", "observacoes", "nome",
    "endereco", "telefone", "email", "cidade", "estado", "cep", "bairro", "numero",
    "complemento", "paciente", "medico", "medica", "receita", "prescricao", "exame",
    "exames", "resultado", "resultados", "laudo", "cirurgia", "consentimento",
    "termo", "termos", "contrato", "boleto", "vencimento", "pagamento", "parcela",
    "parcelas", "juros", "multa", "saldo", "credito", "debito", "extrato", "recibo",
    "nota", "fiscal", "servico", "servicos", "produto", "produtos", "referencia",
    "assunto", "objeto", "pedido", "pedidos", "requerimento", "peticao", "inicial",
    "contestacao", "replica", "sentenca", "acordao", "decisao", "despacho",
    "certidao", "intimacao", "citacao", "mandado", "oficio", "publicacao",
    "julgamento", "audiencia", "sessao", "protocolo", "distribuicao", "classe",
    "assistente", "requerente", "requerido", "reclamante", "reclamada", "reagente",
    "positivo", "negativo", "normal", "alterado", "ausente", "presente", "sim", "nao",
}

# O que pode ser aparado das PONTAS de um candidato sem descarta-lo.
APARAVEL = TRATAMENTO | CONECTIVOS | ABREV | STOP_TERMOS | PALAVRAS_COMUNS


# Padroes estruturados. Cada item e (ROTULO, regex) ou (ROTULO, regex, "v"):
# com o grupo nomeado "v", so ESSE trecho e tarjado (a palavra-chave que o
# precede, como "agencia" ou "matricula", fica no texto para dar contexto).
# A ordem define prioridade em caso de empate de posicao e tamanho.
_N = r"(?:n\.?[\u00ba\u00b0o]?\.?\s*|n[\u00fau]mero\s*)?"      # "n\u00ba", "n.", "numero"
_I = re.IGNORECASE
PADROES = [
    ("EMAIL",    re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")),
    ("REDE_SOCIAL", re.compile(
        r"\b(?:https?://)?(?:www\.)?(?:facebook|fb|instagram|twitter|x|linkedin|"
        r"tiktok|youtube|threads|t)\.(?:com|me)(?:\.br)?/[A-Za-z0-9_./\-@]+"
        r"|(?<![\w@.])@[A-Za-z0-9_.]{3,30}(?<!\.)", _I)),
    # CNPJ numerico ou ALFANUMERICO (Receita Federal, desde 31/07/2026:
    # 12 posicoes alfanumericas + 2 digitos verificadores, ex. 00.000.000/E08G-12)
    ("CNPJ",     re.compile(
        r"(?<![A-Z0-9])[A-Z0-9]{2}\.[A-Z0-9]{3}\.[A-Z0-9]{3}/[A-Z0-9]{4}-\d{2}(?!\d)|(?<!\d)\d{14}(?!\d)"
        r"|(?<![A-Z0-9])(?=[A-Z0-9]{12}\d{2}(?![A-Z0-9]))(?=[A-Z0-9]*[A-Z])[A-Z0-9]{14}(?![A-Z0-9])")),
    # CPF: pontuado, cru, e nas grafias que o OCR produz (espaco/ponto no lugar do hifen)
    ("CPF",      re.compile(r"(?<!\d)\d{3}[.\s]?\d{3}[.\s]?\d{3}[-.\s]?\d{2}(?!\d)")),
    ("CHASSI",   re.compile(r"\b(?=[A-HJ-NPR-Z0-9]{17}\b)(?=[A-Z0-9]*[A-Z])[A-HJ-NPR-Z0-9]{17}\b")),
    ("CARTAO",   re.compile(r"(?<!\d)\d{4}[\s.]?\d{4}[\s.]?\d{4}[\s.]?\d{4}(?!\d)")),
    ("SUS",      re.compile(r"(?<!\d)\d{3}\s?\d{4}\s?\d{4}\s?\d{4}(?!\d)"
                            r"|\b(?:cart[\u00e3a]o\s+(?:do\s+)?SUS|CNS)\s*:?\s*" + _N + r"(?P<v>\d[\d\s.]{13,18}\d)", _I), "v"),
    ("TITULO_ELEITOR", re.compile(
        r"(?<!\d)\d{4}\s?\d{4}\s?\d{4}(?!\d)"
        r"|\bt[\u00edi]tulo\s+(?:de\s+)?eleit\w*\s*:?\s*" + _N + r"(?P<v>\d[\d\s.]{10,15}\d)", _I), "v"),
    ("PIS",      re.compile(r"(?<!\d)\d{3}\.\d{5}\.\d{2}-\d(?!\d)"
                            r"|\b(?:PIS|PASEP|NIT|NIS)\s*(?:/\s*PASEP)?\s*:?\s*" + _N + r"(?P<v>\d[\d.\s-]{9,14}\d)", _I), "v"),
    ("NB",       re.compile(r"(?<!\d)\d{3}\.\d{3}\.\d{3}-\d(?!\d)"
                            r"|\b(?:NB|benef[\u00edi]cio)\s*:?\s*" + _N + r"(?P<v>\d{3}\.?\d{3}\.?\d{3}-?\d)\b", _I), "v"),
    ("OAB",      re.compile(r"\bOAB\s*[/:\-]?\s*(?:[A-Z]{2}\s*)?[n\u00ba\u00b0o.:\s]*"
                            r"(?:\d{1,3}(?:\.?\d{3}){1,2}|\d{3,7})(?:\s*/\s*[A-Z]{2})?", _I)),
    ("REGISTRO_PROF", re.compile(
        r"\b(?:CRM|CREA|CRESS|CRP|CRO|CRC|COREN|CRF|CRMV|CRA|CRN|CREF|CRB|CRQ|CRECI|"
        r"CRT|CRBM|CORECON|CAU)\s*[/:\-]?\s*(?:[A-Z]{2}\s*)?[n\u00ba\u00b0o.:\s]*"
        r"(?:\d{1,2}\s*/\s*)?\d{1,3}(?:\.?\d{3}){0,3}\d*(?:\s*/\s*[A-Z]{2})?")),
    ("RG",       re.compile(
        r"\b(?:RG|R\.G\.|c[\u00e9e]dula\s+de\s+identidade|carteira\s+de\s+identidade|identidade)"
        r"\s*:?\s*" + _N + r":?\s*(?P<v>\d{1,2}\.?\d{3}\.?\d{3}-?[\dxX])\b"
        r"|(?<!\d)(?P<v2>\d{1,2}\.\d{3}\.\d{3}-[\dxX])(?![\dxX])", _I), "v"),
    ("CTPS",     re.compile(r"\bCTPS\s*:?\s*" + _N + r"(?P<v>\d{4,8}(?:\s*[-/,]?\s*(?:s[\u00e9e]rie\s*)?\d{3,5}(?:-?[A-Z]{2})?)?)", _I), "v"),
    ("PASSAPORTE", re.compile(r"\bpassaporte\s*:?\s*" + _N + r"(?P<v>[A-Z]{2}\s?\d{6})\b|\b(?P<v2>[A-Z]{2}\d{6})\b", _I), "v"),
    ("PLACA",    re.compile(r"\b(?!(?:ADI|ADC|ADO|RMS|RCL|IAC|AGR|EDV|STA|INQ|PET|CNJ|CPC|CLT|CDC|LEI|ART|CEP|OAB|DJE)-?\d)"
                            r"[A-Z]{3}-?\d[A-Z0-9]\d{2}\b")),
    ("CONTA",    re.compile(r"\b(?:ag[\u00eae]ncia|ag\.|conta(?:[-\s]*corrente|[-\s]*poupan[\u00e7c]a|[-\s]*sal[\u00e1a]rio)?|c/c|c\.c\.)"
                            r"\s*:?\s*" + _N + r":?\s*(?P<v>\d[\d.\-]{2,12}\d)\b", _I), "v"),
    ("MATRICULA", re.compile(r"\bmatr[\u00edi]cula\s*(?:funcional|do\s+im[\u00f3o]vel|imobili[\u00e1a]ria|do\s+servidor)?"
                             r"\s*:?\s*" + _N + r":?\s*(?P<v>\d[\d.]{3,12}(?:-\d)?)\b", _I), "v"),
    ("IPTU",     re.compile(r"\b(?:IPTU|contribuinte|SQL|inscri[çc][ãa]o\s+(?:imobili[áa]ria|municipal|cadastral))"
                            r"\s*:?\s*" + _N + r":?\s*(?P<v>\d{3}\.\d{3}\.\d{4}-\d|\d[\d.\-]{6,14}\d)\b", _I), "v"),
    ("CEP",      re.compile(r"(?<!\d)\d{5}-\d{3}(?!\d)|\bCEP\s*:?\s*" + _N + r"(?P<v>\d{5}\.?-?\d{3})\b", _I), "v"),
    ("TELEFONE", re.compile(r"(?<!\d)(?:\+55\s*)?(?:\(?\d{2}\)?[\s.\-]*)?(?:9[\s.]?)?\d{4}[-\s.]?\d{4}(?!\d)"
                            r"|\b0800[\s.\-]?\d{3}[\s.\-]?\d{4}\b")),
    # Numero e complemento do ENDERECO. O logradouro/bairro fica (lugar), mas
    # "n\u00ba 1.234, apto. 45" identifica a residencia da parte.
    ("ENDERECO", re.compile(
        r"\b(?:rua|r\.|avenida|av\.|alameda|al\.|travessa|tv\.|pra[\u00e7c]a|p\u00e7\.|rodovia|rod\.|"
        r"estrada|estr\.|largo|viela|beco)\s+[^\n,;()]{2,60}?[,\s]+"
        r"(?P<v>" + _N + r"\d{1,3}(?:\.\d{3})?(?!\d)"
        r"(?:[\s,]*(?:\d{1,3}[\u00ba\u00b0\u00aao]?\s*andar|"
        r"(?:apto?\.?|apartamento|ap\.|casa|bloco|bl\.?|sala|sl\.?|cj\.?|conjunto|conj\.?|"
        r"lote|lt\.?|quadra|qd\.?|torre|andar|fundos|sobreloja|km)\s*[\dA-Za-z]{1,6}[\u00ba\u00b0\u00aa]?))*)", _I), "v"),
]

# Padroes que so entram com flag (sao quase-identificadores uteis para a
# analise interna; sob sigilo total, tambem devem sumir).
PADROES_OPCIONAIS = {
    "processo": ("PROCESSO", re.compile(r"(?<!\d)\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}(?!\d)|(?<!\d)\d{20}(?!\d)")),
    "nascimento": ("DATA_NASC", re.compile(
        r"(?:\bnascid[oa]s?\s+(?:em|aos|a)\s*|\bdata\s+de\s+nascimento\s*:?\s*|\bnascimento\s*:?\s*|"
        r"\bDN\s*:?\s*|\bnasc\.?\s*:?\s*)"
        r"(?P<v>\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4}|\d{1,2}[\u00ba\u00b0]?\s+de\s+[a-z\u00e7]+\s+de\s+\d{4})", _I), "v"),
}

PRIORIDADE = {"NOME": 0, "EMAIL": 1, "CNPJ": 1, "CPF": 1, "OAB": 1,
              "RG": 1, "CEP": 1, "TELEFONE": 1, "NOME_AUTO": 3}


def _span_padrao(m, grupo):
    """Faixa a tarjar num match: o grupo "v" (ou "v2", alternativa) se houver."""
    if grupo:
        for g in (grupo, grupo + "2"):
            try:
                a, b = m.span(g)
            except IndexError:
                continue
            if a >= 0 and b > a:
                return a, b
    return m.span()


def sem_acento(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s)
                   if not unicodedata.combining(c)).lower()


def detectar_encoding(b):
    if chardet:
        r = chardet.detect(b) or {}
        return r.get("encoding") or "utf-8"
    return "utf-8"


def ler(p):
    b = Path(p).read_bytes()
    enc = detectar_encoding(b)
    try:
        return b.decode(enc, errors="replace")
    except Exception:
        return b.decode("utf-8", errors="replace")


def iniciais(nome):
    toks = [t for t in re.split(r"\s+", nome.strip()) if t]
    letras = [t[0].upper() for t in toks if t.lower() not in CONECTIVOS]
    if not letras:
        letras = [t[0].upper() for t in toks]
    return ".".join(letras) + "." if letras else nome


def regex_nome(nome):
    toks = [re.escape(t) for t in re.split(r"\s+", nome.strip()) if t]
    if not toks:
        return None
    corpo = r"\s+".join(toks)
    return ure.compile(r"(?<![^\W\d_])" + corpo + r"(?![^\W\d_])", ure.IGNORECASE)


def entidade_e_nome(texto_ent):
    """Filtra falsos positivos do NER: pronomes de tratamento, rotulos forenses e URLs."""
    # Rejeitar URLs e caminhos web
    txt_lower = texto_ent.lower()
    if any(p in txt_lower for p in ("http", "www.", ".jus.br", ".gov.br", ".com.br")):
        return False
    # Tokenizar, remover acentos, manter so letras (elimina parenteses, pontuacao)
    toks = [re.sub(r"[^a-z]", "", sem_acento(t)) for t in re.split(r"\s+", texto_ent) if t.strip()]
    nucleo = [t for t in toks if t and t not in STOP_NER and t not in CONECTIVOS and len(t) >= 2]
    return len(nucleo) > 0


def _chunk_excluido(texto_chunk):
    """True se o candidato contem termo de instituicao/lugar/juridico (nao e pessoa)."""
    toks = [re.sub(r"[^a-z]", "", sem_acento(t)) for t in re.split(r"\s+", texto_chunk) if t.strip()]
    nucleo = [t for t in toks if t and t not in CONECTIVOS and len(t) >= 2]
    if not nucleo:
        return True
    return any(t in EXCLUI_PESSOA for t in nucleo)


def _spans_protegidos(doc, base, ignorar_allcaps=False, exigir_capitalizado=False):
    """Entidades que NAO devem ser anonimizadas: orgaos, empresas, lugares, datas."""
    # ATENCAO: protege-se APENAS LUGAR/DATA. Nao se protege ORG/MISC porque o
    # spaCy rotula blocos de nome em CAIXA ALTA como ORG/MISC e isso blindaria
    # nomes reais de pessoa. Instituicoes sao mantidas pelo dicionario de
    # palavras-chave (EXCLUI_PESSOA), que e deterministico.
    # ignorar_allcaps: no texto ORIGINAL em CAIXA ALTA o spaCy erra o rotulo de
    # lugar (ja marcou sobrenome como LOC); nesse caso so confiamos na copia
    # Title Case. Descartamos, entao, spans de LUGAR que sejam todo maiusculos.
    prot = []
    pers = [(e.start_char, e.end_char) for e in doc.ents if e.label_ in ("PER", "PERSON")]
    pontes = ("", "de", "da", "do", "dos", "das", "e")

    def colado_a_pessoa(a, b):
        """LUGAR encostado numa entidade PESSOA ("Gicelia" + "Souza Leite"): e
        prenome que o spaCy nao conhece, nao cidade. Nao pode blindar o nome."""
        for p0, p1 in pers:
            if 0 <= p0 - b <= 5 and base[b:p0].strip().lower() in pontes:
                return True
            if 0 <= a - p1 <= 5 and base[p1:a].strip().lower() in pontes:
                return True
        return False

    for e in doc.ents:
        if e.label_ in ("LOC", "GPE", "DATE", "TIME"):
            # Entidade que atravessa quebra de linha vem de lista/tabela (um nome
            # por linha); o spaCy rotula "Nagina Maria Queiroz\nN" como LUGAR e
            # isso blindava o nome. Nao se protege.
            if "\n" in base[e.start_char:e.end_char]:
                continue
            if e.label_ in ("LOC", "GPE") and colado_a_pessoa(e.start_char, e.end_char):
                continue
            # Na copia Title Case tudo fica capitalizado e o spaCy "ve" lugar em
            # prosa comum ("Leciona Arruda Alvim" -> LOC), blindando o nome. So
            # se confia no LUGAR dessa copia se o ORIGINAL ja era capitalizado.
            if exigir_capitalizado and e.label_ in ("LOC", "GPE") and any(
                    w[0].islower() for w in base[e.start_char:e.end_char].split()):
                continue
            if ignorar_allcaps:
                letras = [c for c in base[e.start_char:e.end_char] if c.isalpha()]
                if letras and all(c.isupper() for c in letras):
                    continue
            prot.append((e.start_char, e.end_char))
    return prot


def _nucleos(texto_chunk):
    toks = [re.sub(r"[^a-z]", "", sem_acento(x)) for x in re.split(r"\s+", texto_chunk) if x.strip()]
    return [x for x in toks if x and x not in CONECTIVOS and len(x) >= 2]


def _tudo_maiusculo(s):
    letras = [c for c in s if c.isalpha()]
    return bool(letras) and all(c.isupper() for c in letras)


def _aparar(texto, a, b):
    """Recua as bordas de [a, b) para deixar de fora pronomes de tratamento,
    cargos, conectivos e termos genericos que estejam nas PONTAS do candidato
    ("Sra. Ana Lucia Ferreira Gomes" -> "Ana Lucia Ferreira Gomes").
    Devolve (a, b) ajustados, ou None se nao sobrar nada."""
    toks = []
    for m in re.finditer(r"\S+", texto[a:b]):
        toks.append((a + m.start(), a + m.end(), re.sub(r"[^a-z]", "", sem_acento(m.group(0))),
                     m.group(0)))
    while toks and (not toks[0][2] or toks[0][2] in APARAVEL):
        toks.pop(0)
    # no fim, tambem cai letra solta sem ponto ("...Queiroz\nN" de tabela)
    while toks and (not toks[-1][2] or toks[-1][2] in APARAVEL
                    or (len(toks[-1][3]) == 1 and toks[-1][3].isalpha())):
        toks.pop()
    if not toks:
        return None
    return toks[0][0], toks[-1][1]


def _sweep(doc, orig_text, protegido, so_allcaps, com_propn=True, propn_pula_caps=False,
           sobrepostos=None):
    """Coleta candidatos a nome de pessoa num doc spaCy.
    orig_text: texto ORIGINAL (mesmo comprimento do texto do doc).
    protegido(a,b): True se a faixa cai sobre entidade de lugar/orgao.
    so_allcaps: se True, so aceita candidatos cujo texto original era CAIXA ALTA
                (usado na passagem Title Case para nao inventar nomes).
    com_propn: se True, alem do NER varre sequencias de nomes proprios (PROPN).
    propn_pula_caps: se True, a varredura PROPN ignora trechos em CAIXA ALTA
                (esses ficam a cargo da passagem PER-only, que nao confunde
                 frases de enfase juridica maiusculas com nomes).
    """
    out = []

    def considerar(a, b, min_nucleos=1, per=False):
        # Primeiro apara tratamento/cargo das pontas; so depois avalia. Antes,
        # "Sra." dentro do span fazia o nome INTEIRO ser descartado (vazamento).
        ap = _aparar(orig_text, a, b)
        if not ap:
            return
        a, b = ap
        if protegido(a, b):
            # Excecao: LUGAR de UMA palavra na borda de um candidato com >= 3
            # nucleos e prenome que o spaCy nao conhece ("Gicelia" de Souza
            # Leite, rotulado LOC), nao cidade. Nao pode blindar o nome.
            sob = sobrepostos(a, b) if sobrepostos else []
            borda = sob and len(_nucleos(orig_text[a:b])) >= 3 and all(
                (x <= a or y >= b) and len(_nucleos(orig_text[max(a, x):min(b, y)])) <= 1
                for x, y in sob)
            if not borda:
                return
        original = orig_text[a:b]
        if not original.strip() or not any(c.isalpha() for c in original):
            return
        if so_allcaps and original != original.upper():
            return
        if "março" in original.lower():      # data ("15 de março"), nao pessoa
            return
        nuc = _nucleos(original)
        if len(nuc) < min_nucleos:
            return
        excl = [x for x in nuc if x in EXCLUI_PESSOA]
        if excl:
            # Sobrenome igual a palavra de instituicao ("Neri Tadeu CAMARA Souza"):
            # aceito so em entidade PESSOA do spaCy, nunca na PRIMEIRA posicao
            # ("Banco Bradesco", "Tribunal de Justica" ficam fora), so uma, e com
            # pelo menos dois nucleos de nome ao redor.
            if not (per and len(nuc) >= 2 and len(excl) == 1 and excl[0] in STOP_INSTITUICAO
                    and nuc[0] != excl[0] and nuc[0] not in PALAVRAS_COMUNS
                    and (excl[0] == nuc[-1] or len(nuc) >= 3)):
                return
        out.append((a, b, "NOME_AUTO", iniciais(original), original))

    # entidades PER
    for ent in doc.ents:
        if ent.label_ in ("PER", "PERSON") and entidade_e_nome(ent.text):
            considerar(ent.start_char, ent.end_char, per=True)

    # varredura de sequencias de nomes proprios (PROPN)
    if not com_propn:
        return out
    toks = list(doc)
    n = len(toks)
    i = 0
    while i < n:
        t = toks[i]
        if t.is_space or t.pos_ != "PROPN":
            i += 1
            continue
        last = i
        j = i + 1
        while j < n:
            tj = toks[j]
            if tj.is_space:                 # atravessa espacos e quebras de linha
                j += 1
                continue
            if tj.pos_ == "PROPN":
                last = j
                j += 1
                continue
            if sem_acento(tj.text) in PONTES_NOME:
                k = j + 1
                while k < n and toks[k].is_space:
                    k += 1
                if k < n and toks[k].pos_ == "PROPN":
                    j += 1
                    continue
            break
        a = toks[i].idx
        b = toks[last].idx + len(toks[last].text)
        i = last + 1
        chunk = orig_text[a:b]
        if propn_pula_caps and _tudo_maiusculo(chunk):
            continue
        # exige >= 2 nucleos APOS aparar (evita palavra isolada / falso positivo)
        considerar(a, b, min_nucleos=2)
    return out


# Tamanho de cada bloco enviado ao spaCy. Precisa ficar abaixo de
# nlp.max_length (1.000.000); blocos menores tambem seguram o uso de memoria.
BLOCO_NER = 800000


def _dividir_blocos(texto, tam=BLOCO_NER):
    """Divide o texto em faixas (ini, fim) de ate `tam` chars, cortando em
    quebra de linha (ou espaco) para nao partir um nome ao meio."""
    blocos, ini, n = [], 0, len(texto)
    while ini < n:
        fim = min(ini + tam, n)
        if fim < n:
            corte = texto.rfind("\n", ini, fim)
            if corte <= ini:
                corte = texto.rfind(" ", ini, fim)
            if corte > ini:
                fim = corte + 1
        blocos.append((ini, fim))
        ini = fim
    return blocos


def _mesclar(intervalos):
    """Mescla intervalos sobrepostos; retorna listas paralelas (inicios, fins)
    ordenadas, para consulta binaria em _toca()."""
    if not intervalos:
        return [], []
    intervalos = sorted(intervalos)
    ms, me = [intervalos[0][0]], [intervalos[0][1]]
    for a, b in intervalos[1:]:
        if a <= me[-1]:
            if b > me[-1]:
                me[-1] = b
        else:
            ms.append(a)
            me.append(b)
    return ms, me


def _toca(ms, me, a, b):
    """True se [a, b) cruza algum intervalo mesclado de (ms, me)."""
    i = bisect.bisect_right(ms, a) - 1
    if i >= 0 and me[i] > a:
        return True
    i += 1
    return i < len(ms) and ms[i] < b


def detectar_pessoas_auto(texto, nlp, agressivo=True):
    """Detecta nomes de PESSOA automaticamente (sem lista previa).
    O texto INTEIRO e processado em blocos (o spaCy tem teto de 1M chars por
    chamada) — sem zona cega em autos longos. Em cada bloco a varredura
    NER+PROPN roda duas vezes: no texto original e numa copia Title Case
    (que recupera nomes escritos em CAIXA ALTA, comuns em acordaos), sempre
    mantendo instituicoes, lugares e datas (entidades protegidas).
    Retorna spans (ini, fim, 'NOME_AUTO', iniciais, original).
    """
    blocos = _dividir_blocos(texto)
    spans, protegidos = [], []
    for num, (ini, fim) in enumerate(blocos, 1):
        if len(blocos) > 1:
            print("    ... analisando parte %d de %d" % (num, len(blocos)), flush=True)
        base = texto[ini:fim]
        doc = nlp(base)
        prot = _spans_protegidos(doc, base, ignorar_allcaps=True)

        # Roda uma copia Title Case: o spaCy so reconhece LUGAR (LOC) e nomes
        # de pessoa de forma confiavel em texto normal; em CAIXA ALTA falha. A
        # copia recupera tanto cidades ("SAO PAULO" -> LOC, protegido) quanto nomes.
        doc_t = None
        base_title = base.title()
        if base_title != base and len(base_title) == len(base):
            doc_t = nlp(base_title)
            prot = prot + _spans_protegidos(doc_t, base, exigir_capitalizado=True)

        def sobrepostos(a, b, _prot=prot):
            return [(x, y) for x, y in _prot if not (b <= x or a >= y)]

        def protegido(a, b):
            return bool(sobrepostos(a, b))

        # PRIORIDADE: recall. Sob segredo de justica, vazar um nome e inaceitavel;
        # super-anonimizar (transformar uma frase maiuscula em iniciais) e seguro e
        # fica sinalizado no mapa para conferencia. Por isso a varredura PROPN roda
        # tambem em CAIXA ALTA, mesmo ao custo de alguns falsos positivos.
        s = _sweep(doc, base, protegido, so_allcaps=False, com_propn=agressivo, sobrepostos=sobrepostos)
        if doc_t is not None:
            s += _sweep(doc_t, base, protegido, so_allcaps=True, com_propn=agressivo, sobrepostos=sobrepostos)
        spans.extend((a + ini, b + ini, r, sub, orig) for a, b, r, sub, orig in s)
        protegidos.extend((x + ini, y + ini) for x, y in prot)

    # Contagem, no documento INTEIRO, de quantas vezes cada palavra aparece e
    # quantas com inicial maiuscula. Sobrenome de verdade vem (quase) sempre
    # capitalizado; "original", "consulta", "quadril" aparecem em minuscula.
    total, caps = {}, {}
    ocorrencias = list(ure.finditer(r"[^\W\d_]{2,}", texto))
    for m in ocorrencias:
        wl = re.sub(r"[^a-z]", "", sem_acento(m.group(0)))
        if not wl:
            continue
        total[wl] = total.get(wl, 0) + 1
        if m.group(0)[0].isupper():
            caps[wl] = caps.get(wl, 0) + 1

    def parece_nome(wl):
        """Palavra que serve de evidencia de nome: nao e comum e, no documento,
        aparece com inicial maiuscula em >= 80% das ocorrencias."""
        if len(wl) < 3 or wl in PALAVRAS_COMUNS or wl in CONECTIVOS or wl in EXCLUI_PESSOA \
                or wl in SUFIXOS_NOME or wl in TRATAMENTO:
            return False
        n = total.get(wl, 0)
        return n == 0 or caps.get(wl, 0) >= 0.8 * n

    # Candidato de UMA palavra so (PER solto, ex.: "Consulta", "Extraordinario")
    # precisa passar no mesmo crivo; senao e ruido de OCR/rodape.
    filtrados = []
    for sp in spans:
        nuc = _nucleos(sp[4])
        if len(nuc) == 1 and not parece_nome(nuc[0]):
            continue
        filtrados.append(sp)
    spans = filtrados

    # Passe de REFORCO: uma vez que uma pessoa foi identificada, qualquer
    # ocorrencia solta das palavras do seu nome (por quebra de linha ou mencao
    # parcial) tambem e mascarada, no texto INTEIRO — inclusive em bloco onde o
    # NER nao a flagrou. Fecha vazamentos de nomes fragmentados.
    if agressivo and spans:
        # palavras que sao nome de pessoa (a partir do que ja foi detectado)
        palavras = set()
        for _a, _b, _r, _s, orig in spans:
            for w in re.split(r"\s+", orig):
                wl = re.sub(r"[^a-z]", "", sem_acento(w))
                if parece_nome(wl):
                    palavras.add(wl)
        if palavras:
            cob_s, cob_e = _mesclar([(a, b) for a, b, *_ in spans])
            prot_s, prot_e = _mesclar(protegidos)
            rx_santo = re.compile(r"(?:S[aã]o|Santo|Santa|Sto\.?|Sta\.?)\s*$", re.IGNORECASE)

            # Reforco mascara ocorrencias soltas das palavras de nome ja
            # detectadas (fecha nomes quebrados e mencoes parciais), sem invadir
            # faixas protegidas de lugar/data nem toponimos ("Sao Paulo").
            for m in ocorrencias:
                wl = re.sub(r"[^a-z]", "", sem_acento(m.group(0)))
                if (wl in palavras and not _toca(cob_s, cob_e, m.start(), m.end())
                        and not _toca(prot_s, prot_e, m.start(), m.end())
                        and not rx_santo.search(texto[max(0, m.start() - 7):m.start()])):
                    spans.append((m.start(), m.end(), "NOME_AUTO",
                                  m.group(0)[0].upper() + ".", m.group(0)))
    return spans


def coletar(texto, nomes, nlp, agressivo=True, opcoes=None):
    spans = []
    for nome in nomes:
        rx = regex_nome(nome)
        if not rx:
            continue
        sub = iniciais(nome)
        for m in rx.finditer(texto):
            spans.append((m.start(), m.end(), "NOME", sub, m.group(0)))
    padroes = list(PADROES) + [PADROES_OPCIONAIS[k] for k in (opcoes or ()) if k in PADROES_OPCIONAIS]
    for item in padroes:
        rot, rx = item[0], item[1]
        grupo = item[2] if len(item) > 2 else None
        for m in rx.finditer(texto):
            a, b = _span_padrao(m, grupo)
            spans.append((a, b, rot, "[" + rot + "]", texto[a:b]))
    if nlp is not None:
        spans.extend(detectar_pessoas_auto(texto, nlp, agressivo=agressivo))
    return spans


def resolver(spans):
    # Percorrendo em ordem de inicio, um span so pode colidir com faixas ja
    # aceitas se comecar antes do maior fim aceito ate aqui — dispensa comparar
    # com cada faixa (que ficava quadratico em autos longos).
    spans.sort(key=lambda s: (s[0], -(s[1] - s[0]), PRIORIDADE.get(s[2], 2)))
    escolhidos, max_fim = [], 0
    for s in spans:
        if s[0] >= max_fim:
            escolhidos.append(s)
            max_fim = s[1]
    return escolhidos


def aplicar(texto, escolhidos):
    out, pos, mapa = [], 0, {}
    for ini, fim, rot, sub, orig in escolhidos:
        out.append(texto[pos:ini])
        out.append(sub)
        pos = fim
        # iniciais ja terminam em ponto: nao duplicar no fim de frase ("C.L.N..")
        if sub.endswith(".") and texto[pos:pos + 1] == ".":
            pos += 1
        chave = (orig, sub, rot)
        mapa[chave] = mapa.get(chave, 0) + 1
    out.append(texto[pos:])
    return "".join(out), mapa


def escrever_mapa(destino, mapa):
    linhas = [
        "MAPA DE ANONIMIZACAO  --  ARQUIVO SIGILOSO",
        "Permite reidentificar pessoas. Guarde em local seguro ou apague.",
        "NUNCA envie este arquivo junto com a peca anonimizada.",
        "=" * 60, "",
    ]
    manual = [k for k in mapa if k[2] != "NOME_AUTO"]
    auto = [k for k in mapa if k[2] == "NOME_AUTO"]
    for orig, sub, rot in sorted(manual, key=lambda k: (k[2], k[0])):
        linhas.append("[%s] %s  ->  %s   (%dx)" % (rot, orig, sub, mapa[(orig, sub, rot)]))
    if auto:
        linhas += ["", "-- DETECAO AUTOMATICA (spaCy) -- CONFERIR CADA UMA --"]
        for orig, sub, rot in sorted(auto, key=lambda k: k[0]):
            linhas.append("[NOME?] %s  ->  %s   (%dx)" % (orig, sub, mapa[(orig, sub, rot)]))
    Path(destino).write_text("\n".join(linhas), encoding="utf-8")


def processar(arquivo, nomes, nlp, agressivo=True, opcoes=None):
    arquivo = Path(arquivo)
    texto = ler(arquivo)
    escolhidos = resolver(coletar(texto, nomes, nlp, agressivo=agressivo, opcoes=opcoes))
    anon, mapa = aplicar(texto, escolhidos)
    saida = arquivo.with_name(arquivo.stem + "_anon.txt")
    mapa_f = arquivo.with_name(arquivo.stem + "_anon_mapa.txt")
    saida.write_text(anon, encoding="utf-8")
    escrever_mapa(mapa_f, mapa)
    return saida, mapa_f, sum(mapa.values())


def alvos(caminho):
    caminho = Path(caminho)
    if caminho.is_file():
        return [caminho]
    return [p for p in caminho.rglob("*.txt")
            if not p.stem.endswith("_anon") and not p.stem.endswith("_anon_mapa")]


def _erro_fatal_spacy(motivo):
    print("=" * 60)
    print("ERRO FATAL: " + motivo)
    print("NADA FOI ANONIMIZADO. Nenhum arquivo _anon.txt foi gerado.")
    print("")
    print("Para corrigir, cole no PowerShell (precisa de internet):")
    print(r"  C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe -m pip install spacy")
    print(r"  C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe -m spacy download pt_core_news_lg")
    print("")
    print("Sem internet/na rede do tribunal: baixe o .whl do modelo em")
    print("  https://github.com/explosion/spacy-models/releases")
    print("e instale com:")
    print(r"  C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe -m pip install CAMINHO\DO\ARQUIVO.whl")
    print("=" * 60)
    sys.exit(2)


def carregar_nlp(modelo):
    try:
        import spacy
    except Exception:
        _erro_fatal_spacy("o pacote spaCy nao esta instalado no ambiente.")
    try:
        return spacy.load("pt_core_news_" + modelo)
    except Exception:
        pass
    try:
        nlp = spacy.load("pt_core_news_md")
        print("AVISO: modelo 'lg' ausente; usando 'md' (menor, menos preciso).")
        return nlp
    except Exception:
        _erro_fatal_spacy("nenhum modelo spaCy de portugues esta instalado.")


def main():
    ap = argparse.ArgumentParser(description="Anonimizador de .txt (reconstrucao)")
    ap.add_argument("caminho", help="pasta ou arquivo .txt")
    ap.add_argument("--nomes", default="", help='nomes separados por ; ex: "Joao Silva; Maria Lima"')
    ap.add_argument("--sem-ner", action="store_true", help="desliga a detecao automatica (spaCy)")
    ap.add_argument("--classico", action="store_true",
                    help="modo conservador: so nomes do NER (PER), sem varredura de nomes proprios")
    ap.add_argument("--modelo", default="lg", choices=["lg", "md"], help="modelo spaCy (padrao lg)")
    ap.add_argument("--tarjar-processo", action="store_true",
                    help="tarja tambem o numero CNJ do processo ([PROCESSO])")
    ap.add_argument("--tarjar-nascimento", action="store_true",
                    help="tarja datas de nascimento ('nascido em', 'DN', 'data de nascimento')")
    ap.add_argument("--sigilo-total", action="store_true",
                    help="atalho para --tarjar-processo --tarjar-nascimento")
    a = ap.parse_args()
    opcoes = set()
    if a.tarjar_processo or a.sigilo_total:
        opcoes.add("processo")
    if a.tarjar_nascimento or a.sigilo_total:
        opcoes.add("nascimento")

    caminho = Path(a.caminho)
    if not caminho.exists():
        print("Caminho nao encontrado:", caminho)
        sys.exit(1)

    nomes = [n.strip() for n in a.nomes.split(";") if n.strip()]
    # Descarta lixo de variavel nao expandida do .bat (ex.: literal %NOMES%)
    nomes = [n for n in nomes if "%" not in n]
    arqs = alvos(caminho)
    if not arqs:
        print("Nenhum .txt encontrado.")
        sys.exit(1)

    if not nomes and a.sem_ner:
        print("AVISO: sem --nomes e sem NER, so os padroes estruturados serao aplicados.")

    nlp = None if a.sem_ner else carregar_nlp(a.modelo)
    agressivo = not a.classico
    modo = "nao" if a.sem_ner else ("%s+propn" % a.modelo if agressivo else "%s (classico)" % a.modelo)
    extras = " | extras: " + ",".join(sorted(opcoes)) if opcoes else ""
    print("Arquivos: %d | Nomes: %d | NER: %s%s" % (len(arqs), len(nomes), modo, extras), flush=True)
    zerados = 0
    for f in arqs:
        print("  processando %s ... (documentos grandes levam varios minutos; aguarde)"
              % f.name, flush=True)
        s, mp, tot = processar(f, nomes, nlp, agressivo=agressivo, opcoes=opcoes)
        print("  %s  ->  %s  (%d substituicoes)  | mapa: %s" % (f.name, s.name, tot, mp.name))
        if tot == 0:
            zerados += 1
            print("    ATENCAO: NENHUMA substituicao neste arquivo. Confira se ele")
            print("    realmente nao contem nomes/CPF/telefone antes de usar.")
    print("Concluido. CONFIRA cada _anon_mapa.txt antes de usar as pecas.")
    print("LEMBRETE: o texto anonimizado fica no arquivo *_anon.txt;")
    print("o .txt original NAO e alterado.")
    if zerados:
        print("AVISO: %d arquivo(s) sem nenhuma substituicao (ver acima)." % zerados)


if __name__ == "__main__":
    main()
