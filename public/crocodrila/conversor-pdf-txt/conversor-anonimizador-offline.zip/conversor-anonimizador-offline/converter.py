#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
converter.py  --  Conversor offline de PDF para TXT

Estrategia de extracao (hibrida, pagina a pagina):
  - Pagina com texto embutido suficiente -> PyMuPDF (rapido, qualidade alta)
  - Pagina escaneada (sem texto ou texto insuficiente) -> Tesseract OCR
  - Pagina com texto FRAGMENTADO (linhas partidas em pedacos fora de ordem) ->
    reextracao com ordenacao geometrica; se continuar fragmentada -> Tesseract OCR
  Assim, PDFs mistos (parte digital, parte escaneada) sao extraidos por completo.
  Fallback: se PyMuPDF nao estiver instalado, OCR do documento inteiro
  (requer Tesseract + Poppler).

Uso:
  python converter.py "arquivo.pdf"
  python converter.py "pasta_com_pdfs/"
  python converter.py "arquivo.pdf" --saida "C:/minha_pasta"
  python converter.py "pasta/" --ocr-forcar          # forca OCR mesmo com texto embutido
  python converter.py "pasta/" --ocr-dpi 400         # DPI mais alto para scans ruins

Saida:
  Para cada PDF, gera um .txt com o mesmo nome no diretorio de saida
  (padrao: mesmo diretorio do PDF, ou --saida para outro local).
"""
import argparse
import os
import re
import sys
import time
from pathlib import Path

# -- PyMuPDF -----------------------------------------------------------------
try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

# -- OCR (Tesseract via pytesseract + pdf2image) -----------------------------
try:
    import pytesseract
except ImportError:
    pytesseract = None

try:
    from pdf2image import convert_from_path
except ImportError:
    convert_from_path = None

try:
    from PIL import Image
except ImportError:
    Image = None

# -- Progresso ---------------------------------------------------------------
try:
    from tqdm import tqdm
except ImportError:
    tqdm = None

# -- Cores no terminal -------------------------------------------------------
try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init()
except ImportError:
    class _Dummy:
        def __getattr__(self, _):
            return ""
    Fore = Style = _Dummy()


# ---------------------------------------------------------------------------
# Configuracao de caminhos para Tesseract e Poppler no Windows
# ---------------------------------------------------------------------------
TESSERACT_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
POPPLER_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "poppler", "poppler-26.02.0", "Library", "bin"
)

if os.path.isfile(TESSERACT_PATH) and pytesseract is not None:
    pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH


# ---------------------------------------------------------------------------
# Extracao hibrida pagina a pagina (PyMuPDF + Tesseract OCR)
# ---------------------------------------------------------------------------
LIMITE_CHARS_POR_PAGINA = 100  # abaixo disso, a pagina e tratada como escaneada

# Carimbos que os tribunais embutem em TODA pagina, inclusive nas escaneadas.
# Nao contam como conteudo: sem descontar, uma pagina so-imagem do e-SAJ
# (~400 chars de carimbo) passava por "texto embutido" e perdia o OCR.
CARIMBOS = [
    # e-SAJ: conferencia do documento original
    re.compile(r"Para conferir o original.*?c[oó]digo\s+\S+", re.S | re.I),
    re.compile(r"Este documento [ée] c[oó]pia do original.*?sob o n[uú]mero\s*\d+\.?",
               re.S | re.I),
    # e-SAJ: numeracao de folhas
    re.compile(r"^\s*fls\.\s*\d+\s*$", re.M | re.I),
    # e-proc: rodape de evento
    re.compile(r"Processo\s+[\d.\-]+,\s*Evento\s+\d+,\s*\S+,\s*P[áa]gina\s+\d+", re.I),
]


def texto_util(texto):
    """Texto da pagina sem os carimbos de tribunal (mede conteudo real)."""
    for padrao in CARIMBOS:
        texto = padrao.sub("", texto)
    return texto.strip()


def so_carimbos(texto):
    """Apenas os carimbos da pagina, na ordem em que aparecem."""
    achados = []
    for padrao in CARIMBOS:
        achados += [(m.start(), m.group(0).strip()) for m in padrao.finditer(texto)]
    return "\n".join(t for _, t in sorted(achados))


# Camada de texto FRAGMENTADA: o PDF grava cada linha em varios objetos de texto
# pequenos e o PyMuPDF, sem ordenacao, devolve os pedacos na ordem interna do
# arquivo ("O " / "Ap" / "pelante " / "ajuizou "), um por linha. A pagina tem
# caracteres de sobra e passava pelo limite acima sem OCR. Caso real: 353 de 662
# paginas de um processo de familia (29/10/2026). Sinal barato que separa os
# dois grupos com folga: pagina legivel tem mediana de linha de 70-80 chars;
# pagina fragmentada, ~17.
FRAG_MIN_LINHAS = 8     # abaixo disso (cabecalho, tabela curta) nao ha evidencia
FRAG_MEDIANA_MAX = 30   # mediana do comprimento das linhas de conteudo


def parece_fragmentado(texto):
    """True se o texto da pagina parece camada de texto embaralhada em pedacos."""
    linhas = [l.strip() for l in texto_util(texto).splitlines() if l.strip()]
    if len(linhas) < FRAG_MIN_LINHAS:
        return False
    tamanhos = sorted(len(l) for l in linhas)
    meio = len(tamanhos) // 2
    mediana = tamanhos[meio] if len(tamanhos) % 2 else (tamanhos[meio - 1] + tamanhos[meio]) / 2
    return mediana <= FRAG_MEDIANA_MAX


def extrair_texto_embutido(page):
    """Texto embutido da pagina com diagnostico de ordem de leitura.

    Retorna (texto, status):
      "ok"          - extracao direta ja veio em ordem
      "reordenado"  - saiu fragmentada; a ordenacao geometrica do PyMuPDF resolveu
      "fragmentado" - continua fragmentada mesmo ordenada: tratar como camada ruim
                      (candidata a OCR); o texto devolvido e o melhor disponivel
    """
    texto = page.get_text("text")
    if not parece_fragmentado(texto):
        return texto, "ok"
    try:
        ordenado = page.get_text("text", sort=True)
    except TypeError:  # PyMuPDF antigo, sem parametro sort
        ordenado = texto
    if not parece_fragmentado(ordenado):
        return ordenado, "reordenado"
    return ordenado, "fragmentado"


def extrair_hibrido(pdf_path, forcar_ocr=False, dpi=300, lang="por"):
    """
    Extrai texto pagina a pagina: usa o texto embutido quando suficiente e
    aplica OCR apenas nas paginas escaneadas (ou em todas, se forcar_ocr).
    Retorna (texto, pags_embutido, pags_ocr, pags_sem_texto, pags_reordenadas,
    pags_fragmentadas_sem_ocr).
    """
    ocr_disponivel = pytesseract is not None and Image is not None
    doc = fitz.open(str(pdf_path))
    paginas = []
    n_emb = n_ocr = n_vazias = n_reord = n_frag = 0
    iterator = tqdm(doc, total=len(doc), desc="  Pags", unit="pag") if tqdm else doc
    for page in iterator:
        texto, status = extrair_texto_embutido(page)
        if (not forcar_ocr and status != "fragmentado"
                and len(texto_util(texto)) >= LIMITE_CHARS_POR_PAGINA):
            paginas.append(texto)
            n_emb += 1
            n_reord += status == "reordenado"
            continue

        texto_ocr = ""
        if ocr_disponivel:
            pix = page.get_pixmap(dpi=dpi)
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            texto_ocr = pytesseract.image_to_string(img, lang=lang) or ""

        if texto_ocr.strip():
            # mantem o carimbo embutido (traz o marcador "fls. N")
            carimbo = so_carimbos(texto)
            if carimbo:
                # o OCR tambem le o "fls. N" impresso: fica so o do carimbo
                texto_ocr = CARIMBOS[2].sub("", texto_ocr)
                texto_ocr = texto_ocr.rstrip() + "\n" + carimbo + "\n"
            paginas.append(texto_ocr)
            n_ocr += 1
        elif texto and texto.strip():
            # OCR indisponivel ou vazio: mantem o texto embutido que ha (se
            # fragmentado, fica registrado no metodo para o operador saber)
            paginas.append(texto)
            n_emb += 1
            n_frag += status == "fragmentado"
        else:
            n_vazias += 1
    doc.close()
    return "\n\n".join(paginas), n_emb, n_ocr, n_vazias, n_reord, n_frag


# ---------------------------------------------------------------------------
# Extracao via Tesseract OCR
# ---------------------------------------------------------------------------
def extrair_ocr(pdf_path, dpi=300, lang="por"):
    """Converte PDF em imagens e aplica Tesseract OCR. Retorna (texto, paginas)."""
    if pytesseract is None or convert_from_path is None:
        return None, 0

    poppler_arg = {}
    if os.path.isdir(POPPLER_PATH):
        poppler_arg["poppler_path"] = POPPLER_PATH

    images = convert_from_path(str(pdf_path), dpi=dpi, **poppler_arg)
    paginas = []
    iterator = tqdm(images, desc="  OCR", unit="pag") if tqdm else images
    for img in iterator:
        texto = pytesseract.image_to_string(img, lang=lang)
        if texto and texto.strip():
            paginas.append(texto)
    if not paginas:
        return None, 0
    return "\n\n".join(paginas), len(paginas)


# ---------------------------------------------------------------------------
# Pipeline de conversao
# ---------------------------------------------------------------------------
def converter_pdf(pdf_path, forcar_ocr=False, ocr_dpi=300, ocr_lang="por"):
    """
    Converte um PDF para texto.
    Retorna (texto, metodo_usado, total_paginas).
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"Arquivo nao encontrado: {pdf_path}")
    if pdf_path.suffix.lower() != ".pdf":
        raise ValueError(f"Nao e PDF: {pdf_path}")

    # Caminho principal: extracao hibrida pagina a pagina
    if fitz is not None:
        texto, n_emb, n_ocr, n_vazias, n_reord, n_frag = extrair_hibrido(
            pdf_path, forcar_ocr=forcar_ocr, dpi=ocr_dpi, lang=ocr_lang
        )
        if texto.strip():
            if n_ocr == 0:
                metodo = "PyMuPDF (texto embutido)"
            elif n_emb == 0:
                metodo = "Tesseract OCR"
            else:
                metodo = f"Hibrido ({n_emb} pags texto + {n_ocr} pags OCR)"
            if n_reord:
                metodo += f" | {n_reord} pag(s) reordenada(s) (camada de texto fragmentada)"
            if n_frag:
                metodo += (f" | AVISO: {n_frag} pag(s) fragmentada(s) mantida(s) sem OCR "
                           f"(Tesseract indisponivel)")
            if n_vazias:
                metodo += f" | AVISO: {n_vazias} pag(s) sem texto extraido"
            return texto, metodo, n_emb + n_ocr

    # Fallback sem PyMuPDF: OCR do documento inteiro via pdf2image
    texto, n_pags = extrair_ocr(pdf_path, dpi=ocr_dpi, lang=ocr_lang)
    if texto and texto.strip():
        return texto, "Tesseract OCR", n_pags

    return "", "FALHA (nenhum texto extraido)", 0


# ---------------------------------------------------------------------------
# Funcoes auxiliares
# ---------------------------------------------------------------------------
def listar_pdfs(caminho):
    """Retorna lista de PDFs a partir de arquivo ou pasta."""
    caminho = Path(caminho)
    if caminho.is_file():
        return [caminho] if caminho.suffix.lower() == ".pdf" else []
    if caminho.is_dir():
        return sorted(caminho.rglob("*.pdf"))
    return []


def salvar_txt(texto, destino):
    """Salva texto em arquivo UTF-8."""
    Path(destino).write_text(texto, encoding="utf-8")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(
        description="Conversor offline de PDF para TXT (PyMuPDF + Tesseract OCR)"
    )
    ap.add_argument("caminho", help="PDF ou pasta com PDFs")
    ap.add_argument("--saida", default="", help="Pasta de saida (padrao: mesmo local do PDF)")
    ap.add_argument("--ocr-forcar", action="store_true",
                    help="Forca OCR mesmo se houver texto embutido")
    ap.add_argument("--ocr-dpi", type=int, default=300,
                    help="DPI para OCR (padrao: 300, use 400+ para scans ruins)")
    ap.add_argument("--ocr-lang", default="por",
                    help="Idioma Tesseract (padrao: por)")
    args = ap.parse_args()

    caminho = Path(args.caminho)
    if not caminho.exists():
        print(f"{Fore.RED}Caminho nao encontrado: {caminho}{Style.RESET_ALL}")
        sys.exit(1)

    pdfs = listar_pdfs(caminho)
    if not pdfs:
        print(f"{Fore.RED}Nenhum PDF encontrado em: {caminho}{Style.RESET_ALL}")
        sys.exit(1)

    saida_dir = Path(args.saida) if args.saida else None
    if saida_dir and not saida_dir.exists():
        saida_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n{Fore.CYAN}=== Conversor PDF -> TXT (offline) ==={Style.RESET_ALL}")
    print(f"PDFs encontrados: {len(pdfs)}")
    print(f"OCR forcar: {'sim' if args.ocr_forcar else 'nao'}")
    print(f"OCR DPI: {args.ocr_dpi}")
    print(f"OCR idioma: {args.ocr_lang}")
    if pytesseract is None or not os.path.isfile(TESSERACT_PATH):
        print(f"{Fore.RED}AVISO: Tesseract OCR indisponivel - "
              f"paginas escaneadas NAO serao extraidas{Style.RESET_ALL}")
    print()

    ok, falhas = 0, 0
    inicio_total = time.time()

    for pdf in pdfs:
        print(f"{Fore.YELLOW}Convertendo:{Style.RESET_ALL} {pdf.name}")
        inicio = time.time()
        try:
            texto, metodo, n_pags = converter_pdf(
                pdf,
                forcar_ocr=args.ocr_forcar,
                ocr_dpi=args.ocr_dpi,
                ocr_lang=args.ocr_lang,
            )
            if not texto.strip():
                print(f"  {Fore.RED}FALHA: nenhum texto extraido{Style.RESET_ALL}")
                falhas += 1
                continue

            # Definir destino
            if saida_dir:
                destino = saida_dir / (pdf.stem + ".txt")
            else:
                destino = pdf.with_suffix(".txt")

            salvar_txt(texto, destino)
            dt = time.time() - inicio
            print(f"  {Fore.GREEN}OK{Style.RESET_ALL} [{metodo}] "
                  f"{n_pags} pags | {len(texto):,} chars | {dt:.1f}s")
            print(f"  -> {destino}")
            ok += 1

        except Exception as e:
            print(f"  {Fore.RED}ERRO: {e}{Style.RESET_ALL}")
            falhas += 1

    dt_total = time.time() - inicio_total
    print(f"\n{Fore.CYAN}Resultado:{Style.RESET_ALL} "
          f"{ok} convertido(s), {falhas} falha(s) em {dt_total:.1f}s")


if __name__ == "__main__":
    main()
