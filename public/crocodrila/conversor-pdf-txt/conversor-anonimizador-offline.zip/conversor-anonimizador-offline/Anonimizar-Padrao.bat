@echo off
chcp 65001 >nul
title Anonimizar TXT - PADRAO-SEGURANCA (recall maximo)
set "VENV=C:\claude-code-backup\pipeline_juridica\.venv\Scripts\python.exe"
set "APP=%~dp0anonimizar.py"

set "ALVO=%~1"
set "TENTATIVAS=0"
:PEDIR_ALVO
if defined ALVO goto ALVO_INFORMADO
if %TENTATIVAS% GEQ 3 (
    echo.
    echo Nenhum caminho foi informado. Abra o atalho de novo quando tiver o arquivo.
    pause
    exit /b 1
)
set /a TENTATIVAS+=1
set /p ALVO="Arraste a pasta ou o arquivo .txt para esta janela e tecle Enter: "
if not defined ALVO echo Nenhum caminho informado. Arraste o arquivo ou a pasta para esta janela e tecle Enter.
goto PEDIR_ALVO
:ALVO_INFORMADO
rem Arrastar para dentro da janela cola o caminho ENTRE ASPAS: remove-las evita duplicar aspas em caminhos com espaco.
set ALVO=%ALVO:"=%
if not defined ALVO goto PEDIR_ALVO

echo.
echo === MODO PADRAO-SEGURANCA ===
echo Detecta TODOS os nomes de pessoa automaticamente e prioriza NAO deixar
echo vazar nome (pode super-anonimizar frases em maiusculas - isso e seguro).
echo Recomendado para documentos sob segredo de justica e para PDFs escaneados.
echo.
echo Para deteccao 100%% automatica, apenas tecle Enter.
echo Para REFORCAR nomes especificos, digite-os separados por ponto e virgula.
set "NOMES="
set /p NOMES="Nomes (opcional): "

echo.
echo.
echo Tarjar TAMBEM o numero do processo e as datas de nascimento?
echo   S = sigilo total (texto que vai SAIR da sua maquina)
echo   N = manter (analise interna; e o padrao)
set "RESP="
set "SIGILO="
set /p RESP="Sigilo total? [S/N] (Enter = N): "
if /i "%RESP%"=="S" set "SIGILO=--sigilo-total"
echo.
"%VENV%" "%APP%" "%ALVO%" --nomes "%NOMES%" %SIGILO%

if errorlevel 1 (
    echo.
    echo ============================================================
    echo  A ANONIMIZACAO FALHOU. NENHUM ARQUIVO _anon.txt FOI GERADO.
    echo  Leia a mensagem de erro ACIMA antes de fechar esta janela.
    echo ============================================================
    pause
    exit /b 1
)

echo.
echo Terminado. O texto anonimizado esta no arquivo *_anon.txt
echo (o .txt original NAO e alterado).
echo CONFIRA o _anon_mapa.txt ANTES de usar a peca.
echo O mapa e sigiloso: nunca o envie junto com o texto anonimizado.
pause
