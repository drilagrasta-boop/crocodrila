# ============================================================================
# INSTALADOR - Conversor PDF/TXT e Anonimizador Offline
# ============================================================================
# Para colegas que NAO usam Claude Code. Roda inteiro pelo PowerShell.
#
# Uso: clique direito neste arquivo > "Executar com PowerShell"
#      ou no PowerShell:  Set-ExecutionPolicy Bypass -Scope Process; .\instalar.ps1
#
# O QUE ELE FAZ:
#   - Verifica se o Python 3.10+ esta instalado (nao instala Python por voce)
#   - Cria a pasta C:\claude-code-backup\pipeline_juridica
#   - Monta um ambiente Python isolado (.venv) e baixa as dependencias
#   - Baixa o modelo de linguagem portugues do spaCy (~550 MB)
#   - Instala o Tesseract OCR (se winget estiver disponivel)
#   - Copia Poppler e os icones
#   - Cria os atalhos na area de trabalho
#
# PRECISA DE INTERNET NA HORA DE INSTALAR (baixa dependencias).
# Depois de instalado, TUDO roda 100%% offline - nenhum documento sai da maquina.
# ============================================================================

$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ProgressPreference = 'SilentlyContinue'  # acelera downloads

$DESTINO = "C:\claude-code-backup\pipeline_juridica"
$ORIGEM  = Split-Path -Parent $MyInvocation.MyCommand.Path

# ----------------------------------------------------------------------------
# Funcoes auxiliares
# ----------------------------------------------------------------------------
function Write-Titulo($msg) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Ok($msg)    { Write-Host "  [OK] $msg" -ForegroundColor Green }
function Write-Aviso($msg) { Write-Host "  [!!] $msg" -ForegroundColor Yellow }
function Write-Erro($msg)  { Write-Host "  [ERRO] $msg" -ForegroundColor Red }
function Write-Info($msg)  { Write-Host "  $msg" -ForegroundColor Gray }

function Pausar {
    Write-Host ""
    Write-Host "Pressione qualquer tecla para continuar..." -ForegroundColor Gray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    Write-Host ""
}

Write-Titulo "CONVERSOR PDF/TXT + ANONIMIZADOR OFFLINE - INSTALADOR"
Write-Info "Este instalador prepara tudo automaticamente."
Write-Info "Requer Python 3.10+ ja instalado e internet durante a instalacao."
Write-Info "Destino: $DESTINO"

# ----------------------------------------------------------------------------
# 1. Verificar Python
# ----------------------------------------------------------------------------
Write-Titulo "1/7 - Verificando Python"

$python = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd --version 2>&1
        if ($ver -match "Python (\d+)\.(\d+)") {
            $major = [int]$Matches[1]
            $minor = [int]$Matches[2]
            if ($major -ge 3 -and $minor -ge 10) {
                $python = $cmd
                Write-Ok "$ver encontrado ($cmd)"
                break
            }
        }
    } catch {}
}

if (-not $python) {
    Write-Erro "Python 3.10+ nao encontrado nesta maquina."
    Write-Host ""
    Write-Info "COMO RESOLVER (passo a passo):"
    Write-Info "  1. Abra: https://www.python.org/downloads/"
    Write-Info "  2. Clique no botao grande 'Download Python 3.x.x'"
    Write-Info "  3. Execute o instalador baixado"
    Write-Info "  4. >>> MARQUE A CAIXA 'Add Python to PATH' <<< (canto inferior)"
    Write-Info "  5. Clique em 'Install Now' e aguarde"
    Write-Info "  6. FECHE esta janela e rode o instalar.ps1 de novo"
    Write-Host ""
    Write-Aviso "Sem esse passo, o resto da instalacao nao funciona."
    Pausar
    exit 1
}

# ----------------------------------------------------------------------------
# 2. Verificar / Instalar Tesseract OCR
# ----------------------------------------------------------------------------
Write-Titulo "2/7 - Verificando Tesseract OCR (necessario para PDFs escaneados)"

$tesseractOk = $false
$tesseractExe = "C:\Program Files\Tesseract-OCR\tesseract.exe"

if (Test-Path $tesseractExe) {
    $tver = & $tesseractExe --version 2>&1 | Select-Object -First 1
    Write-Ok "Tesseract encontrado: $tver"
    $tesseractOk = $true
} else {
    Write-Aviso "Tesseract OCR nao encontrado."
    Write-Info "Tentando instalar via winget..."
    try {
        winget install UB-Mannheim.TesseractOCR --accept-source-agreements --accept-package-agreements 2>&1 | Out-Null
        if (Test-Path $tesseractExe) {
            Write-Ok "Tesseract instalado com sucesso via winget."
            $tesseractOk = $true
        }
    } catch {
        Write-Aviso "winget nao disponivel."
    }

    if (-not $tesseractOk) {
        Write-Aviso "Nao foi possivel instalar o Tesseract automaticamente."
        Write-Info "Instale manualmente (so e preciso para PDFs escaneados):"
        Write-Info "  1. Baixe em: https://github.com/UB-Mannheim/tesseract/wiki"
        Write-Info "  2. Instale no caminho padrao (C:\Program Files\Tesseract-OCR)"
        Write-Info "  3. Durante a instalacao, MARQUE o idioma 'Portuguese'"
        Write-Info ""
        Write-Info "Continuando sem Tesseract (PDFs DIGITAIS continuam funcionando)..."
    }
}

# Verificar idioma portugues
if ($tesseractOk) {
    $langs = & $tesseractExe --list-langs 2>&1
    if ($langs -match "por") {
        Write-Ok "Idioma portugues (por) disponivel."
    } else {
        Write-Aviso "Idioma portugues nao encontrado no Tesseract."
        Write-Info "Baixe por.traineddata de:"
        Write-Info "  https://github.com/tesseract-ocr/tessdata/raw/main/por.traineddata"
        Write-Info "Salve em: C:\Program Files\Tesseract-OCR\tessdata\"
    }
}

# ----------------------------------------------------------------------------
# 3. Criar estrutura de pastas
# ----------------------------------------------------------------------------
Write-Titulo "3/7 - Criando estrutura de pastas"

$pastas = @("$DESTINO", "$DESTINO\input", "$DESTINO\output", "$DESTINO\logs", "$DESTINO\temp")
foreach ($p in $pastas) {
    if (-not (Test-Path $p)) {
        New-Item -ItemType Directory -Path $p -Force | Out-Null
        Write-Ok "Criada: $p"
    } else {
        Write-Info "Ja existe: $p"
    }
}

# ----------------------------------------------------------------------------
# 4. Copiar arquivos
# ----------------------------------------------------------------------------
Write-Titulo "4/7 - Copiando arquivos"

$arquivos = @(
    "converter.py",
    "anonimizar.py",
    "limpar_metadados.py",
    "teste_anonimizar_rapido.py",
    "teste_converter.py",
    "requirements.txt",
    "Converter.bat",
    "Anonimizar.bat",
    "Anonimizar-Classico.bat",
    "Anonimizar-Padrao.bat",
    "Converter-e-Anonimizar.bat",
    "Limpar-Metadados.bat"
)

foreach ($arq in $arquivos) {
    $src = Join-Path $ORIGEM $arq
    $dst = Join-Path $DESTINO $arq
    if (Test-Path $src) {
        Copy-Item $src $dst -Force
        Write-Ok $arq
    } else {
        Write-Erro "Nao encontrado: $src"
    }
}

# Copiar Poppler
$popplerSrc = Join-Path $ORIGEM "poppler"
$popplerDst = Join-Path $DESTINO "poppler"
if (Test-Path $popplerSrc) {
    if (-not (Test-Path $popplerDst)) {
        Copy-Item $popplerSrc $popplerDst -Recurse -Force
        Write-Ok "poppler/ (binarios PDF)"
    } else {
        Write-Info "poppler/ ja existe no destino"
    }
} else {
    Write-Aviso "Pasta poppler/ nao encontrada no pacote."
    Write-Info "O conversor usara apenas PyMuPDF (sem fallback OCR para imagens)."
}

# Copiar icones
$iconsSrc = Join-Path $ORIGEM "icons"
$iconsDst = Join-Path $DESTINO "icons"
if (Test-Path $iconsSrc) {
    Copy-Item $iconsSrc $iconsDst -Recurse -Force
    Write-Ok "icons/ (icones dos atalhos)"
} else {
    Write-Aviso "Pasta icons/ nao encontrada (atalhos ficarao com icone padrao)."
}

# ----------------------------------------------------------------------------
# 5. Criar ambiente virtual e instalar dependencias
# ----------------------------------------------------------------------------
Write-Titulo "5/7 - Criando ambiente virtual e instalando dependencias"

$venvDir = Join-Path $DESTINO ".venv"
$venvPython = Join-Path $venvDir "Scripts\python.exe"
$reqFile = Join-Path $DESTINO "requirements.txt"

if (-not (Test-Path $venvPython)) {
    Write-Info "Criando ambiente virtual (.venv)..."
    & $python -m venv $venvDir
    Write-Ok "Ambiente virtual criado."
} else {
    Write-Info "Ambiente virtual ja existe."
}

Write-Info "Atualizando pip..."
& $venvPython -m pip install --upgrade pip --quiet 2>$null | Out-Null
Write-Info "Instalando pacotes Python (pode demorar)..."
$pipOut = & $venvPython -m pip install -r $reqFile 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Aviso "Alguns pacotes podem ter falhado. Detalhes:"
    $pipOut | Where-Object { $_ -match "ERROR|error|Could not" } | ForEach-Object { Write-Info "  $_" }
} else {
    Write-Ok "Pacotes Python instalados."
}

# ----------------------------------------------------------------------------
# 6. Baixar modelo spaCy portugues
# ----------------------------------------------------------------------------
Write-Titulo "6/7 - Baixando modelo spaCy portugues (pode demorar, ~550 MB)"

$spacyCheck = & $venvPython -c "import spacy; spacy.load('pt_core_news_lg'); print('OK')" 2>$null
if ("$spacyCheck" -match "OK") {
    Write-Ok "Modelo pt_core_news_lg ja instalado."
} else {
    Write-Info "Baixando pt_core_news_lg (pode demorar)..."
    & $venvPython -m spacy download pt_core_news_lg 2>&1 | Out-Null
    $spacyCheck2 = & $venvPython -c "import spacy; spacy.load('pt_core_news_lg'); print('OK')" 2>$null
    if ("$spacyCheck2" -match "OK") {
        Write-Ok "Modelo pt_core_news_lg instalado com sucesso."
    } else {
        Write-Aviso "Modelo lg falhou. Tentando pt_core_news_md..."
        & $venvPython -m spacy download pt_core_news_md 2>&1 | Out-Null
        $spacyCheck3 = & $venvPython -c "import spacy; spacy.load('pt_core_news_md'); print('OK')" 2>$null
        if ("$spacyCheck3" -match "OK") {
            Write-Ok "Modelo pt_core_news_md instalado (menor, menos preciso)."
        } else {
            Write-Erro "NENHUM modelo spaCy foi instalado. O ANONIMIZADOR NAO VAI FUNCIONAR."
            Write-Info "Causa comum: proxy/firewall da rede bloqueando o download."
            Write-Info "Como resolver depois (com internet liberada), cole no PowerShell:"
            Write-Info "  $venvPython -m spacy download pt_core_news_lg"
            Write-Info "Ou baixe o .whl em https://github.com/explosion/spacy-models/releases"
            Write-Info "e instale com:  $venvPython -m pip install CAMINHO\DO\ARQUIVO.whl"
        }
    }
}

# ----------------------------------------------------------------------------
# 7. Criar atalhos na area de trabalho
# ----------------------------------------------------------------------------
Write-Titulo "7/7 - Criando atalhos na area de trabalho"

$desktop = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell

$atalhos = @(
    @{ Nome = "Converter PDF para TXT";        Bat = "Converter.bat";               Ico = "converter.ico" },
    @{ Nome = "Converter e Anonimizar";        Bat = "Converter-e-Anonimizar.bat";  Ico = "converter_anonimizar.ico" },
    @{ Nome = "Anonimizar - Padrao-Seguranca"; Bat = "Anonimizar-Padrao.bat";       Ico = "anonimizar_padrao.ico" },
    @{ Nome = "Anonimizar - Classico";         Bat = "Anonimizar-Classico.bat";     Ico = "anonimizar_classico.ico" },
    @{ Nome = "Limpar Metadados (docx e PDF)"; Bat = "Limpar-Metadados.bat";        Ico = "limpar_metadados.ico" }
)

foreach ($a in $atalhos) {
    $lnk = $ws.CreateShortcut("$desktop\$($a.Nome).lnk")
    $lnk.TargetPath = Join-Path $DESTINO $a.Bat
    $lnk.WorkingDirectory = $DESTINO
    $icoPath = Join-Path $DESTINO "icons\$($a.Ico)"
    if (Test-Path $icoPath) { $lnk.IconLocation = $icoPath }
    $lnk.Save()
    Write-Ok "$($a.Nome)"
}

# ----------------------------------------------------------------------------
# Verificacao final
# ----------------------------------------------------------------------------
Write-Titulo "VERIFICACAO FINAL"

$erros = 0

# Python no venv
try {
    $pyVer = & $venvPython --version 2>&1
    Write-Ok "Python venv: $pyVer"
} catch { Write-Erro "Python no venv"; $erros++ }

# PyMuPDF
$r = & $venvPython -c "import fitz; print('OK')" 2>$null
if ("$r" -match "OK") { Write-Ok "PyMuPDF (fitz)" } else { Write-Erro "PyMuPDF"; $erros++ }

# pytesseract
$r = & $venvPython -c "import pytesseract; print('OK')" 2>$null
if ("$r" -match "OK") { Write-Ok "pytesseract" } else { Write-Erro "pytesseract"; $erros++ }

# pdf2image
$r = & $venvPython -c "import pdf2image; print('OK')" 2>$null
if ("$r" -match "OK") { Write-Ok "pdf2image" } else { Write-Erro "pdf2image"; $erros++ }

# lxml (limpeza de metadados .docx)
$r = & $venvPython -c "import lxml.etree; print('OK')" 2>$null
if ("$r" -match "OK") { Write-Ok "lxml (limpeza de .docx)" } else { Write-Erro "lxml"; $erros++ }

# pywin32 + olefile (limpeza de .doc antigo; exige Word instalado)
$r = & $venvPython -c "import win32com.client, olefile; print('OK')" 2>$null
if ("$r" -match "OK") { Write-Ok "pywin32 + olefile (limpeza de .doc)" }
else { Write-Aviso "pywin32/olefile ausentes: limpeza de .doc antigo indisponivel (.docx e PDF funcionam)" }

# spaCy
$r = & $venvPython -c "import spacy; nlp = spacy.load('pt_core_news_lg'); print('OK')" 2>$null
if ("$r" -match "OK") { Write-Ok "spaCy + pt_core_news_lg" }
else {
    $r2 = & $venvPython -c "import spacy; nlp = spacy.load('pt_core_news_md'); print('OK')" 2>$null
    if ("$r2" -match "OK") { Write-Aviso "spaCy + pt_core_news_md (modelo menor)" }
    else { Write-Erro "spaCy sem modelo portugues"; $erros++ }
}

# Tesseract
if (Test-Path $tesseractExe) { Write-Ok "Tesseract OCR" } else { Write-Aviso "Tesseract OCR nao instalado (OCR indisponivel)"; }

# Poppler
$popplerBin = Join-Path $DESTINO "poppler\poppler-26.02.0\Library\bin\pdftoppm.exe"
if (Test-Path $popplerBin) { Write-Ok "Poppler (pdftoppm)" } else { Write-Aviso "Poppler nao encontrado"; }

# Scripts
foreach ($s in @("converter.py", "anonimizar.py", "limpar_metadados.py")) {
    if (Test-Path (Join-Path $DESTINO $s)) { Write-Ok $s } else { Write-Erro $s; $erros++ }
}

# Resultado
Write-Host ""
if ($erros -eq 0) {
    Write-Host "  INSTALACAO CONCLUIDA COM SUCESSO!" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Atalhos criados na area de trabalho:" -ForegroundColor Gray
    Write-Host "    - Converter PDF para TXT" -ForegroundColor White
    Write-Host "    - Converter e Anonimizar" -ForegroundColor White
    Write-Host "    - Anonimizar - Padrao-Seguranca  (recomendado)" -ForegroundColor White
    Write-Host "    - Anonimizar - Classico" -ForegroundColor White
    Write-Host "    - Limpar Metadados (docx e PDF)  (passo final antes de protocolar)" -ForegroundColor White
    Write-Host ""
    Write-Host "  Tudo roda offline, nada sai da sua maquina." -ForegroundColor Gray
    Write-Host "  Leia o arquivo LEIA-ME.txt para instrucoes de uso." -ForegroundColor Gray
} else {
    Write-Erro "$erros componente(s) com problema. Revise os erros acima."
    Write-Info "Consulte a secao SOLUCAO DE PROBLEMAS no arquivo LEIA-ME.txt."
}

Write-Host ""
Pausar
