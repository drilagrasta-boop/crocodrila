# -*- coding: utf-8 -*-
r"""
SCRIPT: DETECÇÃO DE PROMPT INJECTION
=====================================
Analisa arquivos TXT em busca de padrões suspeitos de prompt injection
antes de iniciar a análise FIRAC.

Etapa 0.1 da Pipeline (após OCR, antes do FIRAC)

Uso:
    python detectar_prompt_injection.py "C:\caminho\para\pasta"
    python detectar_prompt_injection.py "C:\caminho\arquivo.txt"

Códigos de saída:
    0 - Nenhum risco detectado
    1 - Risco BAIXO (alertas menores)
    2 - Risco MÉDIO (requer atenção)
    3 - Risco ALTO (bloqueia pipeline)

Autor: Pipeline Jurídica
Versão: 1.0
"""

import os
import sys
import re
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Tuple
from dataclasses import dataclass, field


# =============================================================================
# CONFIGURAÇÃO DE PADRÕES SUSPEITOS
# =============================================================================

@dataclass
class PadraoSuspeito:
    """Define um padrão suspeito de prompt injection."""
    nome: str
    regex: str
    severidade: int  # 1=baixo, 2=médio, 3=alto
    descricao: str


# Código de saída para falha de execução (fora da escala de risco 0-3)
ERRO_EXECUCAO = 4

# Padrões de prompt injection conhecidos
PADROES_INJECTION = [
    # === SEVERIDADE ALTA (3) - Tentativas diretas de manipulação ===
    PadraoSuspeito(
        nome="ignore_instructions",
        regex=r"(?i)(ignore|ignorar|desconsider[ea]r?|esqueç[ao]|forget).{0,30}(instru[çc][õo]es|instructions|anteriores|previous|acima|above)",
        severidade=3,
        descricao="Tentativa de ignorar instruções anteriores"
    ),
    PadraoSuspeito(
        nome="new_instructions",
        regex=r"(?i)(novas?\s+instru[çc][õo]es|new\s+instructions|suas?\s+novas?\s+ordens?)",
        severidade=3,
        descricao="Tentativa de injetar novas instruções"
    ),
    PadraoSuspeito(
        nome="system_prompt",
        regex=r"(?i)(system\s*prompt|system\s*:|\[system\]|\<system\>|prompt\s*do\s*sistema)",
        severidade=3,
        descricao="Referência a system prompt"
    ),
    PadraoSuspeito(
        nome="act_as",
        regex=r"(?i)(act\s+as|atue\s+como|finja\s+ser|pretend\s+to\s+be|você\s+agora\s+é)",
        severidade=3,
        descricao="Tentativa de alterar persona do assistente"
    ),
    PadraoSuspeito(
        nome="jailbreak",
        regex=r"(?i)(jailbreak|dan\s*mode|developer\s*mode|modo\s*desenvolvedor|sem\s*restri[çc][õo]es)",
        severidade=3,
        descricao="Tentativa de jailbreak"
    ),
    PadraoSuspeito(
        nome="override_rules",
        regex=r"(?i)(override|sobrescrever|substituir|anular).{0,20}(rules|regras|restri[çc][õo]es|limita[çc][õo]es)",
        severidade=3,
        descricao="Tentativa de sobrescrever regras"
    ),
    PadraoSuspeito(
        nome="execute_code",
        regex=r"(?i)(execute\s+o?\s*seguinte|run\s+this|eval\s*\(|exec\s*\(|import\s+os|subprocess)",
        severidade=3,
        descricao="Tentativa de execução de código"
    ),
    PadraoSuspeito(
        nome="hidden_instruction",
        regex=r"(?i)\[INST\]|\[\/INST\]|\<\|im_start\|\>|\<\|im_end\|\>|###\s*(Human|Assistant|System):",
        severidade=3,
        descricao="Marcadores de instrução ocultos"
    ),

    # === SEVERIDADE MÉDIA (2) - Padrões suspeitos ===
    PadraoSuspeito(
        nome="reveal_prompt",
        regex=r"(?i)(revelar?|mostrar?|exibir?|print).{0,20}(prompt|instru[çc][õo]es|configura[çc][ãa]o)",
        severidade=2,
        descricao="Tentativa de revelar prompt interno"
    ),
    PadraoSuspeito(
        nome="roleplay_judge",
        regex=r"(?i)(você\s+é\s+o?\s*juiz|você\s+decide|sua\s+decisão\s+é|decida\s+a\s+favor)",
        severidade=2,
        descricao="Tentativa de influenciar decisão judicial"
    ),
    PadraoSuspeito(
        nome="urgent_command",
        regex=r"(?i)(urgente|imediatamente|agora\s+mesmo|sem\s+questionar).{0,30}(fa[çc]a|execute|ignore)",
        severidade=2,
        descricao="Comando urgente suspeito"
    ),
    PadraoSuspeito(
        nome="base64_content",
        regex=r"[A-Za-z0-9+/]{50,}={0,2}",
        severidade=2,
        descricao="Possível conteúdo codificado em Base64"
    ),
    PadraoSuspeito(
        nome="unicode_homoglyph",
        regex=r"[\u200b-\u200f\u2028-\u202f\u2060-\u206f]",
        severidade=2,
        descricao="Caracteres Unicode invisíveis/homóglifos"
    ),

    # === SEVERIDADE BAIXA (1) - Alertas menores ===
    PadraoSuspeito(
        nome="markdown_injection",
        regex=r"```(?:python|bash|shell|javascript|js)\s*\n.{10,}?\n```",
        severidade=1,
        descricao="Bloco de código em markdown (verificar contexto)"
    ),
    PadraoSuspeito(
        nome="xml_tags",
        regex=r"<(?:script|iframe|object|embed|form|input)[^>]*>",
        severidade=1,
        descricao="Tags HTML/XML potencialmente perigosas"
    ),
    PadraoSuspeito(
        nome="url_injection",
        regex=r"https?://[^\s]+(?:\.exe|\.bat|\.ps1|\.sh|\.py)",
        severidade=1,
        descricao="URL para arquivo executável"
    ),
]

# Padrões específicos para documentos jurídicos (falsos positivos comuns)
FALSOS_POSITIVOS = [
    r"(?i)ignorar\s+o\s+pedido",  # "ignorar o pedido" é linguagem jurídica comum
    r"(?i)novas\s+instru[çc][õo]es\s+para\s+per[ií]cia",  # Instruções para perícia
    r"(?i)execute[\-\s]se",  # "Execute-se" é despacho judicial
    r"(?i)atue\s+como\s+(advogado|perito|assistente\s+t[ée]cnico)",  # Contexto profissional
]


# =============================================================================
# FUNÇÕES DE ANÁLISE
# =============================================================================

@dataclass
class Deteccao:
    """Representa uma detecção de padrão suspeito."""
    arquivo: str
    linha: int
    padrao: str
    severidade: int
    trecho: str
    descricao: str


@dataclass
class RelatorioSeguranca:
    """Relatório de segurança da análise."""
    pasta_analisada: str
    arquivos_analisados: int
    data_analise: str
    deteccoes: List[Deteccao] = field(default_factory=list)
    risco_geral: int = 0
    recomendacao: str = ""


def eh_falso_positivo(texto: str, contexto: str) -> bool:
    """Verifica se a detecção é um falso positivo comum em documentos jurídicos."""
    texto_completo = f"{contexto} {texto}".lower()

    for padrao_fp in FALSOS_POSITIVOS:
        if re.search(padrao_fp, texto_completo):
            return True

    return False


def analisar_arquivo(caminho: Path) -> List[Deteccao]:
    """Analisa um arquivo TXT em busca de padrões suspeitos."""
    deteccoes = []

    try:
        with open(caminho, 'r', encoding='utf-8', errors='ignore') as f:
            linhas = f.readlines()
    except Exception as e:
        print(f"   Erro ao ler {caminho.name}: {e}")
        return deteccoes

    for num_linha, linha in enumerate(linhas, 1):
        # Obtém contexto (linhas anterior e posterior)
        contexto_anterior = linhas[num_linha - 2] if num_linha > 1 else ""
        contexto_posterior = linhas[num_linha] if num_linha < len(linhas) else ""
        contexto = f"{contexto_anterior} {linha} {contexto_posterior}"

        for padrao in PADROES_INJECTION:
            matches = re.finditer(padrao.regex, linha)

            for match in matches:
                trecho = match.group(0)

                # Verifica falso positivo
                if eh_falso_positivo(trecho, contexto):
                    continue

                # Limita tamanho do trecho para exibição
                trecho_exibicao = trecho[:80] + "..." if len(trecho) > 80 else trecho

                deteccoes.append(Deteccao(
                    arquivo=caminho.name,
                    linha=num_linha,
                    padrao=padrao.nome,
                    severidade=padrao.severidade,
                    trecho=trecho_exibicao,
                    descricao=padrao.descricao
                ))

    return deteccoes


def analisar_espacamento_anomalo(caminho: Path) -> List[Deteccao]:
    """Detecta texto oculto por espaçamento anômalo."""
    deteccoes = []

    try:
        with open(caminho, 'r', encoding='utf-8', errors='ignore') as f:
            conteudo = f.read()
    except:
        return deteccoes

    # Detecta múltiplos espaços consecutivos (possível texto oculto)
    espacos_anomalos = re.finditer(r'(\S)\s{10,}(\S)', conteudo)

    for match in espacos_anomalos:
        # Encontra a linha
        pos = match.start()
        linhas_antes = conteudo[:pos].count('\n') + 1

        deteccoes.append(Deteccao(
            arquivo=caminho.name,
            linha=linhas_antes,
            padrao="espacamento_anomalo",
            severidade=2,
            trecho=f"'{match.group(1)}' ... [~{len(match.group(0))} espaços] ... '{match.group(2)}'",
            descricao="Espaçamento anômalo - possível texto oculto"
        ))

    return deteccoes


def processar_pasta(pasta: Path) -> RelatorioSeguranca:
    """Processa todos os arquivos TXT de uma pasta."""
    relatorio = RelatorioSeguranca(
        pasta_analisada=str(pasta),
        arquivos_analisados=0,
        data_analise=datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    )

    # Encontra arquivos TXT
    arquivos_txt = list(pasta.glob("*.txt"))

    if not arquivos_txt:
        print("\n[!] Nenhum arquivo TXT encontrado na pasta.")
        return relatorio

    print(f"\n{'='*70}")
    print(f"   DETECÇÃO DE PROMPT INJECTION - Pipeline Jurídica")
    print(f"{'='*70}")
    print(f"\nPasta: {pasta}")
    print(f"Arquivos TXT: {len(arquivos_txt)}")
    print(f"Data: {relatorio.data_analise}")
    print(f"\n{'-'*70}")

    for arquivo in arquivos_txt:
        print(f"\n[TXT] {arquivo.name}")
        relatorio.arquivos_analisados += 1

        # Análise de padrões de injection
        deteccoes = analisar_arquivo(arquivo)

        # Análise de espaçamento anômalo
        deteccoes += analisar_espacamento_anomalo(arquivo)

        if deteccoes:
            print(f"   ⚠️  {len(deteccoes)} padrão(ões) suspeito(s) encontrado(s)")
            relatorio.deteccoes.extend(deteccoes)
        else:
            print(f"   ✅ Nenhum padrão suspeito detectado")

    # Calcula risco geral
    if relatorio.deteccoes:
        max_severidade = max(d.severidade for d in relatorio.deteccoes)
        relatorio.risco_geral = max_severidade

        if max_severidade == 3:
            relatorio.recomendacao = "BLOQUEIO RECOMENDADO - Revisar manualmente antes de prosseguir"
        elif max_severidade == 2:
            relatorio.recomendacao = "ATENÇÃO NECESSÁRIA - Verificar detecções antes de prosseguir"
        else:
            relatorio.recomendacao = "BAIXO RISCO - Prosseguir com cautela"
    else:
        relatorio.risco_geral = 0
        relatorio.recomendacao = "APROVADO - Nenhum risco detectado"

    return relatorio


def exibir_relatorio(relatorio: RelatorioSeguranca) -> None:
    """Exibe o relatório de segurança formatado."""
    print(f"\n{'='*70}")
    print(f"   RELATÓRIO DE SEGURANÇA")
    print(f"{'='*70}")

    # Nível de risco
    niveis = {0: "NENHUM", 1: "BAIXO", 2: "MÉDIO", 3: "ALTO"}
    cores = {0: "✅", 1: "⚡", 2: "⚠️", 3: "🚨"}

    print(f"\n{cores[relatorio.risco_geral]} Nível de Risco: {niveis[relatorio.risco_geral]}")
    print(f"📋 Recomendação: {relatorio.recomendacao}")

    # Estatísticas
    print(f"\n📊 Estatísticas:")
    print(f"   - Arquivos analisados: {relatorio.arquivos_analisados}")
    print(f"   - Detecções totais: {len(relatorio.deteccoes)}")

    if relatorio.deteccoes:
        por_severidade = {1: 0, 2: 0, 3: 0}
        for d in relatorio.deteccoes:
            por_severidade[d.severidade] += 1

        print(f"   - Alta severidade: {por_severidade[3]}")
        print(f"   - Média severidade: {por_severidade[2]}")
        print(f"   - Baixa severidade: {por_severidade[1]}")

    # Detalhes das detecções
    if relatorio.deteccoes:
        print(f"\n{'-'*70}")
        print(f"   DETECÇÕES ENCONTRADAS")
        print(f"{'-'*70}")

        # Ordena por severidade (maior primeiro)
        deteccoes_ordenadas = sorted(relatorio.deteccoes, key=lambda x: -x.severidade)

        for d in deteccoes_ordenadas:
            sev_icone = {1: "⚡", 2: "⚠️", 3: "🚨"}[d.severidade]
            sev_texto = {1: "BAIXO", 2: "MÉDIO", 3: "ALTO"}[d.severidade]

            print(f"\n{sev_icone} [{sev_texto}] {d.padrao}")
            print(f"   Arquivo: {d.arquivo}, Linha: {d.linha}")
            print(f"   Descrição: {d.descricao}")
            print(f"   Trecho: \"{d.trecho}\"")

    print(f"\n{'='*70}\n")


def salvar_relatorio(relatorio: RelatorioSeguranca, pasta: Path) -> Path:
    """Salva o relatório de segurança em arquivo."""
    caminho_relatorio = pasta / "00_relatorio_seguranca.md"

    niveis = {0: "NENHUM", 1: "BAIXO", 2: "MÉDIO", 3: "ALTO"}
    icones = {0: "✅", 1: "⚡", 2: "⚠️", 3: "🚨"}

    conteudo = f"""# RELATÓRIO DE SEGURANÇA - DETECÇÃO DE PROMPT INJECTION

**Data da Análise:** {relatorio.data_analise}
**Pasta Analisada:** `{relatorio.pasta_analisada}`
**Arquivos Analisados:** {relatorio.arquivos_analisados}

---

## {icones[relatorio.risco_geral]} Nível de Risco: {niveis[relatorio.risco_geral]}

**Recomendação:** {relatorio.recomendacao}

---

## Estatísticas

| Métrica | Valor |
|---------|-------|
| Arquivos analisados | {relatorio.arquivos_analisados} |
| Detecções totais | {len(relatorio.deteccoes)} |
"""

    if relatorio.deteccoes:
        por_severidade = {1: 0, 2: 0, 3: 0}
        for d in relatorio.deteccoes:
            por_severidade[d.severidade] += 1

        conteudo += f"""| Alta severidade (🚨) | {por_severidade[3]} |
| Média severidade (⚠️) | {por_severidade[2]} |
| Baixa severidade (⚡) | {por_severidade[1]} |

---

## Detecções Encontradas

"""
        deteccoes_ordenadas = sorted(relatorio.deteccoes, key=lambda x: -x.severidade)

        for d in deteccoes_ordenadas:
            sev_icone = {1: "⚡", 2: "⚠️", 3: "🚨"}[d.severidade]
            sev_texto = {1: "BAIXO", 2: "MÉDIO", 3: "ALTO"}[d.severidade]

            conteudo += f"""### {sev_icone} [{sev_texto}] {d.padrao}

- **Arquivo:** `{d.arquivo}`
- **Linha:** {d.linha}
- **Descrição:** {d.descricao}
- **Trecho:** `{d.trecho}`

"""
    else:
        conteudo += """
---

## ✅ Nenhuma Detecção

Nenhum padrão suspeito de prompt injection foi encontrado nos arquivos analisados.
"""

    conteudo += f"""---

**Script:** `detectar_prompt_injection.py` v1.0
**Pipeline Jurídica** - Etapa 0.1
"""

    with open(caminho_relatorio, 'w', encoding='utf-8') as f:
        f.write(conteudo)

    return caminho_relatorio


# =============================================================================
# FUNÇÃO PRINCIPAL
# =============================================================================

def main():
    """Função principal."""
    # Windows sem UTF-8 configurado: os emojis do relatório derrubariam o
    # script (UnicodeEncodeError) quando a saída é redirecionada, e o código
    # de saída do erro (1) se confundiria com "risco BAIXO".
    for fluxo in (sys.stdout, sys.stderr):
        try:
            fluxo.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if len(sys.argv) < 2:
        print("\n🔍 DETECÇÃO DE PROMPT INJECTION - Pipeline Jurídica")
        print("=" * 50)
        print("\nUso:")
        print('  python detectar_prompt_injection.py "C:\\caminho\\pasta"')
        print('  python detectar_prompt_injection.py "C:\\caminho\\arquivo.txt"')
        print("\nCódigos de saída:")
        print("  0 - Nenhum risco detectado")
        print("  1 - Risco BAIXO")
        print("  2 - Risco MÉDIO")
        print("  3 - Risco ALTO (bloqueia pipeline)")
        print("  4 - Erro: a verificação NÃO rodou (caminho inexistente etc.)")
        print()
        return 0

    caminho = Path(sys.argv[1])

    if not caminho.exists():
        print(f"\n⚠️ Caminho não encontrado: {caminho}")
        return ERRO_EXECUCAO

    # Determina se é arquivo ou pasta
    if caminho.is_file():
        pasta = caminho.parent
        # Cria lista temporária só com este arquivo
        relatorio = RelatorioSeguranca(
            pasta_analisada=str(pasta),
            arquivos_analisados=1,
            data_analise=datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        )

        print(f"\n{'='*70}")
        print(f"   DETECÇÃO DE PROMPT INJECTION - Pipeline Jurídica")
        print(f"{'='*70}")
        print(f"\nArquivo: {caminho}")

        deteccoes = analisar_arquivo(caminho)
        deteccoes += analisar_espacamento_anomalo(caminho)
        relatorio.deteccoes = deteccoes

        if deteccoes:
            max_sev = max(d.severidade for d in deteccoes)
            relatorio.risco_geral = max_sev
            if max_sev == 3:
                relatorio.recomendacao = "BLOQUEIO RECOMENDADO"
            elif max_sev == 2:
                relatorio.recomendacao = "ATENÇÃO NECESSÁRIA"
            else:
                relatorio.recomendacao = "BAIXO RISCO"
        else:
            relatorio.risco_geral = 0
            relatorio.recomendacao = "APROVADO"
    else:
        pasta = caminho
        relatorio = processar_pasta(pasta)

    # Exibe relatório
    exibir_relatorio(relatorio)

    # Salva relatório
    caminho_relatorio = salvar_relatorio(relatorio, pasta if caminho.is_dir() else caminho.parent)
    print(f"📄 Relatório salvo em: {caminho_relatorio}\n")

    # Retorna código de saída baseado no nível de risco
    return relatorio.risco_geral


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as erro:  # nunca confundir falha com "risco baixo"
        print(f"ERRO: a verificação não rodou: {erro}")
        sys.exit(ERRO_EXECUCAO)
