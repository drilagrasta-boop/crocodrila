# instalar-no-claude.ps1
# Copia a skill "protocolo-anti-injection" (com o detector) para o Claude Code
# desta conta e testa o detector com os exemplos do kit.
# NAO altera o seu CLAUDE.md: o trecho para colar esta em trecho-para-o-CLAUDE.md.txt

$ErrorActionPreference = "Continue"
$origem   = Join-Path $PSScriptRoot "protocolo-anti-injection"
$destBase = Join-Path $HOME ".claude\skills"
$destino  = Join-Path $destBase "protocolo-anti-injection"
$exemplos = Join-Path (Split-Path $PSScriptRoot -Parent) "exemplos"
$problemas = 0

Write-Host ""
Write-Host "=== Instalando o Protocolo Anti-Injection no Claude ===" -ForegroundColor Cyan

# 1. Python
$py = $null; $pyArgs = @()
if (Get-Command py -ErrorAction SilentlyContinue) { $py = "py"; $pyArgs = @("-3") }
elseif (Get-Command python -ErrorAction SilentlyContinue) { $py = "python" }
if ($py) {
    Write-Host "[OK] Python encontrado" -ForegroundColor Green
} else {
    Write-Host "[FALTA] Python nao encontrado. Instale em https://www.python.org/downloads/" -ForegroundColor Red
    Write-Host "        marcando 'Add python.exe to PATH'."
    $problemas++
}

# 2. Copiar a skill (backup da anterior FORA da pasta skills)
if (-not (Test-Path $destBase)) { New-Item -ItemType Directory -Path $destBase -Force | Out-Null }
if (Test-Path $destino) {
    $bakBase = Join-Path (Split-Path $destBase -Parent) "skills-backup"
    if (-not (Test-Path $bakBase)) { New-Item -ItemType Directory -Path $bakBase -Force | Out-Null }
    $bak = Join-Path $bakBase ("protocolo-anti-injection-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    Move-Item -Path $destino -Destination $bak
    Write-Host "[INFO] Ja existia uma versao da skill; guardada em $bak"
}
Copy-Item -Path $origem -Destination $destino -Recurse
$det = Join-Path $destino "scripts\detectar_prompt_injection.py"
if (Test-Path $det) {
    Write-Host "[OK] Skill copiada para $destino" -ForegroundColor Green
} else {
    Write-Host "[ERRO] Nao consegui copiar a skill" -ForegroundColor Red
    $problemas++
}

# 3. Autoteste com os exemplos do kit
if ($py -and (Test-Path $det) -and (Test-Path $exemplos)) {
    & $py @pyArgs $det (Join-Path $exemplos "peticao-limpa.txt") *> $null
    $limpo = $LASTEXITCODE
    & $py @pyArgs $det (Join-Path $exemplos "peticao-com-injecao.txt") *> $null
    $sujo = $LASTEXITCODE
    if ($limpo -eq 0 -and $sujo -eq 3) {
        Write-Host "[OK] Autoteste: peticao limpa = sem risco; peticao com injecao = risco ALTO" -ForegroundColor Green
    } else {
        Write-Host "[ERRO] Autoteste falhou (limpa=$limpo, com injecao=$sujo; esperado 0 e 3)" -ForegroundColor Red
        $problemas++
    }
    $rel = Join-Path $exemplos "00_relatorio_seguranca.md"
    if (Test-Path $rel) { Remove-Item $rel }
}

Write-Host ""
if ($problemas -eq 0) {
    Write-Host "PRONTO. Feche e abra o Claude Code." -ForegroundColor Green
    Write-Host "Para o protocolo valer em TODA conversa, cole o conteudo de"
    Write-Host "trecho-para-o-CLAUDE.md.txt no seu CLAUDE.md (veja COMO-USAR-NO-CLAUDE.txt)."
} else {
    Write-Host "Ha $problemas pendencia(s) acima. Resolva e rode de novo." -ForegroundColor Yellow
}
Write-Host ""
Read-Host "Aperte Enter para fechar"
