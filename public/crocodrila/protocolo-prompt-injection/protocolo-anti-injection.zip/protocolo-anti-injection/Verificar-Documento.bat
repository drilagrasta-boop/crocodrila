@echo off
chcp 65001 >nul
title Verificar documento - prompt injection

set "DET=%~dp0detector\detectar_prompt_injection.py"
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY (where python >nul 2>&1 && set "PY=python")
if not defined PY (
    echo ERRO: Python nao encontrado. Instale em https://www.python.org/downloads/
    echo marcando "Add python.exe to PATH" e tente de novo.
    pause
    exit /b 1
)

set "ALVO=%~1"
if "%ALVO%"=="" (
    echo Arraste um arquivo .txt ^(ou uma pasta com .txt^) para esta janela e tecle Enter.
    echo PDF precisa ser convertido em .txt antes.
    set /p ALVO="Caminho: "
)
rem o Windows cola o caminho arrastado ja entre aspas; tira as aspas
if defined ALVO set ALVO=%ALVO:"=%
if not defined ALVO (
    echo Nenhum arquivo informado.
    pause
    exit /b 1
)

%PY% "%DET%" "%ALVO%"
set "RISCO=%errorlevel%"
echo.
if "%RISCO%"=="0" echo RESULTADO: nenhum sinal de injecao.
if "%RISCO%"=="1" echo RESULTADO: risco BAIXO. Leia os alertas acima.
if "%RISCO%"=="2" echo RESULTADO: risco MEDIO. Confira os trechos antes de usar o documento numa IA.
if "%RISCO%"=="3" echo RESULTADO: risco ALTO. NAO use este documento numa IA sem revisar os trechos acima.
if %RISCO% GEQ 4 echo RESULTADO: ERRO, a verificacao NAO rodou. Leia a mensagem acima.
echo O relatorio completo ficou em 00_relatorio_seguranca.md, na pasta do documento.
echo.
pause
