# FICHA — <título do arquivo>

- **Disciplina:** <nome da disciplina, curso ou assunto>
- **Arquivo:** <nome do arquivo original>
- **Papel:** <programa | leitura>
- **Autor:** <só se constar no próprio texto; senão "não consta">
- **Qualidade do texto:** <texto_corrido | slides_telegraficos | ocr_tesseract>
- **Bruto:** <caminho em 03_brutos>

## Resumo

(5 a 8 linhas, só com o que está no texto.)

## Tese central

(Uma ou duas frases. Se o texto não defende tese, escreva "não se aplica" e explique em uma linha o que ele é: programa, glossário, relato...)

## Conceitos-chave

- **Conceito** — definição conforme o texto (p. N)

## Argumento passo a passo

1. ... (p. N)

## Trechos literais

> "trecho copiado EXATAMENTE do bruto, sem alterar uma letra" (p. N)

## Conexões e debates

(Apenas o que o próprio texto indica: autores com quem dialoga, objeções que enfrenta. Nada de conhecimento externo.)

## Perguntas de estudo

1. ...
