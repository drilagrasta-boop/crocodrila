"""Passo 7. Monta 04_project/, a pasta que voce sobe para o Project do claude.ai:
- base/NN_<disciplina>.txt   os textos integrais, um arquivo por disciplina, com cabecalho por arquivo
- fichas/FNN_<disciplina>.txt  as fichas (se voce fez; sem fichas, o Oraculo funciona so com a base)
- 00_INDICE.txt e 01_MAPA.txt
- instrucoes_personalizadas.md  (criado a partir de modelo/ se ainda nao existir; preencha os [CAMPOS])

Uso: python scripts/50_montar_project.py [--raiz PASTA]
Tirar um item da base sem apagar nada: catalogo/excluir_do_pacote.json, campos "id_exato" (lista de ids) e "arquivo_contem"."""
import json, re, shutil, sys, unicodedata
from collections import OrderedDict
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


ROOT = raiz()
cfg = json.loads((ROOT / "oraculo.json").read_text(encoding="utf-8")) if (ROOT / "oraculo.json").exists() else {}
NOME = cfg.get("nome", "Oraculo")
OUT = ROOT / "04_project" / "base"
OUT.mkdir(parents=True, exist_ok=True)
for f in OUT.glob("*.txt"): f.unlink()   # so apaga a saida gerada por este script
cat = [json.loads(l) for l in (ROOT / "catalogo" / "catalogo.jsonl").read_text(encoding="utf-8").splitlines()]
exc_f = ROOT / "catalogo" / "excluir_do_pacote.json"
exc = json.loads(exc_f.read_text(encoding="utf-8")) if exc_f.exists() else {}
EXC, IDX = exc.get("arquivo_contem", []), exc.get("id_exato", [])
cat = [o for o in cat if o["id"] not in IDX and not any(x.lower() in o["arquivo"].lower() for x in EXC)]
pend = [o for o in cat if o["qualidade_texto"] == "sem_texto_precisa_ocr"]
if pend: print(f"ATENCAO: {len(pend)} PDF(s) sem texto (OCR pendente) entram vazios na base. Rode scripts/32_ocr_pdf.py e monte de novo.")
NOTA = {"ocr_tesseract": "TEXTO POR OCR: pode ter erros de leitura; conferir citacoes literais no PDF original.",
        "slides_telegraficos": "SLIDES: texto telegrafico; citar como slide N.",
        "sem_texto_precisa_ocr": "SEM TEXTO: o PDF era imagem e o OCR nao foi feito.",
        "texto_corrido": ""}
ORDEM = {"programa": 0, "leitura": 1}
disc = OrderedDict()
for it in sorted(cat, key=lambda o: (o["disciplina"], ORDEM.get(o["papel"], 2), o["arquivo"])): disc.setdefault(it["disciplina"], []).append(it)
indice = [f"# INDICE DA BASE - {NOME}", "", "Cada arquivo `NN_disciplina.txt` reune os textos integrais da disciplina. Marcador de pagina: <!-- p. N -->.", ""]
for n, (d, items) in enumerate(disc.items(), 1):
    nome = "Arquivos gerais" if d == "_geral" else d
    slug = re.sub(r"[^a-z0-9]+", "-", unicodedata.normalize("NFKD", d.lower()).encode("ascii", "ignore").decode()).strip("-")[:40] or "geral"
    fn = f"{n:02d}_{slug}.txt"
    partes = [f"DISCIPLINA: {nome}\n"]
    indice.append(f"## {n:02d}. {nome}  ({fn})")
    for it in items:
        txt = (ROOT / it["bruto"]).read_text(encoding="utf-8").strip()
        partes.append(f"\n\n{'=' * 70}\nARQUIVO: {it['arquivo']}\nPAPEL: {it['papel']} | QUALIDADE: {it['qualidade_texto']} | PAGINAS: {it['paginas'] or '-'}\n{NOTA.get(it['qualidade_texto'], '')}\n{'=' * 70}\n\n{txt}")
        indice.append(f"- {it['arquivo']}  [{it['papel']}; {it['qualidade_texto']}; {it['paginas'] or '-'} p.]")
    (OUT / fn).write_text("".join(partes), encoding="utf-8")
    indice.append("")
(ROOT / "04_project" / "00_INDICE.txt").write_text("\n".join(indice), encoding="utf-8")
tot = sum(f.stat().st_size for f in OUT.glob("*.txt"))
print(len(disc), "arquivo(s) de base,", round(tot / 1e6, 2), "MB")
for f in sorted(OUT.glob("*.txt")): print(" ", round(f.stat().st_size / 1e3), "KB", f.name)

# fichas por disciplina e mapa (opcional)
NL = chr(10)
FD = ROOT / "04_project" / "fichas"
FD.mkdir(exist_ok=True)
for f in FD.glob("*.txt"): f.unlink()
pastas = sorted(p for p in (ROOT / "02_fichas").iterdir() if p.is_dir() and any(p.glob("*.md"))) if (ROOT / "02_fichas").exists() else []
for n, d in enumerate(pastas, 1):
    sep = NL * 2 + "=" * 70 + NL * 2
    corpo = sep.join(f.read_text(encoding="utf-8") for f in sorted(d.glob("*.md")))
    (FD / f"F{n:02d}_{d.name}.txt").write_text("FICHAS DE ESTUDO (resumos com paginas; citacoes literais conferidas contra o texto integral)" + NL * 2 + corpo, encoding="utf-8")
mapa = ROOT / "01_nucleo" / "01_mapa.md"
if mapa.exists(): shutil.copy(mapa, ROOT / "04_project" / "01_MAPA.txt")
print(len(pastas), "arquivo(s) de fichas," + (" com mapa." if mapa.exists() else " sem fichas: o Oraculo vai funcionar so com a base."))

# instrucoes do Project
ins = ROOT / "04_project" / "instrucoes_personalizadas.md"
modelo = next((m for m in (ROOT / "modelo" / "instrucoes_do_project.md", Path(__file__).resolve().parent.parent / "modelo" / "instrucoes_do_project.md") if m.exists()), None)
if not ins.exists() and modelo:
    shutil.copy(modelo, ins)
    print("Criei 04_project/instrucoes_personalizadas.md a partir do modelo. PREENCHA os [CAMPOS] antes de colar no Project.")
if ins.exists() and re.search(r"\[[A-ZÀ-Ú][A-ZÀ-Ú0-9 ,.:/_|'-]{2,}", ins.read_text(encoding="utf-8")):
    print("ATENCAO: ainda ha [CAMPOS] sem preencher em instrucoes_personalizadas.md")
print("Proximo passo: python scripts/70_varredura_privacidade.py, depois suba o conteudo de 04_project/ ao Project (guia/GUIA.md).")
