"""Passo 6 (so com fichas). Gera 01_nucleo/01_mapa.md a partir das fichas: tese central e autor de cada arquivo.
Nao acrescenta nada que as fichas nao digam.

Uso: python scripts/45_gerar_nucleo.py [--raiz PASTA]"""
import json, re, sys
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


ROOT = raiz()
cfg = json.loads((ROOT / "oraculo.json").read_text(encoding="utf-8")) if (ROOT / "oraculo.json").exists() else {}
NOME = cfg.get("nome", "Oraculo")


def campo(txt, *rotulos):
    for rot in rotulos:
        m = re.search(rf"\*\*{rot}:\*\*\s*(.+)", txt)
        if m: return m.group(1).strip()
    return "não consta"


def secao(txt, nome, n=420):
    m = re.search(rf"## {nome}\s*\n+(.*?)(?=\n## |\Z)", txt, re.S)
    if not m: return ""
    t = re.sub(r"\s+", " ", m.group(1)).strip()
    return t if len(t) <= n else t[:n].rsplit(" ", 1)[0] + "..."


pastas = sorted(p for p in (ROOT / "02_fichas").iterdir() if p.is_dir()) if (ROOT / "02_fichas").exists() else []
out = [f"# MAPA - {NOME}", "",
       "Gerado das fichas de estudo. Para cada arquivo: papel, autor e a tese central registrada na ficha. "
       "Detalhes e trechos literais estão nas fichas e nos textos integrais da base.", ""]
for d in pastas:
    fichas = sorted(d.glob("*.md"))
    if not fichas: continue
    out += [f"## {campo(fichas[0].read_text(encoding='utf-8'), 'Disciplina')}", ""]
    for f in fichas:
        t = f.read_text(encoding="utf-8")
        papel, autor, arq = campo(t, "Papel"), campo(t, "Autor", "Autor/professor"), campo(t, "Arquivo")
        tese = secao(t, "Tese central")
        if not tese or tese.lower().startswith("não se aplica"): tese = secao(t, "Resumo", 300) or secao(t, "Resumo \\(5 a 8 linhas\\)", 300)
        if len(autor) > 110: autor = autor[:110].rsplit(" ", 1)[0] + "..."
        out += [f"- **{arq}** ({papel}; autor: {autor})", f"  - {tese or 'sem tese central registrada'}"]
    out.append("")
(ROOT / "01_nucleo").mkdir(exist_ok=True)
(ROOT / "01_nucleo" / "01_mapa.md").write_text("\n".join(out), encoding="utf-8")
print(len(out), "linhas em 01_nucleo/01_mapa.md. Proximo passo: python scripts/50_montar_project.py")
