"""Passo 5. Conferidor de aspas: toda citacao entre aspas tem de existir, palavra por palavra, no texto de origem.

Modo 1 (as fichas do Oraculo):
  python scripts/41_qa_citacoes.py [--raiz PASTA]
  Le cada ficha de logs/lote_N.json e confere as aspas da secao "## Trechos literais" contra o texto bruto da ficha.

Modo 2 (qualquer arquivo seu, por exemplo a wiki de um Segundo Cerebro):
  python scripts/41_qa_citacoes.py --avulso <arquivo.md ou pasta> --contra <pasta com os textos de origem>
  Confere toda aspa com 25 caracteres ou mais dos arquivos .md contra o conjunto de textos da pasta --contra.

A comparacao ignora diferenca de espacos, quebra de linha, hifenizacao de fim de linha, maiusculas e aspas curvas.
Aspa que nao e encontrada vem listada: ou o trecho foi alterado, ou veio de outro texto, ou o texto de origem tem
erro de leitura (OCR). Nenhum caso se resolve sozinho: abra o original e decida. Relatorio em logs/qa_citacoes.txt."""
import json, re, sys, unicodedata
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


def pega(opcao):
    if opcao in sys.argv:
        i = sys.argv.index(opcao); v = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return v.resolve()
    return None


ROOT = raiz()
AVULSO, CONTRA = pega("--avulso"), pega("--contra")


def norm(s):
    s = unicodedata.normalize("NFC", s)
    s = re.sub(r"<!--.*?-->", " ", s)
    s = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", s)      # hifenizacao de fim de linha
    s = s.replace("‑", "-").replace("­", "")
    s = s.replace("“", '"').replace("”", '"').replace("‘", "'").replace("’", "'").replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", " ", s).strip().lower()


def aspas(txt, minimo):
    return re.findall(r'"([^"\n]{%d,})"' % minimo, txt.replace("“", '"').replace("”", '"'))


ok = ruins = semficha = 0; relatorio = []
if AVULSO:
    if not CONTRA: sys.exit("No modo --avulso informe tambem --contra <pasta com os textos de origem>.")
    base = norm("\n".join(f.read_text(encoding="utf-8", errors="ignore") for f in sorted(CONTRA.rglob("*")) if f.suffix in (".md", ".txt")))
    arqs = [AVULSO] if AVULSO.is_file() else sorted(AVULSO.rglob("*.md"))
    for fp in arqs:
        for c in aspas(fp.read_text(encoding="utf-8", errors="ignore"), 25):
            c2 = norm(c).strip(" .,;")
            if c2 and c2 in base: ok += 1
            else: ruins += 1; relatorio.append(f"ASPA NAO ENCONTRADA em {fp.name}: {c[:110]}")
else:
    bruto_por_ficha = {}
    for f in sorted((ROOT / "logs").glob("lote_*.json")):
        for it in json.loads(f.read_text(encoding="utf-8")): bruto_por_ficha[it["ficha"].replace(chr(92), "/")] = it["bruto"]
    if not bruto_por_ficha: sys.exit("Nenhum lote em logs/. Rode antes: python scripts/30_lotes.py")
    for ficha, bruto in bruto_por_ficha.items():
        fp = ROOT / ficha
        if not fp.exists(): semficha += 1; relatorio.append(f"SEM FICHA: {ficha}"); continue
        sec = fp.read_text(encoding="utf-8").split("## Trechos literais", 1)[-1].split("\n## ", 1)[0]
        b = norm((ROOT / bruto).read_text(encoding="utf-8"))
        for c in aspas(sec, 12):
            c2 = norm(c).strip(" .,;")
            if c2 and c2 in b: ok += 1
            else: ruins += 1; relatorio.append(f"CITACAO NAO ENCONTRADA em {ficha}: {c[:110]}")
print(f"citacoes ok={ok} nao_encontradas={ruins}" + ("" if AVULSO else f" fichas_ausentes={semficha}"))
(ROOT / "logs").mkdir(exist_ok=True)
(ROOT / "logs" / "qa_citacoes.txt").write_text("\n".join(relatorio), encoding="utf-8")
print("\n".join(relatorio[:20]))
sys.exit(1 if (ruins or semficha) else 0)
