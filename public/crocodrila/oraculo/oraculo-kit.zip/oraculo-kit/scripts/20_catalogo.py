"""Passo 2. Gera catalogo/catalogo.jsonl a partir de logs/extracao.json: um item por arquivo, com papel e qualidade do texto.

Uso: python scripts/20_catalogo.py [--raiz PASTA]

Qualidade do texto (decide o que fazer em seguida):
- texto_corrido          texto normal, pode virar ficha
- slides_telegraficos    pouco texto por pagina (slides); a ficha avisa
- sem_texto_precisa_ocr  PDF escaneado; rode scripts/32_ocr_pdf.py
Papel: "programa" (ementa, plano de ensino, syllabus) ou "leitura" (todo o resto).
Pode rodar de novo a qualquer hora: o que ja passou por OCR e preservado."""
import json, re, sys, unicodedata
from collections import Counter
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


ROOT = raiz()
rows = json.loads((ROOT / "logs" / "extracao.json").read_text(encoding="utf-8"))
cat_f = ROOT / "catalogo" / "catalogo.jsonl"
antigo = {}
if cat_f.exists():
    for l in cat_f.read_text(encoding="utf-8").splitlines():
        o = json.loads(l); antigo[o["id"]] = o


def slug(s, n=60):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:n]


def papel(r):
    a = r["arquivo"].lower()
    if any(x in a for x in ("plano de ensino", "ementa", "programa", "syllabus")): return "programa"
    return "leitura"


out, ids = [], set()
for r in rows:
    if r["tipo"] in ("ignorado", "duplicado", "erro"): continue
    cpp = r.get("chars_por_pag")
    if r["tipo"] == ".pdf" and cpp is not None and cpp < 150: qual = "sem_texto_precisa_ocr"
    elif r["tipo"] == ".pptx": qual = "slides_telegraficos"
    elif r["tipo"] == ".pdf" and cpp is not None and cpp < 700: qual = "slides_telegraficos"
    else: qual = "texto_corrido"
    i = f"{slug(r['disc'], 30)}--{slug(Path(r['bruto']).stem)}"
    if i in ids: i += "-" + r["md5"][:6]
    ids.add(i)
    item = {"id": i, "disciplina": r["disc"], "arquivo": r["arquivo"], "papel": papel(r), "paginas": r.get("paginas"),
            "chars": r.get("chars"), "qualidade_texto": qual, "bruto": r["bruto"],
            "status": "texto_extraido" if qual != "sem_texto_precisa_ocr" else "baixado"}
    if antigo.get(i, {}).get("qualidade_texto") == "ocr_tesseract":   # preserva o resultado do OCR
        item["qualidade_texto"] = "ocr_tesseract"; item["status"] = "texto_extraido"
    out.append(item)
cat_f.parent.mkdir(exist_ok=True)
cat_f.write_text("\n".join(json.dumps(o, ensure_ascii=False) for o in out), encoding="utf-8")
print(len(out), "itens"); print(dict(Counter(o["qualidade_texto"] for o in out))); print(dict(Counter(o["papel"] for o in out)))
print("grupos (disciplinas):", len({o["disciplina"] for o in out}))
falta = [o for o in out if o["qualidade_texto"] == "sem_texto_precisa_ocr"]
for o in out:
    if o["qualidade_texto"] == "sem_texto_precisa_ocr" or (o["chars"] or 0) < 1500: print("  atencao:", o["disciplina"][:30], "|", o["arquivo"][:60], o["paginas"], o["chars"])
print("Proximo passo:", "python scripts/32_ocr_pdf.py (ha " + str(len(falta)) + " PDF(s) escaneado(s))" if falta else "python scripts/30_lotes.py (se for fazer fichas) ou python scripts/50_montar_project.py (so a base)")
