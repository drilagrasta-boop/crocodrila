"""Passo 4 (so se for fazer fichas). Divide o catalogo em lotes de trabalho: logs/lote_1.json, lote_2.json...

Uso: python scripts/30_lotes.py [--raiz PASTA]

Cada lote e uma lista de itens (texto bruto, caminho da ficha a escrever, disciplina, papel, qualidade).
Um lote leva no maximo ~600 mil caracteres e 14 arquivos; livro grande (mais de 400 mil caracteres) fica sozinho no seu lote.
Depois, no Claude Code, peca uma ficha de cada lote (veja guia/GUIA.md).
Itens listados em catalogo/excluir_do_pacote.json (campo "id_exato") nao entram."""
import json, sys
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


ROOT = raiz()
cat = [json.loads(l) for l in (ROOT / "catalogo" / "catalogo.jsonl").read_text(encoding="utf-8").splitlines()]
exc_f = ROOT / "catalogo" / "excluir_do_pacote.json"
IDX = json.loads(exc_f.read_text(encoding="utf-8")).get("id_exato", []) if exc_f.exists() else []
cat = [o for o in cat if o["id"] not in IDX]
pend = [o for o in cat if o["qualidade_texto"] == "sem_texto_precisa_ocr"]
if pend:
    sys.exit(f"{len(pend)} PDF(s) ainda sem texto (precisam de OCR). Rode antes: python scripts/32_ocr_pdf.py")
for o in cat:
    o["bruto"] = o["bruto"].replace(chr(92), "/")
    o["ficha"] = o["bruto"].replace("03_brutos", "02_fichas", 1)
    o["qualidade"] = o.pop("qualidade_texto"); o.pop("status", None)
cat.sort(key=lambda o: (o["disciplina"], o["arquivo"]))
lotes = [[o] for o in cat if o["chars"] > 400000]
cur, c = [], 0
for o in (o for o in cat if o["chars"] <= 400000):
    if cur and (c + o["chars"] > 600000 or len(cur) >= 14):
        lotes.append(cur); cur, c = [], 0
    cur.append(o); c += o["chars"]
if cur: lotes.append(cur)
(ROOT / "logs").mkdir(exist_ok=True)
(ROOT / "02_fichas").mkdir(exist_ok=True)
for i, l in enumerate(lotes, 1):
    (ROOT / "logs" / f"lote_{i}.json").write_text(json.dumps(l, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"lote_{i}.json: {len(l)} arquivo(s), {sum(o['chars'] for o in l)} caracteres")
antigos = [f.name for f in (ROOT / "logs").glob("lote_*.json") if int(f.stem.split("_")[1]) > len(lotes)]
if antigos: print("Atencao: sobraram lotes de uma rodada anterior, apague-os na mao:", antigos)
print("Proximo passo: peca as fichas ao Claude Code (guia/GUIA.md, passo 5).")
