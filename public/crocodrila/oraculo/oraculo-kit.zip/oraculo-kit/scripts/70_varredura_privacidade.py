"""Passo 8. Varredura de dados pessoais ANTES de subir o pacote: procura CPF, CNPJ, e-mail, telefone e os termos
que voce listar em oraculo.json (campo "termos_sensiveis": seu nome, seu endereco, nome de familiares...).

Uso: python scripts/70_varredura_privacidade.py [--raiz PASTA]

Varre 04_project/ (o que vai para o Project). Mostra no maximo 3 ocorrencias por tipo e arquivo, com um pedaco do contexto.
Nao decide nada: ocorrencia pode ser legitima (e-mail de um autor num artigo) ou pode ser um documento que nao devia
estar na base. Se for o segundo caso, tire o arquivo de fontes/, ou liste o id em catalogo/excluir_do_pacote.json, e monte de novo."""
import json, re, sys
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


ROOT = raiz()
cfg = json.loads((ROOT / "oraculo.json").read_text(encoding="utf-8")) if (ROOT / "oraculo.json").exists() else {}
PADROES = {
    "CPF": r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b",
    "CNPJ": r"\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b",
    "e-mail": r"[\w.+-]+@[\w-]+\.[\w.-]+",
    "telefone": r"\(?\b\d{2}\)?\s?9?\d{4}-\d{4}\b",
}
for t in cfg.get("termos_sensiveis", []):
    if t.strip(): PADROES[f"termo '{t}'"] = re.escape(t)
alvo = ROOT / "04_project"
if not alvo.exists(): sys.exit("Nao ha 04_project/. Rode antes: python scripts/50_montar_project.py")
total = 0
for f in sorted(alvo.rglob("*")):
    if not f.is_file() or f.suffix not in (".txt", ".md"): continue
    txt = f.read_text(encoding="utf-8", errors="ignore")
    for nome, pad in PADROES.items():
        achados = list(re.finditer(pad, txt, re.I if nome.startswith("termo") else 0))
        if not achados: continue
        total += len(achados)
        print(f"{f.relative_to(alvo)}: {len(achados)} x {nome}")
        for m in achados[:3]:
            a, b = max(0, m.start() - 40), min(len(txt), m.end() + 40)
            print("    ...", txt[a:b].replace("\n", " "), "...")
print("Nenhuma ocorrencia." if not total else f"{total} ocorrencia(s) para voce avaliar.")
