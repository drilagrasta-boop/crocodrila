"""Passo 1. Extrai o texto de cada arquivo de fontes/ para 03_brutos/<pasta>/ com marcador <!-- p. N --> (slide N nos PPTX).

Uso: python scripts/10_extrair.py [--raiz PASTA] [--incluir lista.json]

- A pasta de primeiro nivel dentro de fontes/ e a "disciplina" (pode ser curso, tema, assunto).
  Arquivos soltos em fontes/ entram em "_geral".
- --incluir: JSON com a lista de caminhos relativos (a partir de fontes/) que devem entrar; o resto e ignorado.
- Arquivos identicos (mesmo md5) entram uma vez so.
- Texto que ja passou por OCR (catalogo marca ocr_tesseract) nao e sobrescrito."""
import sys, re, json, unicodedata, hashlib
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


ROOT = raiz()
INC = None
if "--incluir" in sys.argv:
    i = sys.argv.index("--incluir")
    INC = {unicodedata.normalize("NFC", x).replace(chr(92), "/") for x in json.loads(Path(sys.argv[i + 1]).read_text(encoding="utf-8"))}

try:
    import fitz, docx, openpyxl
    from bs4 import BeautifulSoup
    from pptx import Presentation
except ImportError as e:
    sys.exit(f"Falta instalar um pacote ({e.name}). Rode: pip install -r requirements.txt")

SRC, OUT = ROOT / "fontes", ROOT / "03_brutos"
NFC = lambda s: unicodedata.normalize("NFC", s)


def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:40] or "x"


def docx_text(p):
    d = docx.Document(p)
    parts = [x.text for x in d.paragraphs]
    for t in d.tables:
        for r in t.rows:
            parts.append(" | ".join(c.text.strip() for c in r.cells))
    return "\n".join(parts)


def pptx_text(p):
    out = []
    for i, s in enumerate(Presentation(p).slides, 1):
        linhas = []
        for sh in s.shapes:
            if sh.has_text_frame:
                linhas += [x.text.strip() for x in sh.text_frame.paragraphs if x.text.strip()]
            if getattr(sh, "has_table", False) and sh.has_table:
                for r in sh.table.rows:
                    linhas.append(" | ".join(c.text.strip() for c in r.cells))
        if s.has_notes_slide and s.notes_slide.notes_text_frame.text.strip():
            linhas.append("[notas do apresentador] " + s.notes_slide.notes_text_frame.text.strip())
        out.append(f"\n<!-- p. {i} -->\n" + "\n".join(linhas))
    return "".join(out), len(out)


def html_text(p):
    soup = BeautifulSoup(p.read_text(encoding="utf-8", errors="ignore"), "html.parser")
    for t in soup(["script", "style"]): t.decompose()
    return re.sub(r"\n\s*\n+", "\n\n", soup.get_text("\n"))


def xlsx_text(p):
    wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
    out = []
    for ws in wb.worksheets:
        out.append(f"\n## Planilha: {ws.title}")
        for row in ws.iter_rows(values_only=True):
            if any(c is not None for c in row):
                out.append(" | ".join("" if c is None else str(c) for c in row))
    return "\n".join(out)


if not SRC.exists() or not any(SRC.rglob("*")):
    sys.exit(f"Nada em {SRC}. Ponha ali os arquivos (uma subpasta por disciplina ou assunto) e rode de novo.")

ocr_feito = set()
cat_f = ROOT / "catalogo" / "catalogo.jsonl"
if cat_f.exists():
    for l in cat_f.read_text(encoding="utf-8").splitlines():
        o = json.loads(l)
        if o.get("qualidade_texto") == "ocr_tesseract": ocr_feito.add(o["bruto"].replace(chr(92), "/"))

TIPOS = (".pdf", ".docx", ".pptx", ".html", ".xlsx", ".md", ".txt")
rows, usados, seen = [], set(), {}
for f in sorted(x for x in SRC.rglob("*") if x.is_file()):
    rel = f.relative_to(SRC)
    if INC is not None and NFC(str(rel)).replace(chr(92), "/") not in INC: continue
    parts = rel.parts
    discname = NFC(parts[0]) if len(parts) > 1 else "_geral"
    arq = NFC("/".join(parts[1:] if len(parts) > 1 else parts))
    ds = slug(discname)
    ext = f.suffix.lower()
    if ext == "" and f.read_bytes()[:2] == b"PK": ext = ".pptx"   # PowerPoint salvo sem extensao
    if ext not in TIPOS:
        rows.append({"disc": discname, "arquivo": arq, "tipo": "ignorado"}); continue
    md5 = hashlib.md5(f.read_bytes()).hexdigest()
    if md5 in seen:
        rows.append({"disc": discname, "arquivo": arq, "tipo": "duplicado", "duplicado_de": seen[md5]}); continue
    seen[md5] = f"{ds}/{slug(f.stem)}"
    o = OUT / ds; o.mkdir(parents=True, exist_ok=True)
    dest = o / (slug(f.stem) + ".md")
    if dest in usados: dest = o / (slug(f.stem) + "-" + md5[:6] + ".md")
    usados.add(dest)
    bruto = dest.relative_to(ROOT).as_posix()
    pages = 0
    try:
        if bruto in ocr_feito and dest.exists():
            txt = dest.read_text(encoding="utf-8")
            pages = len(re.findall(r"<!-- p\. \d+ -->", txt))
        elif ext == ".pdf":
            doc = fitz.open(f); pages = len(doc)
            txt = "".join(f"\n<!-- p. {i + 1} -->\n{pg.get_text()}" for i, pg in enumerate(doc))
        elif ext == ".docx": txt = docx_text(f)
        elif ext == ".pptx": txt, pages = pptx_text(f)
        elif ext == ".html": txt = html_text(f)
        elif ext == ".xlsx": txt = xlsx_text(f)
        else: txt = f.read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        rows.append({"disc": discname, "arquivo": arq, "tipo": "erro", "erro": str(e)[:200]}); continue
    if not (bruto in ocr_feito and dest.exists()): dest.write_text(txt, encoding="utf-8")
    chars = len(re.sub(r"\s", "", txt))
    rows.append({"disc": discname, "arquivo": arq, "tipo": ext, "md5": md5, "paginas": pages, "chars": chars,
                 "chars_por_pag": round(chars / pages) if pages else None, "bruto": bruto})

(ROOT / "logs").mkdir(exist_ok=True)
(ROOT / "logs" / "extracao.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
from collections import Counter
print(Counter(r["tipo"] for r in rows)); print("caracteres no total:", sum(r.get("chars", 0) for r in rows))
for r in rows:
    if r["tipo"] in ("erro", "ignorado", "duplicado"): print(r["tipo"], "|", r["disc"], "|", r["arquivo"], r.get("erro", ""))
print("Proximo passo: python scripts/20_catalogo.py")
