"""Passo 3 (so se houver PDF escaneado). OCR com Tesseract dos itens "sem_texto_precisa_ocr" do catalogo.

Uso:
  python scripts/32_ocr_pdf.py [--raiz PASTA]                    faz o OCR de todos os pendentes
  python scripts/32_ocr_pdf.py <trecho-do-id> [--giro]            refaz so o item cujo id contem o trecho
--giro testa cada pagina em 4 rotacoes (0, 180, 90, 270) e fica com a que leu mais palavras: use quando o
resultado sair como letras sem sentido (pagina escaneada de cabeca para baixo).

Precisa do Tesseract instalado (ver COMECE-AQUI.txt) e do idioma. Configuracao opcional em oraculo.json:
  "idioma_ocr" (padrao "por") e "tesseract" (caminho do programa, se nao estiver no PATH)."""
import io, json, re, shutil, sys
from pathlib import Path


def raiz():
    if "--raiz" in sys.argv:
        i = sys.argv.index("--raiz"); r = Path(sys.argv[i + 1]); del sys.argv[i:i + 2]
        return r.resolve()
    return Path(__file__).resolve().parent.parent


ROOT = raiz()
GIRO = "--giro" in sys.argv
args = [a for a in sys.argv[1:] if not a.startswith("--")]
filtro = args[0] if args else None
try:
    import fitz, pytesseract
    from PIL import Image
except ImportError as e:
    sys.exit(f"Falta instalar um pacote ({e.name}). Rode: pip install -r requirements.txt")
Image.MAX_IMAGE_PIXELS = None
cfg = json.loads((ROOT / "oraculo.json").read_text(encoding="utf-8")) if (ROOT / "oraculo.json").exists() else {}
IDIOMA = cfg.get("idioma_ocr", "por")
exe = cfg.get("tesseract") or shutil.which("tesseract")
for cand in (r"C:\Program Files\Tesseract-OCR\tesseract.exe", r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe", "/usr/bin/tesseract", "/opt/homebrew/bin/tesseract"):
    if not exe and Path(cand).exists(): exe = cand
if not exe:
    sys.exit("Tesseract nao encontrado. Instale (veja COMECE-AQUI.txt) ou informe o caminho em oraculo.json (campo \"tesseract\").")
pytesseract.pytesseract.tesseract_cmd = exe
FUNC = re.compile(r"\b(de|que|a|o|e|do|da|em|um|para|com|não|uma|os|as|se|na|no)\b")   # palavras comuns do portugues
score = lambda t: len(FUNC.findall(t))
SRC = ROOT / "fontes"
cat_f = ROOT / "catalogo" / "catalogo.jsonl"
cat = [json.loads(l) for l in cat_f.read_text(encoding="utf-8").splitlines()]


def ocr(im):
    err = None
    for _ in range(3):
        try:
            return pytesseract.image_to_string(im, lang=IDIOMA, timeout=180)
        except Exception as e:
            err = e
    print("   falha numa pagina:", str(err)[:80], flush=True)
    return ""


feitos = 0
for it in cat:
    if filtro:
        if filtro not in it["id"]: continue
    elif it["qualidade_texto"] != "sem_texto_precisa_ocr": continue
    pdf = SRC / ("" if it["disciplina"] == "_geral" else it["disciplina"]) / it["arquivo"]
    if not pdf.exists(): print("arquivo nao encontrado:", pdf); continue
    doc = fitz.open(pdf); partes = []; rots = []
    for i, pg in enumerate(doc):
        img = Image.open(io.BytesIO(pg.get_pixmap(dpi=200 if GIRO else 300).tobytes("png")))
        if GIRO:
            cands = []
            for nome, im in (("0", img), ("180", img.rotate(180)), ("90", img.rotate(90, expand=True)), ("270", img.rotate(270, expand=True))):
                t = ocr(im); cands.append((score(t), nome, t))
                if nome == "0" and score(t) * 1000 / max(1, len(t)) > 60: break   # ja leu bem: nao testa as outras
            _, nome, txt_pg = max(cands, key=lambda c: c[0]); rots.append(nome)
        else:
            txt_pg = ocr(img)
        partes.append(f"\n<!-- p. {i + 1} -->\n" + txt_pg)
    txt = "".join(partes)
    (ROOT / it["bruto"]).write_text(txt, encoding="utf-8")
    it["qualidade_texto"] = "ocr_tesseract"; it["status"] = "texto_extraido"
    it["chars"] = len("".join(txt.split()))
    dens = score(txt) * 1000 / max(1, it["chars"])
    aviso = "  <- parece ilegivel: tente --giro" if IDIOMA == "por" and not GIRO and dens < 25 else ""
    print(it["paginas"], "p |", it["chars"], "chars |", it["id"][:60], aviso, flush=True)
    feitos += 1
cat_f.write_text("\n".join(json.dumps(o, ensure_ascii=False) for o in cat), encoding="utf-8")
print(feitos, "item(ns) com OCR. Proximo passo: python scripts/30_lotes.py (fichas) ou python scripts/50_montar_project.py (so a base)")
