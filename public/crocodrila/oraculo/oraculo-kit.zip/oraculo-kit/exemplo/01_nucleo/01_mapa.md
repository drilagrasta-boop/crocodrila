# MAPA - Oráculo da Oficina de Cartografia Fluvial (exemplo fictício)

Gerado das fichas de estudo. Para cada arquivo: papel, autor e a tese central registrada na ficha. Detalhes e trechos literais estão nas fichas e nos textos integrais da base.

## Oficina de Cartografia Fluvial

- **Moura - O rio que muda de lugar.pdf** (leitura; autor: Helena Bastos Moura (autora fictícia), 2019)
  - O mapa de um rio é um documento histórico e não um documento geográfico: informa onde o rio estava na data da medição (p. 1).
- **Valadares - Guia de campo para ler uma carta de cheias.pdf** (leitura; autor: Ciro Valadares (autor fictício), 2021)
  - Uma carta de cheias descreve a cheia de referência escolhida pelo projeto, e não o rio; por isso deve ser lida pela legenda, pela data e pela borda antes de servir a uma decisão (pp. 1-2).
