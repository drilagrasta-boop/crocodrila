# FICHA — Guia de campo para ler uma carta de cheias

- **Disciplina:** Oficina de Cartografia Fluvial
- **Arquivo:** Valadares - Guia de campo para ler uma carta de cheias.pdf
- **Papel:** leitura
- **Autor:** Ciro Valadares (autor fictício), 2021
- **Qualidade do texto:** texto_corrido
- **Bruto:** 03_brutos/oficina-de-cartografia-fluvial/valadares-guia-de-campo-para-ler-uma-car.md

## Resumo

Guia prático para quem decide com uma carta de cheias na mão. O autor não ensina a fazer a carta, e sim a lê-la com desconfiança na medida certa (p. 1). Propõe quatro leituras em ordem: a legenda, a data do levantamento, a borda da mancha e o que a carta não mostra, como a água da chuva que não escoa (pp. 1-2). Fecha dizendo que uma boa carta não elimina a dúvida, e a coloca no lugar certo (p. 2).

## Tese central

Uma carta de cheias descreve a cheia de referência escolhida pelo projeto, e não o rio; por isso deve ser lida pela legenda, pela data e pela borda antes de servir a uma decisão (pp. 1-2).

## Conceitos-chave

- **Cheia de referência** — escolha de projeto; muitas cartas adotam a de retorno de cem anos, com uma chance em cem de ocorrer em qualquer ano (p. 1)
- **Faixa de incerteza** — a borda da mancha de cheia não é uma linha, é uma faixa (p. 2)

## Argumento passo a passo

1. Começar pela legenda, que diz qual cheia o mapa imagina (p. 1).
2. Conferir a data do levantamento topográfico e se a cidade mudou depois dele (p. 2).
3. Tratar a borda como faixa de incerteza: alagada, se há pessoas; metade alagada, se é só estimativa de custo (p. 2).
4. Lembrar que a carta costuma esquecer a água de chuva que não encontra saída (p. 2).

## Trechos literais

> "A legenda diz qual cheia o mapa imagina, e é essa cheia, não o rio, que o mapa descreve." (p. 1)

> "A borda de uma mancha de cheia deve ser lida como um convite à cautela, nunca como uma cerca." (p. 2)

> "Uma carta de cheias boa não elimina a dúvida." (p. 2)

## Conexões e debates

O texto não cita outros autores.

## Perguntas de estudo

1. O que significa dizer que a cheia de cem anos "só acontece de cem em cem anos"? Por que a ideia está errada segundo o guia?
2. Como o guia manda tratar a faixa de incerteza quando há pessoas envolvidas?
