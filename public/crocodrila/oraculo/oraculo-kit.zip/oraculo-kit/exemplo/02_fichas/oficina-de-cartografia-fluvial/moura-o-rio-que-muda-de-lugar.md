# FICHA — O rio que muda de lugar

- **Disciplina:** Oficina de Cartografia Fluvial
- **Arquivo:** Moura - O rio que muda de lugar.pdf
- **Papel:** leitura
- **Autor:** Helena Bastos Moura (autora fictícia), 2019
- **Qualidade do texto:** texto_corrido
- **Bruto:** 03_brutos/oficina-de-cartografia-fluvial/moura-o-rio-que-muda-de-lugar.md

## Resumo

Ensaio curto sobre o limite do mapa de rio. A autora sustenta que a carta de um rio de planície registra onde o rio estava quando alguém mediu, e que ele se desloca de lado ao longo do tempo (p. 1). Compara três levantamentos do rio ficcional Aratu, de 1931, 1958 e 1994, e mostra que a curva do Cotovelo andou cerca de 640 metros para o leste, quase tudo em duas cheias excepcionais (p. 2). Conclui com duas recomendações: datar as cartas e desconfiar de limites de propriedade fixados pelo leito do rio (p. 2).

## Tese central

O mapa de um rio é um documento histórico e não um documento geográfico: informa onde o rio estava na data da medição (p. 1).

## Conceitos-chave

- **Meandro** — curva do rio de planície, que corrói a margem externa e deposita areia na interna (p. 1)
- **Deslocamento por saltos** — o rio quase não se mexe nos anos comuns e muda de lugar nas cheias grandes (p. 2)

## Argumento passo a passo

1. O mapa promete uma permanência que o rio não tem (p. 1).
2. Em planícies de sedimento o canal avança lateralmente alguns metros por ano e pode estar a quilômetros da posição da carta em um século (p. 1).
3. Três levantamentos do Aratu mostram deslocamento de cerca de 640 metros, concentrado nas cheias de 1947 e 1983 (p. 2).
4. Por isso a distância entre dois levantamentos mede o número de cheias grandes do intervalo, e não a velocidade do rio (p. 2).
5. Recomendações: datar a carta e cuidar com limites de propriedade definidos pelo leito (p. 2).

## Trechos literais

> "Todo mapa de rio faz uma promessa que o rio não cumpre: a de ficar onde foi desenhado." (p. 1)

> "o mapa de um rio é um documento histórico e não um documento geográfico" (p. 1)

> "O rio muda de lugar aos saltos, e o mapa registra apenas os intervalos entre os saltos." (p. 2)

> "Um mapa sem data é uma afirmação sem fonte." (p. 2)

## Conexões e debates

O texto não cita outros autores. A recomendação final aproxima o assunto do direito de propriedade, que a autora diz tratar como permanente o que a geografia trata como provisório (p. 2).

## Perguntas de estudo

1. Por que a distância entre dois mapas não mede a velocidade do rio?
2. O que muda na leitura de uma carta quando se sabe a data da medição e das últimas cheias?
3. Por que um limite de propriedade fixado pelo leito do rio é um problema?
