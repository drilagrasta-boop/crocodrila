
<!-- p. 1 -->
O RIO QUE MUDA DE LUGAR
Helena Bastos Moura (autora fictícia), 2019
(Texto inventado para demonstração do kit Oráculo. Não existe fora
deste exemplo.)
1. O mapa é uma promessa
Todo mapa de rio faz uma promessa que o rio não cumpre: a de ficar
onde foi desenhado. A cartógrafa que traça o leito de um rio de planície
desenha, na verdade, uma fotografia lenta, e a fotografia envelhece
mais depressa do que o papel.
Em planícies de sedimento, o rio meandra. A curva externa corrói a
margem, a curva interna deposita areia, e o conjunto avança
lateralmente alguns metros por ano. Em um século, o canal pode estar a
quilômetros do ponto em que a carta o registrou.
A tese deste ensaio é simples: o mapa de um rio é um documento
histórico e não um documento geográfico. Ele informa onde o rio estava
quando alguém mediu, e só por extensão onde ele está.

<!-- p. 2 -->
2. Três cheias, três mapas
A autora compara três levantamentos do mesmo trecho do rio ficcional
Aratu, feitos em 1931, 1958 e 1994. Entre o primeiro e o último, a curva
do Cotovelo se deslocou cerca de 640 metros para o leste.
O deslocamento não foi constante. Quase todo ele ocorreu em duas
cheias excepcionais, a de 1947 e a de 1983. Nos anos comuns, o rio
mal se mexeu. "O rio muda de lugar aos saltos, e o mapa registra
apenas os intervalos entre os saltos."
Disso decorre uma regra prática para quem lê cartas antigas: a distância
entre dois levantamentos não mede a velocidade do rio, mede o número
de cheias grandes que couberam no intervalo.
3. O que fazer com isso
A autora recomenda que toda carta fluvial traga, no canto, a data da
medição e a data das últimas cheias conhecidas. "Um mapa sem data é
uma afirmação sem fonte." Recomenda também que se desconfie de
limites de propriedade fixados pelo leito do rio, porque o direito costuma
tratar como permanente aquilo que a geografia trata como provisório.
