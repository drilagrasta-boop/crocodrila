
<!-- p. 1 -->
GUIA DE CAMPO PARA LER UMA CARTA DE CHEIAS
Ciro Valadares (autor fictício), 2021
(Texto inventado para demonstração do kit Oráculo. Não existe fora
deste exemplo.)
Antes de começar
Este guia é para quem precisa decidir alguma coisa com uma carta de
cheias na mão: onde construir, onde não construir, por onde evacuar.
Não ensina a fazer a carta. Ensina a desconfiar dela na medida certa,
que é uma medida pequena: quem desconfia demais não usa o mapa, e
quem confia demais usa o mapa errado.
Primeira leitura: a legenda
Comece sempre pela legenda. A cor mais escura costuma indicar a
mancha que a água ocupa na cheia de referência, e a cheia de
referência quase nunca é a maior possível. "A legenda diz qual cheia o
mapa imagina, e é essa cheia, não o rio, que o mapa descreve."
Cheia de referência é uma escolha de projeto. Muitas cartas adotam a
cheia com retorno de cem anos, que tem, em qualquer ano, uma chance
em cem de ocorrer. Isso não quer dizer que ela só acontece de cem em
cem anos. Duas cheias assim podem vir em anos seguidos, e nada na
estatística impede.
Quem lê a carta pela primeira vez costuma procurar a própria rua.
Procure antes a escala, a data e a legenda; a rua vem depois, e vem
melhor.

<!-- p. 2 -->
Segunda leitura: a data
Verifique o ano do levantamento topográfico que serve de base. Se a
cidade cresceu depois dele, aterros, ruas e muros mudaram o caminho
da água, e a mancha desenhada já não vale. Pergunte também quem
refez as contas: uma carta que só trocou a data de capa continua sendo
a carta antiga.
Terceira leitura: a borda
A borda da mancha parece uma linha, mas é uma faixa de incerteza. "A
borda de uma mancha de cheia deve ser lida como um convite à
cautela, nunca como uma cerca."
Quando a decisão envolve pessoas, trate a faixa de incerteza como se
já estivesse alagada. Quando envolve apenas uma estimativa de custo,
trate-a como metade alagada. Em qualquer caso, anote a regra que
você adotou, para que outra pessoa possa discordar dela depois.
Quarta leitura: o que a carta não mostra
Cartas de cheia costumam mostrar a água que vem do rio e esquecer a
água que vem da chuva e não encontra por onde sair. Bueiro entupido
não aparece em nenhuma legenda.
Última palavra
Uma carta de cheias boa não elimina a dúvida. Ela a coloca no lugar
certo, com cor e com data, para que a decisão seja de quem decide e
não do mapa.
