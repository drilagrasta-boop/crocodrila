# Guia do Oráculo

Como transformar o seu material de estudo (ou de trabalho) num assistente que responde citando o texto, com página, e que diz "não encontrei isso no material" quando não encontra.

O método tem uma ideia só, repetida em cada etapa: **o assistente só pode afirmar o que está nos seus arquivos, e toda aspa dele pode ser conferida**.

## O que você precisa

- **Python 3.10 ou mais novo.** Instale os pacotes uma vez: `pip install -r requirements.txt`.
- **Uma conta do claude.ai** com a função Projects (confira no seu plano). É lá que o Oráculo mora. Nada precisa ficar instalado depois de pronto.
- **Tesseract**, só se você tiver PDF escaneado (aquele em que não dá para selecionar o texto). Windows: instale o programa do projeto UB Mannheim e marque o idioma Portuguese na instalação. Mac: `brew install tesseract tesseract-lang`. Linux: `apt install tesseract-ocr tesseract-ocr-por`.
- **Claude Code**, só se você quiser as fichas (passo 5). Sem fichas o Oráculo funciona do mesmo jeito, só com a base de textos. As fichas deixam as respostas melhores porque servem de mapa.

## Teste rápido com o exemplo (5 minutos)

A pasta `exemplo/` traz um mini-projeto fictício completo: dois textos inventados, as fichas, o pacote pronto e as instruções preenchidas. Para ver cada etapa funcionando:

```
python scripts/10_extrair.py --raiz exemplo
python scripts/20_catalogo.py --raiz exemplo
python scripts/41_qa_citacoes.py --raiz exemplo
python scripts/45_gerar_nucleo.py --raiz exemplo
python scripts/50_montar_project.py --raiz exemplo
python scripts/70_varredura_privacidade.py --raiz exemplo
```

Abra `exemplo/04_project/` e veja o que seria enviado ao Project. Depois estrague de propósito uma aspa numa ficha de `exemplo/02_fichas/` e rode o `41_qa_citacoes.py` de novo: ele aponta a aspa que não bate com o texto.

## O seu Oráculo, passo a passo

### 1. Escolha o que entra (a parte mais importante)

Ponha em `fontes/` só o que você quer que o assistente cite. Uma subpasta por disciplina, curso ou assunto. Leia o `fontes/LEIA-ME.txt`.

Deixe de fora: documento pessoal (RG, extrato, boleto, laudo, histórico escolar), trabalho seu ainda não entregue, rascunho, resumo feito por IA (a IA resumiria o resumo e o erro cresce) e arquivo duplicado. O extrator já descarta cópias idênticas, mas não adivinha o que é pessoal.

### 2. Dê um nome e extraia o texto

Abra `oraculo.json` e troque o nome. Em `termos_sensiveis` ponha o que não pode vazar (seu nome completo, endereço, nomes de familiares); o passo 8 vai procurar por eles. Depois:

```
python scripts/10_extrair.py
python scripts/20_catalogo.py
```

O primeiro cria um arquivo de texto por documento em `03_brutos/`, com o marcador `<!-- p. N -->` no começo de cada página (ou slide). É esse marcador que permite citar a página. O segundo faz o catálogo e diz quais PDFs vieram sem texto.

### 3. OCR dos PDFs escaneados (se houver)

```
python scripts/32_ocr_pdf.py
```

Demora (alguns segundos por página). Se algum resultado sair como letras sem sentido, a página provavelmente está de cabeça para baixo ou de lado. Refaça só esse item:

```
python scripts/32_ocr_pdf.py <trecho-do-nome> --giro
```

O `--giro` testa as quatro rotações de cada página e fica com a que leu mais palavras.

### 4. Confira o que foi extraído

Abra no bloco de notas dois ou três arquivos de `03_brutos/`, de preferência o maior e o mais feio. Procure: página faltando, coluna embaralhada, tabela virando coluna de números, letras trocadas. O Oráculo não corrige isso, ele herda. O que for ilegível vai ficar ilegível para ele também, e você precisa saber disso.

### 5. Fichas (opcional, recomendado)

A ficha é um resumo de cada documento, com tese, conceitos, trechos literais e página. Ela serve de mapa: o assistente acha o texto certo mais depressa e responde melhor.

```
python scripts/30_lotes.py
```

Isso divide o material em lotes (`logs/lote_1.json`...). Abra o Claude Code na pasta do projeto e peça, um lote por vez:

```
Leia modelo/instrucoes_fichas.md e siga-o. Seu lote: logs/lote_1.json
```

Para muitos lotes, o Claude Code pode disparar vários agentes ao mesmo tempo, um por lote. Cada ficha segue `modelo/TEMPLATE_ficha.md`.

### 6. Confira as aspas

```
python scripts/41_qa_citacoes.py
```

Esta é a etapa que separa o Oráculo de um resumo qualquer. O script lê cada trecho entre aspas das fichas e procura, palavra por palavra, no texto de origem. Ignora só diferença de espaço, quebra de linha, hifenização de fim de linha e aspas curvas. Aspa que não existe no texto vem listada. Abra o original e decida: corrija a ficha ou tire as aspas.

Em texto de OCR ruim, às vezes a aspa não passa porque o OCR separou as letras. Nesse caso, tire as aspas e deixe a frase como paráfrase, com o aviso "conferir no PDF".

### 7. Monte o pacote

```
python scripts/45_gerar_nucleo.py
python scripts/50_montar_project.py
```

O primeiro faz o mapa (tese e autor de cada arquivo, tirados das fichas). O segundo cria a pasta `04_project/` e, se ainda não existir, copia para lá o modelo de instruções. **Abra `04_project/instrucoes_personalizadas.md` e preencha todos os [CAMPOS]**; o script avisa se sobrar algum.

Para tirar um item da base sem apagar o arquivo, ponha o id dele em `catalogo/excluir_do_pacote.json` (crie o arquivo se não existir):

```
{"id_exato": ["id-do-item"], "arquivo_contem": []}
```

### 8. Varredura de privacidade

```
python scripts/70_varredura_privacidade.py
```

Procura CPF, CNPJ, e-mail, telefone e os termos que você listou. Ocorrência não é sentença: o e-mail de um autor num artigo é normal. Mas CPF e telefone quase sempre indicam um documento que não devia estar ali.

### 9. Crie o Project no claude.ai

1. No claude.ai, crie um Project novo com o nome do seu Oráculo.
2. Em **instruções**, cole o texto de `04_project/instrucoes_personalizadas.md`.
3. Em **conhecimento do projeto**, envie os arquivos de `04_project/base/`, de `04_project/fichas/` (se tiver) e os dois índices (`00_INDICE.txt` e `01_MAPA.txt`).
4. Confira se todos entraram. Cada arquivo tem de caber no limite de envio do claude.ai (confira o valor atual; o da base costuma ficar em poucos megabytes).

### 10. Teste antes de confiar

Faça no mínimo três perguntas:

- **Uma que a base responde.** Peça a citação literal e a página. Abra o PDF original e confira, a primeira vez sempre.
- **Uma que a base não responde.** O certo é ele dizer "não encontrei isso no material". Se ele inventar, algo está errado nas instruções.
- **Uma que cruza dois textos.** Veja se ele diz de qual arquivo vem cada lado.

## Atualizar depois

Chegou material novo? Ponha em `fontes/`, rode `10_extrair.py`, `20_catalogo.py` (o que já passou por OCR é preservado), faça as fichas dos itens novos e monte de novo. Depois envie ao Project os arquivos que mudaram, apagando antes os antigos de mesmo nome.

## O que o Oráculo não resolve

- **Tabela e gráfico.** Saem como colunas de números soltos ou somem. Se a resposta depende de uma tabela, confira no original.
- **Recorte de livro.** Muito material de curso é um capítulo solto. O assistente deve dizer "recorte"; mesmo assim, desconfie de resposta sobre "o livro" feita com um capítulo.
- **Página do PDF não é página do livro.** O marcador segue o PDF. Ao citar em trabalho, converta para a paginação impressa.
- **OCR erra.** Por isso as fichas de OCR trazem aviso. Citação para publicar se confere no PDF.
- **Ficha é resumo de IA.** Serve para achar, não para citar. A citação vem da base.
- **O assistente não substitui a leitura.** Ele devolve o que está no material; interpretar continua com você.
