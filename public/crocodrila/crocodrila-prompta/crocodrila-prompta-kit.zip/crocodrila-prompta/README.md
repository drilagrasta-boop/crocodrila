# Prompt Library (crocodrila prompta)

Paleta de prompts em AutoHotkey v2. Um atalho global abre uma busca sobre prompts guardados em arquivos YAML; ao escolher um, o script preenche as variáveis (quando houver) e cola o texto no aplicativo ativo.

Instalação e primeiros passos: `LEIA-ME-PRIMEIRO.md`.

## Estrutura

- `prompt-library.ahk` — ponto de entrada: carrega config e prompts, registra atalhos e o menu da bandeja.
- `lib/` — módulos: `YamlParser`, `ConfigLoader`, `PromptLoader`, `ClipboardPaster`, `SearchGui`, `VariableGui`, `TrayMenu`.
- `prompts/<área>/<tarefa>/*.yaml` — os prompts. A área e a tarefa vêm dos nomes das pastas.
- `config.yaml` — atalhos, largura da janela, número de resultados.
- `watchdog.ahk` — vigia: reabre a paleta se ela parar.
- `gerar_catalogo.py` — gera um catálogo (.docx) dos prompts.
- `sincronizar_padrao.py` + `padroes/` — mantém um bloco de texto comum no fim dos prompts listados em `padroes/alvos.txt`.
- `subir-mudancas.bat` — commit e push em um clique.
- `assets/`, `tests/`.

## Testes

- Python: `pytest`
- AutoHotkey: dois cliques em `tests/test-yaml-parser.ahk` e `tests/test-prompt-loader.ahk` (mostram uma janela com o resultado). O segundo depende dos prompts de `prompts/exemplos/`.

## Aviso

Se os seus prompts tiverem material pessoal ou de trabalho, mantenha o repositório **privado**.
