# -*- coding: utf-8 -*-
"""Builds catalogo-prompts.docx by scanning the prompts/ folder.

The catalog is no longer hand-written: every entry comes from the `name` and
`description` fields of each YAML file, and the categories come from the
directory structure. Adding a prompt to prompts/ is enough — just run this
script again.
"""

import io
import os
from datetime import date

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn

PROMPTS_DIRNAME = "prompts"
VALID_EXTENSIONS = (".yaml", ".yml")
ROOT_LABEL = "Raiz"

# Top-level folders in display order; anything else is appended alphabetically.
TOP_ORDER = []

# Folder slug -> label shown in the catalog. Unmapped slugs fall back to
# title case with hyphens turned into spaces.
FOLDER_LABELS = {
    "academico": "Acadêmico",
    "analise": "Análise",
    "anonimizacao": "Anonimização",
    "apoio": "Apoio",
    "conferencia": "Conferência",
    "critica-literaria": "Crítica Literária",
    "culinaria": "Culinária",
    "escrita": "Escrita",
    "fichamento": "Fichamento",
    "forum": "Fórum",
    "geral": "Geral",
    "humanizar": "Humanizar",
    "imagem": "Imagem",
    "juridico": "Jurídico",
    "orientacao": "Orientação",
    "pesquisa": "Pesquisa",
    "redacao": "Redação",
    "resumo": "Resumo",
    "revisao": "Revisão",
    "seguranca": "Segurança",
}

FONT_NAME = "Calibri"
COLOR_HEADER_BG = "1F4E79"
COLOR_HEADER_FG = "FFFFFF"
COLOR_ALT_ROW = "D6E4F0"
COLOR_TITLE = "1F4E79"
COLOR_WARN = "9C2A2A"

EM_DASH = chr(8212)
BULLET = chr(8226)
TRIANGLE = chr(9656)


# ---------------------------------------------------------------- scanning

def is_prompt_file(filename):
    """True for YAML prompt files, skipping backups and hidden files."""
    lowered = filename.lower()
    if lowered.startswith("."):
        return False
    if ".bak" in lowered:
        return False
    return lowered.endswith(VALID_EXTENSIONS)


def unquote(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
        return value[1:-1].strip()
    return value


def parse_header(path):
    """Reads `name` and `description` from a prompt file, without PyYAML.

    Stops at the `prompt:` block. Handles plain scalars, quoted scalars and
    folded/literal blocks spread over several indented lines.
    """
    data = {"name": "", "description": ""}
    pending_key = None
    buffer = []
    with io.open(path, encoding="utf-8", errors="replace") as handle:
        for raw_line in handle:
            line = raw_line.rstrip("\n").rstrip("\r")
            if line.startswith("prompt:"):
                break
            is_top_level = bool(line) and line[0] not in (" ", "\t", "#", "-")
            if is_top_level and ":" in line:
                if pending_key:
                    data[pending_key] = " ".join(buffer).strip()
                    pending_key, buffer = None, []
                key, _, value = line.partition(":")
                key = key.strip()
                if key in data:
                    value = value.strip()
                    if value in ("", "|", ">", "|-", ">-", "|+", ">+"):
                        pending_key = key
                    else:
                        data[key] = unquote(value)
            elif pending_key and (raw_line.startswith(" ") or raw_line.startswith("\t")):
                buffer.append(line.strip())
    if pending_key:
        data[pending_key] = " ".join(buffer).strip()
    return data


def folder_label(slug):
    return FOLDER_LABELS.get(slug, slug.replace("-", " ").replace("_", " ").title())


def category_title(parts):
    """['juridico', 'revisao'] -> 'Jurídico / Revisão'; [] -> 'Raiz'."""
    if not parts:
        return ROOT_LABEL
    if len(parts) == 1:
        return folder_label(parts[0]) + " / " + ROOT_LABEL
    return " / ".join(folder_label(part) for part in parts)


def sort_key(parts):
    """Top folders in TOP_ORDER first; 'Raiz' rows last inside each branch."""
    if not parts:
        return (len(TOP_ORDER) + 1, "")
    top = parts[0]
    rank = TOP_ORDER.index(top) if top in TOP_ORDER else len(TOP_ORDER)
    tail = "/".join(parts[1:])
    return (rank, top if top in TOP_ORDER else top.lower(), "" if tail else "zzz", tail.lower())


def scan_prompts(prompts_dir):
    """Returns (categories, warnings).

    categories: list of {"title", "parts", "prompts": [(name, description)]}
    warnings: maintenance notes (missing fields, repeated names).
    """
    buckets = {}
    warnings = []
    seen_names = {}

    for dirpath, dirnames, filenames in os.walk(prompts_dir):
        dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))
        relative = os.path.relpath(dirpath, prompts_dir)
        parts = [] if relative == "." else relative.split(os.sep)
        for filename in sorted(filenames):
            if not is_prompt_file(filename):
                continue
            full_path = os.path.join(dirpath, filename)
            short_path = os.path.relpath(full_path, prompts_dir)
            header = parse_header(full_path)
            name = header["name"] or os.path.splitext(filename)[0]
            description = header["description"]
            if not header["name"]:
                warnings.append("sem campo 'name': " + short_path)
            if not description:
                description = EM_DASH
                warnings.append("sem campo 'description': " + short_path)
            key = tuple(parts)
            buckets.setdefault(key, []).append((name, description))
            seen_names.setdefault(name.lower(), []).append(short_path)

    for name_key, paths in sorted(seen_names.items()):
        if len(paths) > 1:
            warnings.append("nome repetido em " + str(len(paths)) + " arquivos: " + ", ".join(paths))

    categories = []
    for key in sorted(buckets, key=sort_key):
        prompts = sorted(buckets[key], key=lambda item: item[0].lower())
        categories.append({"title": category_title(list(key)), "parts": list(key), "prompts": prompts})
    return categories, warnings


# ---------------------------------------------------------------- rendering

def set_cell_shading(cell, color_hex):
    shading = cell._element.get_or_add_tcPr()
    shd = shading.makeelement(qn("w:shd"), {qn("w:val"): "clear", qn("w:color"): "auto", qn("w:fill"): color_hex})
    shading.append(shd)


def set_run_font(run, size=11, bold=False, color=None, name=FONT_NAME):
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = rPr.makeelement(qn("w:rFonts"), {})
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), name)
    rFonts.set(qn("w:hAnsi"), name)
    rFonts.set(qn("w:cs"), name)


def add_styled_paragraph(doc, text, size=11, bold=False, color=None,
                         alignment=WD_ALIGN_PARAGRAPH.LEFT, space_after=Pt(6)):
    paragraph = doc.add_paragraph()
    paragraph.alignment = alignment
    paragraph.paragraph_format.space_after = space_after
    run = paragraph.add_run(text)
    set_run_font(run, size=size, bold=bold, color=color)
    return paragraph


def add_horizontal_rule(doc):
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.space_after = Pt(12)
    pPr = paragraph._element.get_or_add_pPr()
    borders = pPr.makeelement(qn("w:pBdr"), {})
    bottom = borders.makeelement(qn("w:bottom"), {
        qn("w:val"): "single", qn("w:sz"): "6", qn("w:space"): "1", qn("w:color"): COLOR_TITLE})
    borders.append(bottom)
    pPr.append(borders)


def add_table_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else tbl.makeelement(qn("w:tblPr"), {})
    borders = tblPr.makeelement(qn("w:tblBorders"), {})
    for edge in ["top", "left", "bottom", "right", "insideH", "insideV"]:
        element = borders.makeelement(qn("w:" + edge), {
            qn("w:val"): "single", qn("w:sz"): "4", qn("w:space"): "0", qn("w:color"): "AAAAAA"})
        borders.append(element)
    tblPr.append(borders)


def plural(count):
    return "s" if count != 1 else ""


def build_catalog(prompts_dir, output_path):
    categories, warnings = scan_prompts(prompts_dir)
    total = sum(len(cat["prompts"]) for cat in categories)

    doc = Document()
    for section in doc.sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.0)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.0)

    add_styled_paragraph(doc, "Catálogo de Prompts " + EM_DASH + " Prompt Library", size=22, bold=True,
                         color=COLOR_TITLE, alignment=WD_ALIGN_PARAGRAPH.CENTER, space_after=Pt(4))
    subtitle = "%d prompts %s %d categorias %s Atualizado em %s" % (
        total, BULLET, len(categories), BULLET, date.today().strftime("%d/%m/%Y"))
    add_styled_paragraph(doc, subtitle, size=11, color="666666",
                         alignment=WD_ALIGN_PARAGRAPH.CENTER, space_after=Pt(18))
    add_horizontal_rule(doc)

    add_styled_paragraph(doc, "Índice de Categorias", size=14, bold=True,
                         color=COLOR_TITLE, space_after=Pt(8))
    for cat in categories:
        count = len(cat["prompts"])
        paragraph = doc.add_paragraph()
        paragraph.paragraph_format.space_after = Pt(2)
        paragraph.paragraph_format.left_indent = Cm(0.5)
        run = paragraph.add_run("%s  %s  (%d prompt%s)" % (TRIANGLE, cat["title"], count, plural(count)))
        set_run_font(run, size=10.5, color="333333")
    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    for cat in categories:
        count = len(cat["prompts"])
        add_styled_paragraph(doc, "%s  (%d prompt%s)" % (cat["title"], count, plural(count)),
                             size=14, bold=True, color=COLOR_TITLE, space_after=Pt(6))
        table = doc.add_table(rows=1, cols=3)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = True
        for row in table.rows:
            row.cells[0].width = Cm(1.2)
            row.cells[1].width = Cm(5.5)
            row.cells[2].width = Cm(10.3)
        header_cells = table.rows[0].cells
        for index, heading in enumerate(["#", "Nome", "Descrição"]):
            set_cell_shading(header_cells[index], COLOR_HEADER_BG)
            paragraph = header_cells[index].paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if index == 0 else WD_ALIGN_PARAGRAPH.LEFT
            run = paragraph.add_run(heading)
            set_run_font(run, size=10, bold=True, color=COLOR_HEADER_FG)
        for index, (name, description) in enumerate(cat["prompts"], start=1):
            cells = table.add_row().cells
            if index % 2 == 0:
                for cell in cells:
                    set_cell_shading(cell, COLOR_ALT_ROW)
            number_paragraph = cells[0].paragraphs[0]
            number_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            set_run_font(number_paragraph.add_run(str(index)), size=10, color="333333")
            set_run_font(cells[1].paragraphs[0].add_run(name), size=10, bold=True, color="1A1A1A")
            set_run_font(cells[2].paragraphs[0].add_run(description), size=10, color="444444")
        add_table_borders(table)
        doc.add_paragraph().paragraph_format.space_after = Pt(14)

    if warnings:
        add_styled_paragraph(doc, "Pendências detectadas na varredura", size=14, bold=True,
                             color=COLOR_WARN, space_after=Pt(6))
        for note in warnings:
            paragraph = doc.add_paragraph()
            paragraph.paragraph_format.space_after = Pt(2)
            paragraph.paragraph_format.left_indent = Cm(0.5)
            set_run_font(paragraph.add_run(BULLET + "  " + note), size=10, color=COLOR_WARN)
        doc.add_paragraph().paragraph_format.space_after = Pt(14)

    add_styled_paragraph(doc, "Total: %d prompts catalogados." % total, size=10, color="888888",
                         alignment=WD_ALIGN_PARAGRAPH.CENTER, space_after=Pt(2))
    add_styled_paragraph(doc, "Gerado automaticamente por gerar_catalogo.py a partir da pasta prompts/",
                         size=9, color="AAAAAA", alignment=WD_ALIGN_PARAGRAPH.CENTER, space_after=Pt(0))

    doc.save(output_path)
    return categories, warnings, total


if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    prompts_path = os.path.join(script_dir, PROMPTS_DIRNAME)
    output = os.path.join(script_dir, "catalogo-prompts.docx")
    if not os.path.isdir(prompts_path):
        raise SystemExit("Pasta nao encontrada: " + prompts_path)
    cats, notes, count = build_catalog(prompts_path, output)
    print("Catalogo salvo em:", output)
    print("Total de prompts:", count)
    print("Total de categorias:", len(cats))
    if notes:
        print("Pendencias (" + str(len(notes)) + "):")
        for item in notes:
            print("  -", item)
