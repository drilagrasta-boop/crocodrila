# Prompt Library (crocodrila prompta)

Biblioteca pessoal de prompts: paleta em AutoHotkey v2 (Windows) que busca arquivos YAML em `prompts/` e cola o prompt escolhido no aplicativo ativo. Visão geral em `README.md`; instalação em `LEIA-ME-PRIMEIRO.md`.

## Idioma

- Respostas e documentação: português do Brasil.
- Código: inglês nos nomes do AutoHotkey; os scripts Python seguem o português que já usam.

## Onde ficam as coisas

- `prompts/<area>/<tarefa>/<nome>.yaml` — um prompt por arquivo. Nomes de pasta e de arquivo em minúsculas, sem acento, com hífen (`resumo-capitulo.yaml`). A área e a tarefa exibidas vêm das pastas.
- `lib/*.ahk` — o motor. Só mexa se o pedido for sobre o comportamento da paleta.
- `padroes/bloco-comum.txt` e `padroes/alvos.txt` — bloco de texto repetido em vários prompts.

## Formato obrigatório de um prompt

O `lib/YamlParser.ahk` é um parser simplificado, não um YAML completo. Respeite exatamente:

```yaml
name: Nome exibido na paleta
description: Uma linha
tags: [tag1, tag2]
variables:
  - name: nome_variavel
    label: Rótulo do campo
    placeholder: "dica"
    default: "valor inicial"
prompt: |
  Texto com 2 espaços de recuo em todas as linhas.
  Variáveis entram como {nome_variavel}.
```

- `name` e `prompt` são obrigatórios; `description`, `tags` e `variables` são opcionais.
- `tags` em lista inline `[a, b]`.
- `prompt` sempre como bloco literal `|`, com 2 espaços de recuo. O bloco termina na primeira linha sem recuo; por convenção, `prompt:` é a última chave do arquivo.
- Toda `{variavel}` usada no texto deve estar declarada em `variables`, com o mesmo `name`.
- Arquivo em UTF-8.

## Bloco comum

Não edite à mão o trecho entre `=== BLOCO COMUM` e `=== FIM DO BLOCO COMUM ===` dentro de um prompt: edite `padroes/bloco-comum.txt` e rode `python sincronizar_padrao.py`. Para incluir um prompt novo, acrescente o caminho dele em `padroes/alvos.txt`.

## Verificação

- Depois de criar ou editar prompts: `python sincronizar_padrao.py --verificar` (se houver alvos) e `pytest`.
- Na paleta, `Ctrl+Shift+F5` recarrega os prompts.
- Para apagar prompts ou pastas, confirme comigo antes.
