#Requires AutoHotkey v2.0
#Include "..\lib\YamlParser.ahk"

result := YamlParser.ParseFile(A_ScriptDir "\sample.yaml")

errors := ""

if result["name"] != "Analise de Documento"
    errors .= "FAIL: name = '" result["name"] "', expected 'Analise de Documento'`n"

if result["description"] != "Analisa um documento com foco especifico"
    errors .= "FAIL: description mismatch`n"

if Type(result["tags"]) != "Array" || result["tags"].Length != 3
    errors .= "FAIL: tags should be Array with 3 items`n"
else if result["tags"][1] != "analise"
    errors .= "FAIL: tags[1] = '" result["tags"][1] "', expected 'analise'`n"

if Type(result["variables"]) != "Array" || result["variables"].Length != 2
    errors .= "FAIL: variables should be Array with 2 items`n"
else {
    v1 := result["variables"][1]
    if v1["name"] != "tipo_documento"
        errors .= "FAIL: variables[1].name = '" v1["name"] "', expected 'tipo_documento'`n"
    if v1["placeholder"] != "ex: contrato, peticao"
        errors .= "FAIL: variables[1].placeholder mismatch`n"

    v2 := result["variables"][2]
    if !v2.Has("default") || v2["default"] != "pontos criticos"
        errors .= "FAIL: variables[2].default should be 'pontos criticos'`n"
}

if !InStr(result["prompt"], "{tipo_documento}")
    errors .= "FAIL: prompt should contain {tipo_documento}`n"
if !InStr(result["prompt"], "{foco}")
    errors .= "FAIL: prompt should contain {foco}`n"

if errors = ""
    MsgBox "ALL TESTS PASSED!", "YAML Parser Tests"
else
    MsgBox errors, "YAML Parser Tests - FAILURES"

ExitApp
