# -*- coding: utf-8 -*-
"""Testes do sincronizar_padrao.py (bloco comum nos prompts)."""

import re
import sys
from pathlib import Path

import pytest
import yaml

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

import gerar_catalogo  # noqa: E402
import sincronizar_padrao as sp  # noqa: E402

FONTE = "=== BLOCO COMUM (versão 28/09/2026) ===\nRegra um.\n\nRegra dois.\n=== FIM DO BLOCO COMUM ==="

PROMPT = (
    "name: Teste\n"
    "description: Um prompt\n"
    "tags: [a, b]\n"
    "prompt: |\n"
    "  Linha do prompt.\n"
    "\n"
    "  Outra linha.\n"
)


def bloco_ahk(conteudo):
    """Reproduz YamlParser._ParseBlock da paleta para a chave prompt."""
    linhas = conteudo.replace("\r\n", "\n").split("\n")
    i = next(n for n, l in enumerate(linhas) if re.match(r"^prompt\s*:\s*\|\s*$", l)) + 1
    saida = []
    while i < len(linhas):
        linha = linhas[i]
        if linha.strip() != "" and not re.match(r"^\s", linha):
            break
        saida.append(re.sub(r"^  ", "", linha))
        i += 1
    return "\n".join(saida).rstrip("\n\r ")


def test_insere_bloco_ao_fim_do_prompt():
    novo = sp.aplicar_bloco(PROMPT, FONTE)
    texto = bloco_ahk(novo)
    assert texto.startswith("Linha do prompt.")
    assert texto.endswith(FONTE)
    assert "Outra linha.\n\n=== BLOCO COMUM" in texto


def test_toda_linha_nao_vazia_do_bloco_tem_recuo():
    novo = sp.aplicar_bloco(PROMPT, FONTE)
    depois = novo.split("prompt: |\n", 1)[1]
    for linha in depois.splitlines():
        assert linha == "" or linha.startswith("  "), repr(linha)


def test_idempotente():
    uma = sp.aplicar_bloco(PROMPT, FONTE)
    assert sp.aplicar_bloco(uma, FONTE) == uma


def test_substitui_versao_anterior_sem_duplicar():
    antiga = FONTE.replace("28/09/2026", "01/01/2026").replace("Regra um.", "Regra velha.")
    com_antiga = sp.aplicar_bloco(PROMPT, antiga)
    nova = sp.aplicar_bloco(com_antiga, FONTE)
    assert "Regra velha." not in nova
    assert nova.count("=== BLOCO COMUM") == 1
    assert nova == sp.aplicar_bloco(PROMPT, FONTE)


def test_preserva_chave_depois_do_prompt():
    conteudo = PROMPT + "variables:\n  - name: x\n    label: X\n"
    novo = sp.aplicar_bloco(conteudo, FONTE)
    dados = yaml.safe_load(novo)
    assert dados["variables"] == [{"name": "x", "label": "X"}]
    assert dados["prompt"].rstrip("\n").endswith("=== FIM DO BLOCO COMUM ===")


def test_preserva_crlf():
    crlf = PROMPT.replace("\n", "\r\n")
    novo = sp.aplicar_bloco(crlf, FONTE)
    assert "\r\n" in novo
    assert re.search(r"(?<!\r)\n", novo) is None


def test_inicio_sem_fim_gera_erro():
    quebrado = PROMPT + "\n  === BLOCO COMUM (versão x) ===\n  resto\n"
    with pytest.raises(ValueError, match="FIM"):
        sp.aplicar_bloco(quebrado, FONTE)


def test_sem_chave_prompt_gera_erro():
    with pytest.raises(ValueError, match="prompt"):
        sp.aplicar_bloco("name: x\ndescription: y\n", FONTE)


def _raiz_falsa(tmp_path, alvos_conteudo):
    (tmp_path / "padroes").mkdir()
    (tmp_path / "padroes" / "bloco-comum.txt").write_text(FONTE + "\n", encoding="utf-8")
    (tmp_path / "padroes" / "alvos.txt").write_text(alvos_conteudo, encoding="utf-8")
    return tmp_path


def test_main_verificar_e_sincronizar(tmp_path):
    raiz = _raiz_falsa(tmp_path, "# comentario\na.yaml\n")
    (raiz / "a.yaml").write_text(PROMPT, encoding="utf-8")
    assert sp.main(["--verificar"], raiz=raiz) == 1
    assert (raiz / "a.yaml").read_text(encoding="utf-8") == PROMPT
    assert sp.main([], raiz=raiz) == 0
    assert sp.main(["--verificar"], raiz=raiz) == 0


def test_main_alvo_inexistente_nao_grava_nada(tmp_path):
    raiz = _raiz_falsa(tmp_path, "a.yaml\nnao-existe.yaml\n")
    (raiz / "a.yaml").write_text(PROMPT, encoding="utf-8")
    assert sp.main([], raiz=raiz) == 2
    assert (raiz / "a.yaml").read_text(encoding="utf-8") == PROMPT


def test_alvos_reais_sincronizados_e_legiveis():
    """Os alvos reais de padroes/alvos.txt contem o bloco atual."""
    alvos = sp.carregar_alvos(RAIZ)
    assert alvos
    fonte = sp.carregar_fonte(RAIZ)
    for alvo in alvos:
        conteudo = alvo.read_bytes().decode("utf-8")
        assert sp.aplicar_bloco(conteudo, fonte) == conteudo, alvo.name
        assert fonte.strip() in bloco_ahk(conteudo), alvo.name
        dados = yaml.safe_load(conteudo)
        assert dados["name"] and dados["prompt"], alvo.name
        cabecalho = gerar_catalogo.parse_header(str(alvo))
        assert cabecalho["name"] == dados["name"], alvo.name


def test_erro_indica_o_alvo_e_nao_grava_os_anteriores(tmp_path, capsys):
    raiz = _raiz_falsa(tmp_path, "a.yaml\nb.yaml\n")
    (raiz / "a.yaml").write_text(PROMPT, encoding="utf-8")
    (raiz / "b.yaml").write_text("name: b\nprompt: >\n  texto\n", encoding="utf-8")
    assert sp.main([], raiz=raiz) == 2
    assert "b.yaml" in capsys.readouterr().err
    assert (raiz / "a.yaml").read_text(encoding="utf-8") == PROMPT


def test_linhas_fora_do_bloco_mantem_o_proprio_final():
    misto = PROMPT.replace("name: Teste\n", "name: Teste\r\n", 1)
    novo = sp.aplicar_bloco(misto, FONTE)
    assert novo.startswith("name: Teste\r\ndescription: Um prompt\n")
    assert novo.count("\r\n") == 1


def test_bloco_colado_duas_vezes_vira_um_so():
    uma = sp.aplicar_bloco(PROMPT, FONTE)
    marcado = "\n".join("  " + l if l else "" for l in FONTE.split("\n"))
    duas = uma + "\n" + marcado + "\n"
    nova = sp.aplicar_bloco(duas, FONTE)
    assert nova.count("=== BLOCO COMUM") == 1
    assert nova == uma


def test_prompt_com_recuo_de_quatro_espacos_continua_yaml_valido():
    quatro = PROMPT.replace("\n  ", "\n    ")
    novo = sp.aplicar_bloco(quatro, FONTE)
    dados = yaml.safe_load(novo)
    assert dados["prompt"].rstrip("\n").endswith("=== FIM DO BLOCO COMUM ===")
