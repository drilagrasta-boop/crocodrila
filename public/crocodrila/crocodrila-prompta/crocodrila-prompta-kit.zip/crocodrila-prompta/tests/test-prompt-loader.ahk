#Requires AutoHotkey v2.0
#Include "..\lib\YamlParser.ahk"
#Include "..\lib\PromptLoader.ahk"

baseDir := A_ScriptDir "\..\prompts"
errors := ""

prompts := PromptLoader.LoadAll(baseDir)
if prompts.Length < 1
    errors .= "FAIL: LoadAll should find at least 1 prompt, found " prompts.Length "`n"

found := false
for p in prompts {
    if p["name"] = "Exemplo - prompt simples" {
        found := true
        if p["area"] != "exemplos"
            errors .= "FAIL: area should be 'exemplos', got '" p["area"] "'`n"
    }
}
if !found
    errors .= "FAIL: 'Exemplo - prompt simples' not found in loaded prompts`n"

results := PromptLoader.Search(prompts, "exemplo")
if results.Length < 1
    errors .= "FAIL: Search for 'exemplo' should return at least 1 result`n"

results2 := PromptLoader.Search(prompts, "xyznonexistent")
if results2.Length != 0
    errors .= "FAIL: Search for 'xyznonexistent' should return 0 results`n"

filled := PromptLoader.FillVariables("Analise {tipo} com foco em {foco}", Map("tipo", "contrato", "foco", "riscos"))
if filled != "Analise contrato com foco em riscos"
    errors .= "FAIL: FillVariables result: '" filled "'`n"

if errors = ""
    MsgBox "ALL TESTS PASSED!", "Prompt Loader Tests"
else
    MsgBox errors, "Prompt Loader Tests - FAILURES"

ExitApp
