# Instalador da Crocodrila prompta.
# Uso normal: dois cliques em INSTALAR.cmd.
# -Destino <pasta> instala em outro lugar; -Teste copia e confere, sem atalho, sem abrir a paleta e sem instalar programas.
param(
    [string]$Destino = (Join-Path $env:USERPROFILE "crocodrila-prompta"),
    [switch]$Teste
)

$ErrorActionPreference = "Stop"
$origem = $PSScriptRoot

function Passo($texto) { Write-Host ""; Write-Host "==> $texto" -ForegroundColor Cyan }
function Ok($texto)    { Write-Host "    $texto" -ForegroundColor Green }
function Aviso($texto) { Write-Host "    $texto" -ForegroundColor Yellow }

function Find-AutoHotkey {
    $candidatos = @(
        (Join-Path $env:LOCALAPPDATA "Programs\AutoHotkey\v2\AutoHotkey64.exe"),
        (Join-Path $env:ProgramFiles "AutoHotkey\v2\AutoHotkey64.exe")
    )
    if (${env:ProgramFiles(x86)}) { $candidatos += (Join-Path ${env:ProgramFiles(x86)} "AutoHotkey\v2\AutoHotkey64.exe") }
    foreach ($c in $candidatos) { if (Test-Path $c) { return $c } }
    return $null
}

Write-Host "Crocodrila prompta - instalador" -ForegroundColor Magenta
Write-Host "Pasta de destino: $Destino"

# 1. AutoHotkey v2
Passo "Verificando o AutoHotkey v2"
$ahk = Find-AutoHotkey
if ($ahk) {
    Ok "Encontrado: $ahk"
} elseif ($Teste) {
    Aviso "Nao encontrado (modo teste: nada sera instalado)."
} else {
    Aviso "Nao encontrado. Tentando instalar pelo winget..."
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        & winget install --id AutoHotkey.AutoHotkey -e --scope user --accept-package-agreements --accept-source-agreements
        $ahk = Find-AutoHotkey
    }
    if (-not $ahk) {
        Aviso "Nao consegui instalar automaticamente."
        Aviso "Vou abrir o site do AutoHotkey. Baixe e instale a versao 2 e depois rode o INSTALAR.cmd de novo."
        Start-Process "https://www.autohotkey.com"
        exit 1
    }
    Ok "Instalado: $ahk"
}

# 2. Copia dos arquivos (nunca sobrescreve uma instalacao existente)
Passo "Copiando os arquivos"
if ((Resolve-Path $origem).Path.TrimEnd('\') -ieq $Destino.TrimEnd('\')) {
    Ok "O kit ja esta na pasta de destino; nada a copiar."
} elseif (Test-Path $Destino) {
    Aviso "A pasta $Destino ja existe. Para nao apagar seus prompts, nada foi copiado."
    Aviso "Se quiser reinstalar, renomeie ou mova essa pasta e rode o instalador de novo."
    exit 1
} else {
    New-Item -ItemType Directory -Path $Destino | Out-Null
    $ignorar = @("INSTALAR.cmd", "instalar.ps1")
    Get-ChildItem -LiteralPath $origem -Force | Where-Object { $ignorar -notcontains $_.Name } |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $Destino -Recurse }
    Get-ChildItem -LiteralPath $Destino -Recurse -File | Unblock-File
    Ok "Arquivos copiados para $Destino"
}

$watchdog = Join-Path $Destino "watchdog.ahk"
if (-not (Test-Path (Join-Path $Destino "prompt-library.ahk"))) {
    Aviso "prompt-library.ahk nao encontrado em $Destino. A copia falhou."
    exit 1
}

if ($Teste) {
    Passo "Modo teste: sem atalho de inicializacao, sem abrir a paleta, sem Python."
    exit 0
}

# 3. Iniciar com o Windows
Passo "Criando o atalho para iniciar junto com o Windows"
$startup = [Environment]::GetFolderPath("Startup")
$lnk = Join-Path $startup "Crocodrila prompta (vigia).lnk"
$shell = New-Object -ComObject WScript.Shell
$atalho = $shell.CreateShortcut($lnk)
$atalho.TargetPath = $ahk
$atalho.Arguments = '"' + $watchdog + '"'
$atalho.WorkingDirectory = $Destino
$atalho.Save()
Ok "Atalho criado em $startup"

# 4. Python (opcional)
Passo "Python (opcional: catalogo em Word, bloco comum e testes)"
if (Get-Command python -ErrorAction SilentlyContinue | Where-Object { $_.Source -notlike "*WindowsApps*" }) {
    Ok "Python ja instalado."
} else {
    $resp = Read-Host "    Instalar o Python agora? (s/N)"
    if ($resp -match '^[sS]') {
        if (Get-Command winget -ErrorAction SilentlyContinue) {
            & winget install --id Python.Python.3.13 -e --scope user --accept-package-agreements --accept-source-agreements
            Aviso "Feche e abra o terminal e rode: pip install python-docx pyyaml pytest"
        } else {
            Aviso "winget indisponivel. Baixe em https://www.python.org e marque 'Add Python to PATH'."
            Start-Process "https://www.python.org/downloads/"
        }
    } else {
        Ok "Pulado. Da para instalar depois; o guia explica como."
    }
}

# 5. Abrir
Passo "Abrindo a paleta"
Start-Process -FilePath $ahk -ArgumentList ('"' + $watchdog + '"') -WorkingDirectory $Destino
Ok "Pronto! Procure a crocodila na bandeja, perto do relogio."
Ok "Aperte Ctrl+Shift+Espaco e digite: exemplo"
Start-Process explorer.exe $Destino
