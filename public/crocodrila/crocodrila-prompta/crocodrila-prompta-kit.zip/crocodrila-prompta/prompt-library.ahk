#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent

; Load modules
#Include "lib\YamlParser.ahk"
#Include "lib\ConfigLoader.ahk"
#Include "lib\PromptLoader.ahk"
#Include "lib\ClipboardPaster.ahk"
#Include "lib\SearchGui.ahk"
#Include "lib\VariableGui.ahk"
#Include "lib\TrayMenu.ahk"

; Paths
global BASE_DIR := A_ScriptDir
global PROMPTS_DIR := BASE_DIR "\prompts"
global CONFIG_PATH := BASE_DIR "\config.yaml"

; Load config and prompts
global config := ConfigLoader.Load(CONFIG_PATH)
global prompts := PromptLoader.LoadAll(PROMPTS_DIR)

; Setup tray
TrayMenu.Setup(PROMPTS_DIR, ReloadPrompts)

; Store class references before they get shadowed
global SearchGuiClass := SearchGui
global VariableGuiClass := VariableGui

; Create GUI instances
global gSearchGui := SearchGuiClass(config, prompts, OnPromptSelected)
global gVariableGui := VariableGuiClass(OnVariablesFilled, OnVariablesCancelled)
global pendingPrompt := ""

; Register global hotkeys
Hotkey config["hotkey"], (*) => ShowPalette()
Hotkey config["reload_hotkey"], (*) => ReloadPrompts()

; --- Functions ---

ShowPalette() {
    global gSearchGui, prompts, config, SearchGuiClass
    gSearchGui := SearchGuiClass(config, prompts, OnPromptSelected)
    gSearchGui.Show()
}

OnPromptSelected(promptData) {
    global pendingPrompt, gVariableGui
    if promptData["variables"].Length > 0 {
        pendingPrompt := promptData
        gVariableGui.Show(promptData)
    } else {
        ClipboardPaster.Paste(promptData["prompt"])
    }
}

OnVariablesFilled(values) {
    global pendingPrompt
    if pendingPrompt != "" {
        finalText := PromptLoader.FillVariables(pendingPrompt["prompt"], values)
        pendingPrompt := ""
        ClipboardPaster.Paste(finalText)
    }
}

OnVariablesCancelled() {
    global pendingPrompt
    pendingPrompt := ""
}

ReloadPrompts() {
    global prompts, config
    config := ConfigLoader.Load(CONFIG_PATH)
    prompts := PromptLoader.LoadAll(PROMPTS_DIR)
    ToolTip "Prompts recarregados: " prompts.Length " encontrados"
    SetTimer () => ToolTip(), -2000
}
