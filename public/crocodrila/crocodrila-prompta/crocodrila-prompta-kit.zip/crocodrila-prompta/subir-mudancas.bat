@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ================================================
echo   Subir mudancas - prompt-library
echo ================================================
echo.

git add -A

echo Arquivos alterados:
git status --short
echo.

git diff --cached --quiet
if not errorlevel 1 (
  echo Nada mudou desde o ultimo envio. Nada a fazer.
  echo.
  pause
  exit /b
)

set "msg="
set /p "msg=Mensagem do commit (Enter = data e hora): "
if "%msg%"=="" set "msg=Atualizacao %date% %time%"

git commit -m "%msg%"
if errorlevel 1 (
  echo.
  echo Erro no commit. Nada foi enviado.
  echo.
  pause
  exit /b
)

git push
if errorlevel 1 (
  echo.
  echo ERRO no push. Verifique a conexao ou a autenticacao do GitHub.
) else (
  echo.
  echo Pronto! Mudancas enviadas ao GitHub.
)

echo.
pause
