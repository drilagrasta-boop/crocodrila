# Crocodrila prompta — kit da estrutura

Este pacote traz o **motor** da biblioteca de prompts da sua mãe, sem os prompts dela. Você recebe a paleta de busca, o formulário de variáveis, o vigia, o catálogo em Word e o sincronizador de bloco comum, e preenche a pasta `prompts/` com os seus.

**Comece pelo `GUIA-CROCODRILA-PROMPTA.pdf`**, que explica tudo com calma. Este arquivo é o resumo técnico.

## O que é

Um "Spotlight de prompts" para Windows, feito em AutoHotkey v2. Você aperta um atalho, digita uma ou duas palavras, escolhe o prompt e ele é colado no aplicativo que estiver em foco (Claude, ChatGPT, Word, navegador, qualquer um). Se o prompt tiver variáveis, uma janelinha pergunta os valores antes de colar.

Cada prompt é um arquivo `.yaml` separado. A pasta onde ele está define a área e a tarefa.

## Instalação rápida (recomendada)

1. Clique com o botão direito no ZIP e escolha "Extrair tudo".
2. Na pasta extraída, dê dois cliques em `INSTALAR.cmd`. Se o Windows avisar, clique em "Mais informações" e "Executar assim mesmo".

O instalador instala o AutoHotkey v2 pelo `winget` (se faltar), copia tudo para `C:\Users\SeuUsuario\crocodrila-prompta`, cria o atalho de inicialização, oferece instalar o Python e abre a paleta. Se a pasta de destino já existir, ele para sem copiar nada.

## Instalação manual (uns 10 minutos)

### 1. Instale o AutoHotkey **v2**

Baixe em https://www.autohotkey.com e escolha a versão 2 (não a 1.1). Na instalação, deixe marcada a associação de arquivos `.ahk`.

### 2. Descompacte a pasta

Coloque a pasta `crocodrila-prompta` onde preferir, por exemplo:

```
C:\Users\SeuUsuario\.prompt-library\
```

Nenhum caminho está fixo no código: tudo é relativo à própria pasta.

### 3. Rode

Dê dois cliques em `prompt-library.ahk`. A crocodila aparece na bandeja (perto do relógio).

- `Ctrl+Shift+Espaço` abre a paleta.
- Digite `exemplo` e você verá os três prompts de demonstração.
- `Ctrl+Shift+F5` recarrega os prompts depois de criar ou editar algum.

### 4. Inicie junto com o Windows (opcional)

`Win+R`, digite `shell:startup`, Enter. Na pasta que abrir, crie um **atalho** para `watchdog.ahk`. O vigia abre a paleta no login e a reabre se ela fechar por algum motivo (verifica a cada 60 segundos).

### 5. Python (opcional)

Baixe em https://www.python.org/downloads/ e marque "Add Python to PATH" na instalação. Só é necessário para os utilitários:

```
pip install python-docx pyyaml pytest
python gerar_catalogo.py          # gera catalogo-prompts.docx com todos os prompts
python sincronizar_padrao.py      # aplica o bloco comum (ver abaixo)
pytest                            # roda os testes dos scripts Python
```

## Primeiros passos com os seus prompts

1. Olhe os exemplos em `prompts/exemplos/`.
2. Crie suas próprias pastas: `prompts/<area>/<tarefa>/nome-do-prompt.yaml`. Por exemplo `prompts/faculdade/resumos/resumo-capitulo.yaml`.
3. Quando não precisar mais dos exemplos, apague `prompts/exemplos/` e retire a linha correspondente de `padroes/alvos.txt`. Os testes (`tests/`) usam esses exemplos; se você apagá-los, ajuste ou descarte os testes também.
4. Com o Claude Code aberto nesta pasta, você pode pedir "crie um prompt para X" — o `CLAUDE.md` já ensina a ele o formato.

## Formato de um prompt

```yaml
name: Nome que aparece na paleta
description: Uma linha sobre o que faz
tags: [tag1, tag2]
variables:
  - name: tema
    label: Tema
    placeholder: "ex: fotossintese"
    default: "valor inicial"       # opcional; o placeholder não aparece na janela, o default sim
prompt: |
  Texto do prompt, sempre com 2 espaços de recuo.
  Use {tema} onde a variável entra.
```

- Obrigatórios: `name` e `prompt`. O resto é opcional.
- O texto do `prompt: |` termina na primeira linha **sem recuo**. Linhas em branco no meio podem ficar.
- Salve em UTF-8.

## Bloco comum (opcional, mas útil)

Se você tem instruções que se repetem em vários prompts (tom, idioma, "não invente fontes"), escreva-as uma vez em `padroes/bloco-comum.txt` e liste os prompts que devem recebê-las em `padroes/alvos.txt`. Depois rode `python sincronizar_padrao.py`: o bloco é colado ou atualizado no fim de cada prompt listado, entre as marcas `=== BLOCO COMUM` e `=== FIM DO BLOCO COMUM ===`. `python sincronizar_padrao.py --verificar` só confere, sem gravar.

## Atalhos e aparência

Em `config.yaml`:

```yaml
hotkey: "^+Space"       # ^ = Ctrl, + = Shift, ! = Alt, # = Win
reload_hotkey: "^+F5"
window_width: 900
max_results: 20
```

Ícones em `assets/`. O nome "Crocodrila prompta" aparece na bandeja (`lib/TrayMenu.ahk`) e no título da paleta (`lib/SearchGui.ahk`); troque se quiser batizar a sua.

## Git e GitHub (opcional)

Se quiser versionar:

```
git init
git add -A
git commit -m "Primeira versao"
```

Crie um repositório **privado** no GitHub, conecte (`git remote add origin ...`, `git push -u origin main`) e, daí em diante, `subir-mudancas.bat` faz commit e push com dois cliques. O `.gitignore` já exclui catálogos gerados, backups e caches.

## Problemas comuns

| Sintoma | O que fazer |
|---|---|
| "requires AutoHotkey v2" | Instale a versão 2, não a 1.1 |
| Prompt não aparece | Confira `name:` e `prompt: |`, o recuo de 2 espaços e o UTF-8; recarregue com Ctrl+Shift+F5 |
| Acentos estranhos | Salve o arquivo em UTF-8 |
| Não colou | Alguns aplicativos bloqueiam o Ctrl+V simulado (a paleta devolve logo em seguida o que você tinha copiado antes); clique no campo de texto antes de abrir a paleta ou copie o texto direto do `.yaml` |
| Atalho não responde | Outro programa pode usar o mesmo atalho; mude em `config.yaml` |
