#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent

; Vigia da Biblioteca de Prompts (Crocodrila)
; Verifica a cada 2 minutos se o prompt-library.ahk esta rodando.
; Se nao estiver, reinicia. Roda em espaco de usuario (sem admin).

global AHK_EXE := A_AhkPath   ; o mesmo AutoHotkey que esta rodando o vigia
global TARGET  := A_ScriptDir "\prompt-library.ahk"

; Icone proprio do vigia (anel dourado)
ApplyIcon()
; No logon o TraySetIcon pode nao pegar (bandeja ainda instavel); reaplica apos 15s
SetTimer(ApplyIcon, -15000)
A_IconTip := "Vigia da Crocodrila"

CheckAndStart()                       ; checa imediatamente ao iniciar
SetTimer(CheckAndStart, 60000)        ; e depois a cada 60 segundos

ApplyIcon() {
    iconPath := A_ScriptDir "\assets\watchdog-tray.png"
    if FileExist(iconPath)
        try TraySetIcon(iconPath)
}

CheckAndStart() {
    if !IsPromptLibraryRunning() {
        if FileExist(AHK_EXE) && FileExist(TARGET)
            Run('"' AHK_EXE '" "' TARGET '"')
    }
}

IsPromptLibraryRunning() {
    query := "SELECT CommandLine FROM Win32_Process WHERE Name = 'AutoHotkey64.exe'"
    for proc in ComObjGet("winmgmts:\\.\root\cimv2").ExecQuery(query) {
        cl := proc.CommandLine
        if (cl != "" && InStr(cl, "prompt-library.ahk"))
            return true
    }
    return false
}
