# -*- coding: utf-8 -*-
"""Sincroniza o bloco comum nos prompts da biblioteca.

Fonte unica: padroes/bloco-comum.txt. Alvos: padroes/alvos.txt (um
caminho por linha, relativo a raiz; linhas vazias e iniciadas por # ignoradas).

O bloco fica ao fim da chave `prompt: |` de cada alvo, entre a linha que comeca
por MARCA_INICIO e a linha MARCA_FIM, com 2 espacos de recuo (exigencia do
YamlParser.ahk da paleta: o bloco termina na primeira linha sem recuo).

Uso:
    python sincronizar_padrao.py              grava e lista o que mudou
    python sincronizar_padrao.py --verificar  so confere (sai 1 se desatualizado)
"""

import re
import sys
from pathlib import Path

MARCA_INICIO = "=== BLOCO COMUM"
MARCA_FIM = "=== FIM DO BLOCO COMUM ==="
_CHAVE_PROMPT = re.compile(r"^prompt\s*:\s*\|\s*$")


def carregar_fonte(raiz: Path) -> str:
    return (raiz / "padroes" / "bloco-comum.txt").read_text(encoding="utf-8").strip("\n")


def carregar_alvos(raiz: Path) -> list:
    alvos = []
    for linha in (raiz / "padroes" / "alvos.txt").read_text(encoding="utf-8").splitlines():
        linha = linha.strip()
        if not linha or linha.startswith("#"):
            continue
        caminho = raiz / linha
        if not caminho.is_file():
            raise FileNotFoundError(f"alvo não encontrado: {linha}")
        alvos.append(caminho)
    return alvos


def aplicar_bloco(conteudo: str, fonte: str) -> str:
    """Devolve `conteudo` com o bloco `fonte` atualizado no fim do prompt.

    Linhas fora do bloco conservam o proprio final de linha; o bloco usa o
    final predominante do arquivo e o recuo do proprio prompt. Copias extras
    do bloco (coladas mais de uma vez) sao reduzidas a uma so.
    """
    crlf = conteudo.count("\r\n")
    quebra = "\r\n" if crlf > conteudo.count("\n") - crlf else "\n"
    linhas = re.findall(r"[^\n]*\n|[^\n]+$", conteudo)
    corpo = [l.rstrip("\r\n") for l in linhas]

    inicio_prompt = next((n for n, l in enumerate(corpo) if _CHAVE_PROMPT.match(l)), None)
    if inicio_prompt is None:
        raise ValueError("chave 'prompt: |' não encontrada")
    fim_prompt = len(corpo)
    for n in range(inicio_prompt + 1, len(corpo)):
        if corpo[n].strip() and not corpo[n][0].isspace():
            fim_prompt = n
            break

    recuo = next((re.match(r"\s*", corpo[n]).group() for n in range(inicio_prompt + 1, fim_prompt)
                  if corpo[n].strip()), "  ")
    bloco = [(recuo + l if l.strip() else "") + quebra
             for l in fonte.strip("\n").split("\n")]

    copias = []
    n = inicio_prompt + 1
    while n < fim_prompt:
        if corpo[n].strip().startswith(MARCA_INICIO):
            fim = next((k for k in range(n + 1, fim_prompt) if corpo[k].strip() == MARCA_FIM), None)
            if fim is None:
                raise ValueError(f"marcadora de início sem '{MARCA_FIM}'")
            copias.append((n, fim))
            n = fim + 1
        else:
            n += 1

    if copias:
        remover = set()
        for ini, fim in copias[1:]:
            remover.update(range(ini, fim + 1))
            if ini - 1 > copias[0][1] and not corpo[ini - 1].strip():
                remover.add(ini - 1)
        ini, fim = copias[0]
        novas = linhas[:ini] + bloco + [l for k, l in enumerate(linhas[fim + 1:], fim + 1)
                                        if k not in remover]
    else:
        ultimo = fim_prompt - 1
        while ultimo > inicio_prompt and not corpo[ultimo].strip():
            ultimo -= 1
        antes = linhas[:ultimo + 1]
        if not antes[-1].endswith("\n"):
            antes[-1] += quebra
        novas = antes + [quebra] + bloco + linhas[ultimo + 1:]

    return "".join(novas)


def main(argv=None, raiz=None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    raiz = Path(__file__).resolve().parent if raiz is None else Path(raiz)
    verificar = "--verificar" in argv
    try:
        fonte = carregar_fonte(raiz)
        alvos = carregar_alvos(raiz)
        pendentes = []
        for alvo in alvos:
            atual = alvo.read_bytes().decode("utf-8")
            try:
                novo = aplicar_bloco(atual, fonte)
            except ValueError as erro:
                raise ValueError(f"{alvo.relative_to(raiz)}: {erro}") from erro
            if novo != atual:
                pendentes.append((alvo, novo))
    except (OSError, ValueError) as erro:
        print(f"ERRO: {erro}", file=sys.stderr)
        return 2

    for alvo, novo in pendentes:
        print(("desatualizado: " if verificar else "atualizado: ") + str(alvo.relative_to(raiz)))
        if not verificar:
            alvo.write_bytes(novo.encode("utf-8"))
    if not pendentes:
        print("todos os alvos em dia")
    return 1 if (verificar and pendentes) else 0


if __name__ == "__main__":
    sys.exit(main())
