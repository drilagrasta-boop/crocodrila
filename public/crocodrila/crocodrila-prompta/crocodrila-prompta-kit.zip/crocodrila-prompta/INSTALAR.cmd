@echo off
rem Instalador da Crocodrila prompta: chama o instalar.ps1 que esta na mesma pasta.
cd /d "%~dp0"
if not exist "%~dp0instalar.ps1" (
  echo.
  echo  Descompacte o ZIP antes de instalar:
  echo  clique com o botao direito no ZIP, escolha "Extrair tudo" e
  echo  rode o INSTALAR.cmd de dentro da pasta extraida.
  echo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1" %*
echo.
pause
