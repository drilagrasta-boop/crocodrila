#Requires AutoHotkey v2.0

class YamlParser {

    static ParseFile(filePath) {
        if !FileExist(filePath)
            throw Error("File not found: " filePath)
        content := FileRead(filePath, "UTF-8")
        return YamlParser.Parse(content)
    }

    static Parse(content) {
        result := Map()
        lines := StrSplit(content, "`n", "`r")
        i := 1
        while i <= lines.Length {
            line := lines[i]

            if Trim(line) = "" || RegExMatch(Trim(line), "^#") {
                i++
                continue
            }

            if RegExMatch(line, "^(\w+)\s*:\s*(.*)", &match) {
                key := match[1]
                value := Trim(match[2])

                if value = "|" {
                    i++
                    result[key] := YamlParser._ParseBlock(&i, lines)
                } else if SubStr(value, 1, 1) = "[" {
                    result[key] := YamlParser._ParseInlineArray(value)
                    i++
                } else if value = "" {
                    i++
                    result[key] := YamlParser._ParseListOfObjects(&i, lines)
                } else {
                    result[key] := YamlParser._StripQuotes(value)
                    i++
                }
            } else {
                i++
            }
        }
        return result
    }

    static _ParseBlock(&i, lines) {
        block := ""
        while i <= lines.Length {
            line := lines[i]
            if Trim(line) != "" && !RegExMatch(line, "^\s") {
                break
            }
            stripped := RegExReplace(line, "^  ", "")
            block .= (block != "" ? "`n" : "") stripped
            i++
        }
        return RTrim(block, "`n`r ")
    }

    static _ParseInlineArray(value) {
        inner := SubStr(value, 2, StrLen(value) - 2)
        items := StrSplit(inner, ",")
        result := []
        for item in items {
            trimmed := Trim(item, " `t`r`n")
            trimmed := YamlParser._StripQuotes(trimmed)
            if trimmed != ""
                result.Push(trimmed)
        }
        return result
    }

    static _ParseListOfObjects(&i, lines) {
        list := []
        while i <= lines.Length {
            line := lines[i]
            if Trim(line) != "" && !RegExMatch(line, "^\s") {
                break
            }
            if RegExMatch(line, "^\s+-\s+(\w+)\s*:\s*(.*)", &match) {
                obj := Map()
                obj[match[1]] := YamlParser._StripQuotes(Trim(match[2]))
                i++
                while i <= lines.Length {
                    innerLine := lines[i]
                    if RegExMatch(innerLine, "^\s{4,}(\w+)\s*:\s*(.*)", &innerMatch) {
                        obj[innerMatch[1]] := YamlParser._StripQuotes(Trim(innerMatch[2]))
                        i++
                    } else {
                        break
                    }
                }
                list.Push(obj)
            } else if Trim(line) = "" {
                i++
            } else {
                break
            }
        }
        return list
    }

    static _StripQuotes(value) {
        if (SubStr(value, 1, 1) = '"' && SubStr(value, -1) = '"')
            return SubStr(value, 2, StrLen(value) - 2)
        if (SubStr(value, 1, 1) = "'" && SubStr(value, -1) = "'")
            return SubStr(value, 2, StrLen(value) - 2)
        return value
    }
}
