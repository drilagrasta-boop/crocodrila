#Requires AutoHotkey v2.0

class TrayMenu {

    static Setup(promptsDir, onReload) {
        A_TrayMenu.Delete()
        A_TrayMenu.Add("Recarregar Prompts", (*) => onReload())
        A_TrayMenu.Add("Abrir Pasta de Prompts", (*) => Run('explorer.exe "' promptsDir '"'))
        A_TrayMenu.Add()  ; separator
        A_TrayMenu.Add("Sair", (*) => ExitApp())

        ; Tray icon (Crocodrila prompta) - usa .ico; a bandeja do Windows nao carrega PNG de forma confiavel
        iconPath := A_ScriptDir "\assets\crocodrila-tray.ico"
        TrayMenu.ApplyIcon(iconPath)
        ; No logon o TraySetIcon pode nao pegar (bandeja ainda instavel); reaplica apos 15s
        SetTimer () => TrayMenu.ApplyIcon(iconPath), -15000

        A_IconTip := "Crocodrila prompta"
    }

    static ApplyIcon(iconPath) {
        if FileExist(iconPath)
            try TraySetIcon(iconPath)
    }
}
