#Requires AutoHotkey v2.0

class ConfigLoader {

    static Defaults := Map(
        "hotkey", "^+Space",
        "reload_hotkey", "^+F5",
        "window_width", 600,
        "max_results", 20
    )

    /**
     * Load config.yaml and return a Map with settings.
     * Missing keys get default values.
     */
    static Load(configPath) {
        settings := ConfigLoader.Defaults.Clone()
        if FileExist(configPath) {
            parsed := YamlParser.ParseFile(configPath)
            for key, value in parsed {
                settings[key] := value
            }
        }
        ; Ensure numeric values
        settings["window_width"] := Integer(settings["window_width"])
        settings["max_results"] := Integer(settings["max_results"])
        return settings
    }
}
