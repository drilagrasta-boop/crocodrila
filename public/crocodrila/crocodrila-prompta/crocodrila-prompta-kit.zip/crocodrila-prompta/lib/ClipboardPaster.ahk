#Requires AutoHotkey v2.0

class ClipboardPaster {

    /**
     * Paste text into the active application.
     * Saves current clipboard, sets new content, pastes, restores original.
     */
    static Paste(text) {
        ; Save current clipboard
        savedClip := ClipboardAll()

        ; Set clipboard to our text
        A_Clipboard := text

        ; Brief delay to ensure clipboard is set
        Sleep 50

        ; Simulate Ctrl+V
        Send "^v"

        ; Wait for paste to complete, then restore
        Sleep 150
        A_Clipboard := savedClip
    }
}
