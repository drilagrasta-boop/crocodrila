#Requires AutoHotkey v2.0

class VariableGui {

    __New(onComplete, onCancel) {
        this.onComplete := onComplete
        this.onCancel := onCancel
        this.gui := ""
        this.edits := Map()
        this.variableNames := []
    }

    Show(promptData) {
        if this.gui {
            try this.gui.Destroy()
        }

        this.edits := Map()
        this.variableNames := []
        variables := promptData["variables"]

        g := Gui("+AlwaysOnTop -Caption +Border", "Preencher Variaveis")
        g.BackColor := "1e1e1e"
        g.MarginX := 15
        g.MarginY := 10
        this.gui := g

        titleCtrl := g.Add("Text", "w570 cWhite", promptData["name"])
        titleCtrl.SetFont("s13 Bold", "Segoe UI")

        g.Add("Text", "w570 h1 Background555555")

        for varDef in variables {
            varName := varDef["name"]
            label := varDef.Has("label") ? varDef["label"] : varName
            placeholder := varDef.Has("placeholder") ? varDef["placeholder"] : ""
            defaultVal := varDef.Has("default") ? varDef["default"] : ""

            this.variableNames.Push(varName)

            labelCtrl := g.Add("Text", "w570 c999999", label ":")
            labelCtrl.SetFont("s10", "Segoe UI")

            editCtrl := g.Add("Edit", "w570 h28 Background2d2d2d cWhite", defaultVal)
            editCtrl.SetFont("s11", "Segoe UI")

            if defaultVal = "" && placeholder != ""
                editCtrl.Value := ""

            this.edits[varName] := editCtrl
        }

        g.Add("Text", "w570 h5")
        cancelBtn := g.Add("Button", "w100 h30 Section", "Cancelar")
        cancelBtn.OnEvent("Click", (*) => this._Cancel())
        insertBtn := g.Add("Button", "w100 h30 ys Default", "Inserir")
        insertBtn.OnEvent("Click", (*) => this._Confirm())

        g.OnEvent("Escape", (*) => this._Cancel())

        g.Show("w600 Center")

        for varName in this.variableNames {
            if this.edits[varName].Value = "" {
                this.edits[varName].Focus()
                break
            }
        }
    }

    _Confirm() {
        values := Map()
        for varName in this.variableNames {
            values[varName] := this.edits[varName].Value
        }
        this.gui.Destroy()
        this.gui := ""
        callback := this.onComplete
        callback(values)
    }

    _Cancel() {
        this.gui.Destroy()
        this.gui := ""
        this.onCancel()
    }
}
