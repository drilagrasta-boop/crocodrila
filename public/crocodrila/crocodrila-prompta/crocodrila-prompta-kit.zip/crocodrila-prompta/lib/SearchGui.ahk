#Requires AutoHotkey v2.0

class SearchGui {

    __New(config, prompts, onSelect) {
        this.config := config
        this.prompts := prompts
        this.onSelect := onSelect
        this.filteredPrompts := []
        this.gui := ""
        this.searchEdit := ""
        this.listView := ""
    }

    Show() {
        if this.gui {
            try this.gui.Destroy()
        }

        width := this.config["window_width"]
        listHeight := 300

        g := Gui("+AlwaysOnTop -Caption +Border", "Crocodrila prompta")
        g.BackColor := "1e1e1e"
        g.MarginX := 0
        g.MarginY := 0
        this.gui := g

        this.searchEdit := g.Add("Edit", "x10 y10 w" (width - 20) " h30 Background2d2d2d cWhite", "")
        this.searchEdit.SetFont("s12", "Segoe UI")
        this.searchEdit.OnEvent("Change", (*) => this._OnSearchChange())

        this.listView := g.Add("ListView",
            "x10 y50 w" (width - 20) " h" listHeight
            " Background2d2d2d cWhite -Hdr +NoSortHdr -Multi AltSubmit",
            ["Prompt", "Categoria"])
        this.listView.SetFont("s11", "Segoe UI")
        this.listView.ModifyCol(1, (width - 20) * 0.64)
        this.listView.ModifyCol(2, (width - 20) * 0.33)
        this.listView.OnEvent("DoubleClick", (*) => this._OnConfirm())

        this._UpdateList("")

        g.OnEvent("Escape", (*) => this.Hide())

        g.Show("w" width " Center")
        this.searchEdit.Focus()

        this._RegisterKeys()
    }

    Hide() {
        this._UnregisterKeys()
        if this.gui {
            this.gui.Destroy()
            this.gui := ""
        }
    }

    _OnSearchChange() {
        query := this.searchEdit.Value
        this._UpdateList(query)
    }

    _UpdateList(query) {
        this.listView.Delete()
        maxResults := this.config["max_results"]
        this.filteredPrompts := PromptLoader.Search(this.prompts, query, maxResults)
        for p in this.filteredPrompts {
            category := p["area"]
            if p["task"] != ""
                category .= " > " p["task"]
            this.listView.Add("", p["name"], category)
        }
        if this.filteredPrompts.Length > 0
            this.listView.Modify(1, "Select Focus")
    }

    _OnConfirm() {
        row := this.listView.GetNext(0, "F")
        if row > 0 && row <= this.filteredPrompts.Length {
            selected := this.filteredPrompts[row]
            this.Hide()
            callback := this.onSelect
            callback(selected)
        }
    }

    _MoveSelection(direction) {
        current := this.listView.GetNext(0, "F")
        total := this.filteredPrompts.Length
        if total = 0
            return
        newRow := current + direction
        if newRow < 1
            newRow := total
        if newRow > total
            newRow := 1
        this.listView.Modify(newRow, "Select Focus")
        if current > 0
            this.listView.Modify(current, "-Select")
    }

    _RegisterKeys() {
        HotIfWinActive "ahk_id " this.gui.Hwnd
        Hotkey "Enter", (*) => this._OnConfirm(), "On"
        Hotkey "Up", (*) => this._MoveSelection(-1), "On"
        Hotkey "Down", (*) => this._MoveSelection(1), "On"
        HotIf
    }

    _UnregisterKeys() {
        try {
            HotIfWinActive "ahk_id " (this.gui ? this.gui.Hwnd : 0)
            Hotkey "Enter", "Off"
            Hotkey "Up", "Off"
            Hotkey "Down", "Off"
            HotIf
        }
    }
}
