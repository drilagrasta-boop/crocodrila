#Requires AutoHotkey v2.0

class PromptLoader {

    static LoadAll(promptsDir) {
        prompts := []
        promptsDir := RTrim(promptsDir, "\")

        loop files promptsDir "\*.yaml", "R" {
            try {
                parsed := YamlParser.ParseFile(A_LoopFileFullPath)

                if !parsed.Has("name") || !parsed.Has("prompt")
                    continue

                relativePath := SubStr(A_LoopFileDir, StrLen(promptsDir) + 2)
                parts := StrSplit(relativePath, "\")

                parsed["area"] := parts.Length >= 1 ? parts[1] : ""
                parsed["task"] := parts.Length >= 2 ? parts[2] : ""
                parsed["filePath"] := A_LoopFileFullPath

                if !parsed.Has("description")
                    parsed["description"] := ""
                if !parsed.Has("tags")
                    parsed["tags"] := []
                if !parsed.Has("variables")
                    parsed["variables"] := []

                searchText := StrLower(parsed["name"] " " parsed["description"] " " parsed["area"] " " parsed["task"])
                if Type(parsed["tags"]) = "Array" {
                    for tag in parsed["tags"] {
                        searchText .= " " StrLower(tag)
                    }
                }
                parsed["_searchText"] := searchText

                prompts.Push(parsed)
            } catch as err {
                continue
            }
        }
        return prompts
    }

    static Search(prompts, query, maxResults := 20) {
        if Trim(query) = ""
            return PromptLoader._LimitResults(prompts, maxResults)

        queryLower := StrLower(Trim(query))
        words := StrSplit(queryLower, " ")
        matches := []

        for prompt in prompts {
            allMatch := true
            for word in words {
                if word != "" && !InStr(prompt["_searchText"], word) {
                    allMatch := false
                    break
                }
            }
            if allMatch
                matches.Push(prompt)
        }
        return PromptLoader._LimitResults(matches, maxResults)
    }

    static FillVariables(promptText, values) {
        result := promptText
        for varName, varValue in values {
            result := StrReplace(result, "{" varName "}", varValue)
        }
        return result
    }

    static _LimitResults(arr, max) {
        if arr.Length <= max
            return arr
        limited := []
        loop max
            limited.Push(arr[A_Index])
        return limited
    }
}
