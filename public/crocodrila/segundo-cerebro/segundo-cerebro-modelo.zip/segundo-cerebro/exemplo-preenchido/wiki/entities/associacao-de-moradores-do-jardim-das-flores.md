# Associação de Moradores do Jardim das Flores

- **Tipo**: organização
- **Atuação**: associação de bairro; parceira do Projeto Horta Comunitária

## Contexto

Representada por [[joel-andrade]]. Tem uma caixa d'água parada que pode ceder à horta, mas decisões desse tipo dependem de aprovação em assembleia.

## Aparições

- [[2026-09-15-reuniao-horta-comunitaria]] — possível cedente da caixa d'água; pedido a ser votado na assembleia de outubro de 2026.
