# Joel Andrade

- **Tipo**: pessoa
- **Atuação**: representante da [[associacao-de-moradores-do-jardim-das-flores]] no Projeto Horta Comunitária

## Contexto

Faz a ponte entre a horta e a Associação de Moradores. Cético quanto à escala fixa de voluntários; prefere a [[irrigacao-por-gotejamento]].

## Aparições

- [[2026-09-15-reuniao-horta-comunitaria]] — ofereceu a caixa d'água parada da Associação; ficou encarregado de levar o pedido à assembleia de outubro.
