# Marta Siqueira

- **Tipo**: pessoa
- **Atuação**: coordenadora do Projeto Horta Comunitária

## Contexto

Coordena a horta. Abriu a reunião de 15/09/2026 relatando a perda das mudas de alface e defende uma [[escala-de-rega]] fixa de voluntários.

## Aparições

- [[2026-09-15-reuniao-horta-comunitaria]] — relatou o problema; ficou encarregada de organizar a escala de rega dos canteiros 3 a 6.
