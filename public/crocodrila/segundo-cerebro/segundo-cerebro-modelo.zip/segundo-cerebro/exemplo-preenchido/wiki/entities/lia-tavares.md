# Lia Tavares

- **Tipo**: pessoa
- **Atuação**: voluntária do Projeto Horta Comunitária; agrônoma

## Contexto

Traz o olhar técnico ao projeto. Diagnosticou a causa da perda das mudas (irrigação irregular) e propôs a [[irrigacao-por-gotejamento]] com garrafa PET.

## Aparições

- [[2026-09-15-reuniao-horta-comunitaria]] — fez o diagnóstico; ficou encarregada de montar os gotejadores nos canteiros 1 e 2 até 30/09/2026.
