# Log

Uma linha por operação: `DD/MM/AAAA | TIPO | arquivo ou pergunta | páginas`.

02/10/2026 | INGEST | raw/anotacoes/2026-09-15-reuniao-horta-comunitaria.md | criadas: sources/2026-09-15-reuniao-horta-comunitaria, concepts/irrigacao-por-gotejamento, concepts/escala-de-rega, entities/marta-siqueira, entities/joel-andrade, entities/lia-tavares, entities/associacao-de-moradores-do-jardim-das-flores

