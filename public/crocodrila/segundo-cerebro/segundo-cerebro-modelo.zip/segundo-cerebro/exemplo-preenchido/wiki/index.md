# Índice

Catálogo de todas as páginas da wiki. Mantido pelo assistente.

## Fontes (sources)

- [[2026-09-15-reuniao-horta-comunitaria]] — reunião sobre perda de mudas e teste gotejamento x escala de rega

## Conceitos (concepts)

- [[irrigacao-por-gotejamento]] — rega lenta com garrafa PET; umidade por cerca de três dias
- [[escala-de-rega]] — revezamento fixo de voluntários para regar

## Entidades (entities)

- [[marta-siqueira]] — coordenadora do Projeto Horta Comunitária
- [[joel-andrade]] — representante da Associação de Moradores do Jardim das Flores
- [[lia-tavares]] — voluntária, agrônoma
- [[associacao-de-moradores-do-jardim-das-flores]] — associação de bairro parceira da horta

## Padrões (patterns)

## Sínteses (synthesis)
