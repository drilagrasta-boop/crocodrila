# Escala de rega

## Definição

Revezamento fixo de voluntários responsáveis por regar a horta ([[2026-09-15-reuniao-horta-comunitaria]]).

## Como aparece nas fontes

- [[2026-09-15-reuniao-horta-comunitaria]] — defendida por [[marta-siqueira]]. [[joel-andrade]] discorda: acha que não funciona porque as pessoas faltam. Será mantida nos canteiros 3 a 6, em comparação com a [[irrigacao-por-gotejamento]] dos canteiros 1 e 2.

## Fontes

- [[2026-09-15-reuniao-horta-comunitaria]]
