# Irrigação por gotejamento

## Definição

Rega lenta e contínua das plantas. Na versão citada nas fontes, feita com garrafa PET: custa quase nada e segura a umidade por cerca de três dias ([[2026-09-15-reuniao-horta-comunitaria]]).

## Como aparece nas fontes

- [[2026-09-15-reuniao-horta-comunitaria]] — proposta por [[lia-tavares]] para resolver a falta de rega nos fins de semana, que causou a perda de metade das mudas de alface em agosto. [[joel-andrade]] a prefere à [[escala-de-rega]] por não depender da presença de voluntários. Será testada nos canteiros 1 e 2, com comparação prevista para novembro de 2026.

## Fontes

- [[2026-09-15-reuniao-horta-comunitaria]]
