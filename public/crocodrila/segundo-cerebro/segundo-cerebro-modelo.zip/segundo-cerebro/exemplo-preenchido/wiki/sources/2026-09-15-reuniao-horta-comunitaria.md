# Reunião do Projeto Horta Comunitária — 15/09/2026

- **Tipo**: anotação
- **Origem**: notas de reunião do Projeto Horta Comunitária (a própria anotação se declara fictícia, criada como exemplo)
- **Data da fonte**: 15/09/2026
- **Arquivo raw**: [[raw/anotacoes/2026-09-15-reuniao-horta-comunitaria]]
- **Processado em**: 02/10/2026

## Resumo

A reunião partiu de uma perda concreta: a horta perdeu metade das mudas de alface em agosto. O diagnóstico, apresentado pela agrônoma [[lia-tavares]], foi a irrigação irregular. Nos fins de semana ninguém rega, e em dias quentes a muda não aguenta dois dias sem água.

Como solução, Lia propôs a [[irrigacao-por-gotejamento]] com garrafa PET: custo quase nulo e umidade mantida por cerca de três dias. A [[associacao-de-moradores-do-jardim-das-flores]], por meio de [[joel-andrade]], ofereceu uma caixa d'água parada, mas a cessão depende de aprovação na assembleia de outubro.

O ponto de divergência foi a [[escala-de-rega]]. [[marta-siqueira]] defende uma escala fixa de voluntários. Joel acha que ela não funciona porque as pessoas faltam, e prefere o gotejamento justamente para não depender de gente. A divergência não foi resolvida por argumento, e sim por um teste: gotejamento nos canteiros 1 e 2, escala nos canteiros 3 a 6, com comparação em novembro.

Encaminhamentos: Lia monta os gotejadores nos canteiros 1 e 2 até 30/09; Joel leva o pedido da caixa d'água à assembleia de outubro; Marta organiza a escala dos canteiros 3 a 6. Próxima reunião em 10/11/2026.

Em aberto: o resultado da comparação; a aprovação da caixa d'água; e se o prazo de 30/09 para os gotejadores foi cumprido (a confirmar: a fonte é anterior a essa data).

## Conceitos

- [[irrigacao-por-gotejamento]] — solução proposta para a falta de rega nos fins de semana; testada nos canteiros 1 e 2.
- [[escala-de-rega]] — alternativa defendida pela coordenação; mantida nos canteiros 3 a 6 para comparação.

## Entidades

- [[marta-siqueira]] — coordenadora; defende escala fixa de voluntários.
- [[joel-andrade]] — representante da Associação de Moradores; prefere o gotejamento.
- [[lia-tavares]] — voluntária, agrônoma; fez o diagnóstico e propôs o gotejamento.
- [[associacao-de-moradores-do-jardim-das-flores]] — pode ceder uma caixa d'água, sujeita à assembleia.

## Conexões

Primeira fonte da wiki; ainda não há páginas com que confirmar ou contrastar. A reunião de 10/11/2026, se registrada em raw/, deve trazer o resultado do teste e desenvolver esta fonte diretamente.
