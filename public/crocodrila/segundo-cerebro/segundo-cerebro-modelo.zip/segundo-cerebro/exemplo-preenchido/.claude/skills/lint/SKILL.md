---
name: lint
description: Manutenção da wiki do segundo cérebro - links quebrados, páginas órfãs, duplicatas, índice desatualizado, contradições e sugestões de síntese. Use uma vez por semana ou quando a pessoa pedir verificação, manutenção ou faxina da wiki.
---

# /lint — Manutenção da wiki

Verifique e relate (não corrija sem perguntar, salvo o índice):

1. wiki/index.md contra as páginas que existem: entradas faltando ou sobrando.
   Esta correção pode ser feita direto.
2. Links [[slug]] sem página correspondente (links quebrados).
3. Páginas órfãs: nenhuma outra página aponta para elas.
4. Possíveis duplicatas: duas páginas sobre o mesmo conceito ou entidade.
5. Conceitos citados em 3 ou mais fontes que ainda não têm página própria.
6. Contradições entre fontes sobre o mesmo ponto.
7. Temas com 5 ou mais fontes relacionadas: sugira uma página em synthesis/.
8. Arquivos de raw/ que nunca foram processados (não aparecem no log).

Apresente uma lista curta por item, com a ação sugerida, e pergunte o que
aplicar. Acrescente a wiki/log.md:
`{DD/MM/AAAA} | LINT | {problemas encontrados} | {ações aplicadas ou sugeridas}`
