---
name: query
description: Responde perguntas consultando a wiki do segundo cérebro, com referência às páginas e fontes. Use quando a pessoa perguntar "o que já temos sobre", "o que a base diz sobre", ou pedir contexto acumulado.
argument-hint: {pergunta}
---

# /query — Consultar a wiki

1. Leia wiki/index.md e identifique as páginas relevantes para a pergunta.
2. Leia essas páginas e, quando precisar de detalhe, a fonte em raw/ que elas citam.
3. Responda com base SÓ no que está na wiki e nas fontes, citando as páginas
   como [[slug]]. O que for inferência sua, diga que é inferência.
4. Se a base não tiver o suficiente, diga o que falta e sugira que fontes
   processar com /ingest.
5. Se a resposta for longa ou reutilizável, ofereça salvá-la em output/.
6. Acrescente a wiki/log.md:
   `{DD/MM/AAAA} | QUERY | {pergunta resumida} | {páginas consultadas}`
