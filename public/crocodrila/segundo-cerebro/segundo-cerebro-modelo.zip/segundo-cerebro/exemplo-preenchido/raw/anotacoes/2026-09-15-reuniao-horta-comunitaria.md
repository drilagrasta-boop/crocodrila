# Reunião do Projeto Horta Comunitária — 15/09/2026

(anotação fictícia, criada como exemplo)

Presentes: Marta Siqueira (coordenadora), Joel Andrade (Associação de Moradores do Jardim das Flores), Lia Tavares (voluntária, agrônoma).

Marta abriu dizendo que a horta perdeu metade das mudas de alface em agosto. Lia explicou que o problema foi a irrigação irregular: nos fins de semana ninguém rega, e em dias quentes a muda não aguenta dois dias sem água. Ela propôs irrigação por gotejamento com garrafa PET, que custa quase nada e segura a umidade por uns três dias.

Joel lembrou que a Associação tem uma caixa d'água parada e pode ceder, mas disse que precisa de aprovação na assembleia de outubro.

Discussão sobre escala de rega: Marta quer uma escala fixa de voluntários; Joel acha que escala fixa não funciona porque as pessoas faltam, e prefere o gotejamento para não depender de gente. Ficou combinado testar o gotejamento em dois canteiros e manter a escala nos outros, para comparar em novembro.

Encaminhamentos:
- Lia monta os gotejadores de garrafa PET nos canteiros 1 e 2 até 30/09.
- Joel leva o pedido da caixa d'água à assembleia de outubro.
- Marta organiza a escala de rega para os canteiros 3 a 6.
- Próxima reunião: 10/11/2026, para comparar os resultados.
