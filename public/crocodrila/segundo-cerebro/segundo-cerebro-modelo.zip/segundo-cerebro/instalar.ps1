# instalar.ps1 - cria o seu Segundo Cerebro a partir do modelo vazio
#
# Uso normal: botao direito > "Executar com PowerShell".
# Opcao: -Destino "C:\outra\pasta"   (padrao: Documentos\segundo-cerebro)

param(
    [string]$Destino = (Join-Path ([Environment]::GetFolderPath("MyDocuments")) "segundo-cerebro"),
    [switch]$SemPausa
)

$ErrorActionPreference = "Continue"
$modelo = Join-Path $PSScriptRoot "vault-modelo"

function Fim { if (-not $SemPausa) { Write-Host ""; Read-Host "Aperte Enter para fechar" } }

Write-Host ""
Write-Host "=== Segundo Cerebro - criando o seu vault ===" -ForegroundColor Cyan
Write-Host "Destino: $Destino"
Write-Host ""

if (-not (Test-Path (Join-Path $modelo "CLAUDE.md"))) {
    Write-Host "[ERRO] Nao achei a pasta vault-modelo ao lado deste instalador." -ForegroundColor Red
    Write-Host "       Extraia o zip inteiro antes de rodar."
    Fim; exit 1
}

# Nunca sobrescrever um vault que ja existe
if ((Test-Path $Destino) -and (Get-ChildItem -Path $Destino -Force | Select-Object -First 1)) {
    Write-Host "[PAROU] A pasta $Destino ja existe e nao esta vazia." -ForegroundColor Yellow
    Write-Host "        Para nao estragar nada, o instalador nao mexe nela."
    Write-Host "        Rode de novo escolhendo outra pasta, por exemplo:"
    Write-Host "        .\instalar.ps1 -Destino `"$Destino-2`""
    Fim; exit 1
}

New-Item -ItemType Directory -Path $Destino -Force | Out-Null
Copy-Item -Path (Join-Path $modelo "*") -Destination $Destino -Recurse -Force
foreach ($oculta in ".claude", ".obsidian") {
    Copy-Item -Path (Join-Path $modelo $oculta) -Destination $Destino -Recurse -Force
}

$faltando = @()
foreach ($item in "CLAUDE.md", "wiki\index.md", "wiki\log.md",
                  ".claude\skills\ingest\SKILL.md", ".claude\skills\query\SKILL.md",
                  ".claude\skills\lint\SKILL.md", ".obsidian\app.json", "raw\documentos") {
    if (-not (Test-Path (Join-Path $Destino $item))) { $faltando += $item }
}
if ($faltando) {
    Write-Host "[ERRO] Faltaram: $($faltando -join ', ')" -ForegroundColor Red
    Fim; exit 1
}

Write-Host "[OK] Vault criado em $Destino" -ForegroundColor Green
Write-Host ""
Write-Host "Proximos passos (detalhes no COMECE-AQUI.txt):"
Write-Host "  1. Abra o CLAUDE.md do vault e troque [SUA AREA] pela sua area."
Write-Host "  2. No Obsidian: 'Open folder as vault' e escolha a pasta acima."
Write-Host "  3. Ponha um documento em raw\ e, no Claude Code aberto na pasta,"
Write-Host "     peca: /ingest raw/documentos/<arquivo>"
Fim
