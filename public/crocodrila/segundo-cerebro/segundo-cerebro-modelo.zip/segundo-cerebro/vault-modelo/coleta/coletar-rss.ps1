# coletar-rss.ps1
# Le os enderecos de feed (RSS ou Atom) em fontes-rss.txt e salva as novidades
# em raw\coletas\AAAA-MM-DD-coleta-rss.md. Nao usa IA e nao processa nada:
# so coleta. Depois, peca ao Claude: /ingest raw/coletas/<arquivo>
#
# Uso:  powershell -ExecutionPolicy Bypass -File coletar-rss.ps1 [-Dias 7]

param([int]$Dias = 7)

$ErrorActionPreference = "Continue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$vault  = Split-Path $PSScriptRoot -Parent
$fontes = Join-Path $PSScriptRoot "fontes-rss.txt"
$pasta  = Join-Path $vault "raw\coletas"
$limite = (Get-Date).AddDays(-$Dias)

function Limpar([string]$t) {
    if (-not $t) { return "" }
    $t = [regex]::Replace($t, "<[^>]+>", " ")
    $t = [System.Net.WebUtility]::HtmlDecode($t)
    $t = [regex]::Replace($t, "\s+", " ").Trim()
    if ($t.Length -gt 400) { $t = $t.Substring(0, 400) + "..." }
    return $t
}

function Texto($no) {
    if ($null -eq $no) { return "" }
    if ($no -is [string]) { return $no }
    if ($no.'#text') { return $no.'#text' }
    if ($no.InnerText) { return $no.InnerText }
    return "$no"
}

# Datas de feed vem em ingles ("Sat, 26 Sep 2026 00:00:00 GMT") ou ISO 8601;
# a cultura invariante le os dois, qualquer que seja o idioma do Windows.
function LerData([string]$s) {
    if (-not $s) { return $null }
    $r = [DateTimeOffset]::MinValue
    $cult = [Globalization.CultureInfo]::InvariantCulture
    $estilo = [Globalization.DateTimeStyles]::AssumeUniversal
    if ([DateTimeOffset]::TryParse($s.Trim(), $cult, $estilo, [ref]$r)) { return $r.LocalDateTime }
    return $null
}

if (-not (Test-Path $fontes)) { Write-Host "Nao achei $fontes"; exit 1 }
$urls = Get-Content $fontes -Encoding UTF8 | ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and -not $_.StartsWith("#") }
if (-not $urls) { Write-Host "fontes-rss.txt esta vazio. Ponha um endereco de feed por linha."; exit 1 }

New-Item -ItemType Directory -Path $pasta -Force | Out-Null
$hoje = Get-Date -Format "yyyy-MM-dd"
$saida = Join-Path $pasta "$hoje-coleta-rss.md"
$linhas = New-Object System.Collections.Generic.List[string]
$linhas.Add("# Coleta RSS de $(Get-Date -Format 'dd/MM/yyyy')")
$linhas.Add("")
$linhas.Add("Itens publicados nos ultimos $Dias dias. Gerado por coleta/coletar-rss.ps1.")
$total = 0

foreach ($url in $urls) {
    try {
        $resp = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 30
        $bytes = $resp.RawContentStream.ToArray()
        $xml = New-Object System.Xml.XmlDocument
        $xml.LoadXml([System.Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xFEFF))
    } catch {
        Write-Host "[ERRO] $url : $($_.Exception.Message)" -ForegroundColor Yellow
        $linhas.Add(""); $linhas.Add("## $url"); $linhas.Add(""); $linhas.Add("(falha na coleta: $($_.Exception.Message))")
        continue
    }
    $itens = @()
    if ($xml.rss) {
        $nomeFeed = Texto $xml.rss.channel.title
        foreach ($i in $xml.rss.channel.item) {
            $itens += [pscustomobject]@{ T = Texto $i.title; L = Texto $i.link; D = Texto $i.pubDate; R = Texto $i.description }
        }
    } elseif ($xml.feed) {
        $nomeFeed = Texto $xml.feed.title
        foreach ($e in $xml.feed.entry) {
            $link = ($e.link | Where-Object { -not $_.rel -or $_.rel -eq "alternate" } | Select-Object -First 1).href
            $data = if ($e.published) { Texto $e.published } else { Texto $e.updated }
            $itens += [pscustomobject]@{ T = Texto $e.title; L = $link; D = $data; R = (Texto $e.summary) }
        }
    } else {
        Write-Host "[ERRO] $url nao parece RSS nem Atom" -ForegroundColor Yellow
        continue
    }
    $novos = foreach ($it in $itens) {
        $dt = LerData $it.D
        if ($dt -and $dt -lt $limite) { continue }
        $it
    }
    $linhas.Add(""); $linhas.Add("## $nomeFeed"); $linhas.Add(""); $linhas.Add("Fonte: $url")
    if (-not $novos) { $linhas.Add(""); $linhas.Add("(nada novo no periodo)"); continue }
    foreach ($it in $novos) {
        $linhas.Add(""); $linhas.Add("### $(Limpar $it.T)")
        $linhas.Add("- Link: $($it.L)")
        if ($it.D) { $linhas.Add("- Data: $($it.D)") }
        $resumo = Limpar $it.R
        if ($resumo) { $linhas.Add(""); $linhas.Add($resumo) }
        $total++
    }
    Write-Host "[OK] $nomeFeed : $(@($novos).Count) item(ns)" -ForegroundColor Green
}

[System.IO.File]::WriteAllLines($saida, $linhas, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ""
Write-Host "Coleta salva em $saida ($total itens)."
