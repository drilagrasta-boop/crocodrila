# Log

Uma linha por operação: `DD/MM/AAAA | TIPO | arquivo ou pergunta | páginas`.

