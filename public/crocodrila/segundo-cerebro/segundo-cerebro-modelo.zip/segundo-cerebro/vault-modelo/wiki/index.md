# Índice

Catálogo de todas as páginas da wiki. Mantido pelo assistente.

## Fontes (sources)

## Conceitos (concepts)

## Entidades (entities)

## Padrões (patterns)

## Sínteses (synthesis)
